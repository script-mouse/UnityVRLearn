# Changelog

## Added

## Removed

## Changed

# [0.11.2]

## Changed

- fix calibration for half vr table configurations

# [0.11.1]

## Added

- support for debug ui for HalfVRTable configuration

## Changed

- renamed input actions for switching eyes on displays

# [0.11.0]

## Added

- prefab for half width VR Table configuration

# [0.10.3]

## Changed

- work around camera render textures changing after a scene change

# [0.10.2]

## Changed

- fix blend state setup in correct helper function and remove dead SetupPresentState() from backend

# [0.10.1]

## Changed

- fixed missing blend state setup for drawing to present windows

# [0.10.0] - 2025-06-09

## Added

- mono only setup for VDen
- mono settings file for regular VDen setup

## Changed

- separated drawing and presenting windows plugin events
- fixed tracking origin calibration scene for led wall
- fixed missing trackingOrigin field in led wall camera rig

# [0.9.5] - 2025-02-17

## Changed

- fixes null deref in warp mesh calibration
- fixes use of APIs that are deprecated in Unity 6 (but have alternatives in 2022.3 and later)

# [0.9.4] - 2025-02-14

## Changed

- fixes crash caused by de-serializing settings from Awake

# [0.9.3] - 2025-02-06

## Changed

- adds separate mono prefab for LEDWall

# [0.9.2] - 2025-01-23

## Added

- adds switching between warpmesh and tracking origin calibration scenes to vden

## Changed

- fix calibration to use previously saved config as starting point

# [0.9.1] - 2024-10-29

## Changed

- fix typo in class name
- fix missing RenderViewOrigin in LED wall prefab

# [0.9.0] - 2024-10-28

## Added

- new SourceCameraInfoOverride to allow changing the camera IPD value from settings files
- additional graphics devices for presenting to windows, handles resource copies
- camera rig for Magnetic3D autostereo display

## Changed

- vden calibration: toggle calibration ui with eye debug ui to allow getting eyes correct when calibrating
- replaces LED Wall mono/stereo rigs with single rig
- adds tracked controller objects to camera rigs

# [0.8.0] - 2024-08-14

## Changed

- Fixed handling of head tracker updates in editor (avoids overwriting tracking data with default pose).

# [0.7.0] - 2024-08-08

## Added

- RenderViewCameraOriginStatic for setups without head tracking

# [0.6.0] - 2024-07-31

## Added

- RenderViewCameraOrigin with OpenVR (SteamVR) action inputs
- Option to control the swap interval

- Revert VDen prefab to use four windows - the single window setup produces lots of flickering in some scenes.

# [0.5.1] - 2024-07-23

## Changed

- Fixed eye swap implementation for VDen

# [0.5.0] - 2024-07-23

## Changed

- Allows disabling HTC Vive Tracker integration with define `VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER`. This is needed for coexistence with the MDVR package which also provides this integration.

# [0.4.0] - 2024-07-17

## Added

- settings files can now contain a "renderScreenOverrides" array that allows making adjustments (size, position, rotation) to existing RenderScreens in the camera rig.

## Changed

- Fixed additional serialization issues that are only present in (release) builds.
- Use a single window for the VDen.
- Documented settings file contents.

# [0.3.0] - 2024-07-15

## Changed

- Fixed serialization crash in builds, caused by com.unity.serialization package not being fully initialized at Awake time.

# [0.2.0] - 2024-07-10

## Added

- Support for switching scenes
- API to update a present source. Allows updating the native texture pointer (and internally re-creates the necessary resources to sample from them, e.g. SRV)
- Calibration of the tracking origin for VRTable

## Changed

- _BREAKING_: Renamed uses of PresentMesh to WarpMesh in type names and variables
- Moved coroutine triggering presentation on external windows to `ExternalDisplayCameraRig`. This allows detecting when a source camera's render texture native pointer has changed and the corresponding present source must be updated.
- Marked the `DontDestroyOnLoad` GameObject storing the plugin state hidden in the inspector
- Improved warp mesh calibration

# [0.1.0] - 2024-06-27

## Added

- Camera rig scripts for MicroTile LED Wall (mono and stereo)
- WarpMesh calibration for VDen

## Changed

- _BREAKING_: Uses a new type to store window settings in ExternalDisplayCameraRig. Settings in scenes/prefabs need to be set again.
- Elements of window override are optional
- Configure prefabs for previewing in editor, provide settings files for builds (or play mode on device)

## Removed

# [0.0.2] - 2024-06-06

## Added

- Ability to override some configuration from a file
  - Window placement and size
  - Warp mesh style, control points, resolution
- Plugin function to update present mesh (still unused)

# [0.0.1] - 2024-05-28

## Added

- Initial release contains basic functionality for LED wall

[0.10.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.5...v0.10.0
[0.9.5]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.4...v0.9.5
[0.9.4]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.3...v0.9.4
[0.9.3]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.2...v0.9.3
[0.9.2]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.1...v0.9.2
[0.9.1]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.9.0...v0.9.1
[0.9.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.8.0...v0.9.0
[0.8.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.7.0...v0.8.0
[0.7.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.6.0...v0.7.0
[0.6.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.5.1...v0.6.0
[0.5.1]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.5.0...v0.5.1
[0.5.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.4.0...v0.5.0
[0.4.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.3.0...v0.4.0
[0.3.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.2.0...v0.3.0
[0.2.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.1.0...v0.2.0
[0.1.0]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.0.2...v0.1.0
[0.0.2]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/compare/v0.0.1...v0.0.2
[0.0.1]: https://gitlab.varlab-internal.cecs.ucf.edu/cneumann/external-display-plugin/-/tree/v0.0.1?ref_type=tags
