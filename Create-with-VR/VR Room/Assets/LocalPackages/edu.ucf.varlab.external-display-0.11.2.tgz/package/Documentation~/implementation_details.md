# Implementation Details

## Overview

The package provides camera rigs for different immersive display systems and enables the development of additional ones.
Typically these display systems involve multiple physical displays (e.g. monitors or projectors) connected to one computer.

While Unity has some support for rendering to multiple displays (see [`UnityEngine.Display`](https://docs.unity3d.com/ScriptReference/Display.html)) there is limited control over how Unity positions and sizes the windows it places on those displays and no option to utilize workstation class display synchronization (e.g. [Nvidia Quadro Sync](https://www.nvidia.com/en-us/design-visualization/solutions/quadro-sync/)).
To overcome these limitations the camera rigs in the package all render to [`UnityEngine.RenderTexture`](https://docs.unity3d.com/ScriptReference/RenderTexture.html), share those `RenderTexture`s with a [native render plugin](https://docs.unity3d.com/Manual/NativePluginInterface.html) which creates its own windows and draws the `RenderTexture`s to those windows.

On the Unity side the main class is `ExternalDisplayCameraRig` which is the base class for all camera rigs supported by the package.
The derived classes (e.g. `ExternalDisplayCameraRigVDen`) typically add only a small amount of system specific functionality and configuration.
The camera rig also stores the configuration of how many windows to create and where to position them, and which cameras content is displayed on which window.

The first configuration section `Device Infos` allows configuring additional graphics devices to be used.
This is currently only necessary for the LED Wall in 3D stereo and the feature should be considered experimental - somewhat counter intuitively it is also likely to incur performance overhead, because `RenderTexture` data needs to be copied to the additional devices.

The `Window Infos` section defines how many windows are created and their size and position on the desktop.
The `Device Name` field can refer to a device from the `Device Infos` section or be left blank to associate the window with Unity's graphics device.

Section `Source Camera Infos` contains references to the cameras of the rig that render the scene.
These cameras are expected to be configured to render into `RenderTexture`s and usually are (indirect) child objects of the camera rig.
`RenderTexture`s of the cameras are registered with the native plugin in order for them to be drawn to the windows.

Detailed control of how the views produced by the source cameras are drawn to the windows is defined by the last two sections `Warp Mesh Infos` and `Present Infos` respectively.
`Warp Mesh Infos` are used to define (optional) distortions applied to (parts of) a `RenderTexture`.
The distortion is primarily used by the VDen camera rig (to compensate for the projectors overshooting the screens and not being perfectly aligned with them).
The VRTable camera rig uses the ability to only show parts of a `RenderTexture` to pick regions that correspond to the physical displays.
Finally, `Present Infos` combine elements from the other sections to define which camera' views are rendered to a window utilizing which warp mesh.

## Settings Override Files

While it is convenient to be able to edit the settings for a camera rig from the Unity Editor that also means that making any changes requires rebuilding the application.
Especially for a system like the VDen where the warp mesh details depend on the projector calibration this is inconvenient - every time a screen gets bumped and the calibration refreshed all applications would need to be re-build.
Therefore (most of) the settings made in the editor can be overridden from a settings file loaded from the `StreamingAssets/VARLab_ExternalDisplay` folder.
For details of the available settings, see [Settings File Reference](settings_file_reference.md).
The settings file is loaded early during startup of the `ExternalDisplayCameraRig` (see `ExternalDisplayCameraRig.TryLoadSettings`) and overrides the settings made in the editor.
Settings not mentioned in the file remain unchanged.

## Interface to the Native Plugin

After processing the settings files the camera rig creates or registers resources with the native plugin.
For each item a descriptor object is created (e.g. `NativeDeviceDesc`, `NativeWindowDesc`, etc) and passed to the native plugin through functions of the `PluginAPI` class.
They carry very similar information to the objects used to store settings on the camera rig, the main difference is that they are have matching definitions in native code so they can be used to transport information between C# and C++ code.
The native plugin will assign an `Index` to the object that is stored in the descriptor object (on successful return from the `PluginAPI` function).
The `Index` is the primary way how native code differentiates between objects of the same type (e.g. two different windows).
