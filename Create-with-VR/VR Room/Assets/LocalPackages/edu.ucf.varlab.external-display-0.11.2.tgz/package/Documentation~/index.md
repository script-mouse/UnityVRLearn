# Overview

The VARLab External Display Plugin package makes it possible to display camera views of Unity scenes on (multiple) windows, that can span displays (e.g. monitors/projectors).

# Package Contents

In the package's `Assets/Prefabs` folder are pre-configured camera rigs for VARLab systems (VDen, VRTable, LED Tile Wall). These can be added to a scene and replace the existing main camera (or camera rig).
Additionally, in the package's `Assets/Settings` folder are files storing the correct window sizes/positions and distortion calibration settings (e.g. for the VDen). These _must_ be copied to `StreamingAssets/VARLab_ExternalDisplay/settings_<SUFFIX>.json`

# Installation Quick Start

This section is for experienced users that have used the package before and just need a quick reminder of the necessary steps to add it to a (new or existing) project. For a more detailed walkthrough of the necessary steps see [Installation Instructions](#installation-instructions) below.

- Install the OpenXR plugin for Unity and ensure you are using the new Input System (for head/controller tracking)
- Install the VARLab External DIsplay Plugin package (`edu.ucf.varlab.external-display`) using the Unity Package Manager.
- Add a prefab from the `Packages/VARLab External Display/Assets/Prefabs` folder to your scene (use a prefab that matches your desired display system, e.g. `P_VRTableCameraRig` for the VR Table).
- Copy the matching settings file from `Packages/VARLab External Display/Assets/Settings` to `StreamingAssets/VARLab_ExternalDisplay`.
- Modify/Extend the prefab (e.g. add a UI Canvas or tracked controllers) and save it as a prefab variant in your project.

# Quick Links

- Project Packages: https://nextcloud.varlab-internal.cecs.ucf.edu/apps/files/?dir=/VARLab%20Unity%20Packages/edu.ucf.varlab.external-display
- Project Repository: https://gitlab.varlab-internal.cecs.ucf.edu/lab-projects/external-display-plugin

# Installation Instructions

## Project Preparation

- Create layers `LeftEyeOnly` (Layer 20), `RightEyeOnly` (Layer 21) in `Edit/Project Settings`, section `Tags and Layers`. This step may be skipped if not using one of the included prefabs nor the `P_EyeDebugUI`. Different layer indices may be used, but in that case they may not be displayed correctly in the Unity Editor Inspector (this is a Unity limitation, as it saves the layer index in prefabs/scenes).
- (Optional) Ensure the project uses linear color space (newer Unity version create projects with linear color space):
  - `Edit/Project Settings...`
  - section `Player/Other Settings` change `Color Space` to `Linear`
- Install the `OpenXR Plugin`:
  - Open the Unity package manager: `Window/Package Manager`
  - Select `Packages: Unity Registry` from the dropdown in the top bar
  - Install package `OpenXR Plugin`
- Unity should ask to enable the backends for the `Input System`, accept and restart the editor

## Install the package

### Installing from a tarball

Download the package `.tgz` file (aka tarball) from [VARLab Nextcloud](https://nextcloud.varlab-internal.cecs.ucf.edu/apps/files/?dir=/VARLab%20Unity%20Packages/edu.ucf.varlab.external-display) and save it to a folder in your project, e.g. `Packages/VARLab/edu.ucf.varlab.external-display-X.Y.Z.tgz`.

**IMPORTANT:** Do _NOT_ save the tarball to the `Download` folder or any other location _outside_ your project; importing a package tarball from outside the project will store an absolute path in the `Packages/manifest.json` and that breaks when cloning the project repository on a different computer.

- Open the Unity package manager: `Window/Package Manager`

  - click the `+` icon in the top left corner
  - select `Add package from tarball...`
  - select the just downloaded file

### Installing from git

As an alternative (i.e. _instead_ of installing from a tarball) the package can also installed directly from git. Note that this makes your project less self contained as now access to the VARLab GitLab server is required to clone the project repo. This method makes it also more difficult to tell which version of the package you are using, because it will install whatever the default branch in the git repository is at.

- Open the Unity package manager: `Window/Package Manager`

  - click the `+` icon in the top left corner
  - select `Add package from a git URL...`
  - enter the URL of the package repository: `https://gitlab.varlab-internal.cecs.ucf.edu/lab-projects/external-display-plugin.git`

## Settings Files

The camera rigs are configured to replicate the display layout used by the VR system on a desktop monitor. In other words the camera rig does not use the window positions and sizes that the actual system needs, but ones that are useful for developing on a standalone workstation.
The actual window positions and sizes as well as calibration data (e.g. for the VDen or VRTable) are stored in settings files. This allows updating/editing the settings without rebuilding the application.
The settings file is stored in `Assets/StreamingAssets/VARLab_ExternalDisplay/settings.json` (Editor) or `{productName}_Data/StreamingAssets/VARLab_ExternalDisplay/settings.json` (Build). If the camera rig has a non-empty value for the `Settings File Suffix` field, the file name is adjusted: `settings.json` -> `settings_SUFFIX.json` where `SUFFIX` is replaced by the `Settings File Suffix` field value.
Details of the settings file are described in [Settings File Reference](settings_file_reference.md).

# Workflows

## Add a camera rig to the scene

The package comes with pre-configured camera rigs for the VR systems at VARLab, these are located in the folder `Packages/VARLab External Display/Assets/Prefabs`:

- `P_VDenCameraRig` for the VDen
- `P_VRTableCameraRig` for the VR Table
- `P_MicroLEDTileWallCameraRigMono` for the LED Wall in mono
- `P_MicroLEDTileWallCameraRigStereo` for the LED Wall in stereo

When entering "Play Mode" in the editor these prefabs by default use smaller windows to display the content then what the actual display system requires. This is intended to help with developing on a conventional desktop system while still getting a preview of what is rendered for the actual VR system. When testing/developing on the actual VR system you will usually want to use the same settings that are used for a build (that way full size windows will be used and you can test your application without needing to create a build first): In order to use the full resolution display windows copy the relevant settings file from

- `Packages/VARLab External Display/Assets/Settings/settings_XYZ.json`

to your project's Assets folder (make the folders if they don't exist yet)

- `Assets/StreamingAssets/VARLab_ExternalDisplay/settings_XYZ.json`

Here `XYZ` is a placeholder for the name of the display system (this is shown as `Settings File Suffix` in the Inspector of the ExternalDisplayCameraRig component). For example, the settings file for the VDen is called `settings_vden.json` and therefore `Settings File Suffix` field is set to `vden`. The settings files contain the full resolution settings. In order to enable their use in the Unity Editor Play Mode, check the `Apply Overrides in Editor` setting of the ExternalDisplayCameraRig component.
**NOTE:** Builds always use the values from the settings file.

## Tracking

### Project Configuration / Head Tracking
First you'll need to make sure your project is properly configured to take in the input from HTC Vive controllers and trackers. Go into Edit->Project Settings->XR Plug-in Management then enable OpenXR. From there, open the dropdown and click on "OpenXR". In the "enabled Interaction Profiles" section, click the '+' and add an HTC Vive Tracker Profile, and an HTC Vive Controller Profile. 

In the XR Plugin-in Management dropdown there is a project validation section. You can fix all the issues *except* for the one that says 'Switch to use InputSystem.XR.PoseControl instead of OpenXR.Input.PoseControl, which will be deprecated in a future release. '

After configuring, the head tracking should work, as the actions come with the camera rig prefab. 

### Head Tracking Details

The VDen and VR Table prefabs have support for head tracking (the `CameraOrigin` GameObject has a `RenderViewCameraOriginOpenXR` component), but they need to be configured to use the desired actions for position and rotation (and optionally tracking state) of the head tracker.
This feature makes use of the Unity Input System package (`com.unity.inputsystem`) and configuring actions for the `RenderViewCameraOriginOpenXR` component works the same as for the `TrackedPoseDriver (Input System)` component in that package. The [documentation](https://docs.unity3d.com/Packages/com.unity.inputsystem@1.8/manual/index.html) for the Input System package has details on how to do this.

**NOTE:** For tracking data from a XR plugin that does not utilize the Input System (e.g. OpenVR) a different implementation of a `RenderViewCameraOriginBase` derived component is required (i.e. it needs to be written).

### Tracked Controllers

The prefabs do not include tracked controllers, add them under the `TrackingOrigin` GameObject (i.e. as a sibling to the `CameraOrigin`). Make the controllers receive tracking data by adding a `TrackedPoseDriver (Input System)` component to it and configure the desired actions.

## Supporting a new display system

First determine the dimensions and placement of your displays in a common coordinate system (usually some easy to define point/corner of a display). Use this to define a hierarchy similar to the existing camera rig prefabs.
Each camera rig prefab has a corresponding `ExternalDisplayCameraRigXYZ` script (e.g. `ExternalDisplayCameraRigVRTable`). These scripts primarily contain the default values for the windows, cameras, warp meshes, and present infos. Therefore, for initial testing the base `ExternalDisplayCameraRig` script can be used and the information for windows, etc. entered manually in the Unity Inspector panel. After testing the values create a new `ExternalDisplayCameraRigXYZ` script for the display system that contains these values (see the existing scripts for examples).
You also need to ensure the cameras you create for your rig all render into appropriately sized render textures.

# Implementation Details

Information how the components in the package work can be found in [Implementation Details](implementation_details.md). These are _not_ necessary for using the package.
