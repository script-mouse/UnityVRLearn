# Settings File Reference

A settings file is a JSON file with the following top level properties (unless otherwise noted all properties are optional):

- windowOverrides: Array of [`WindowOverride`](#windowoverride-object)
- presentOverrides: Array of [`PresentInfoOverride`](#presentinfooverride-object)
- warpMeshOverrides: Array of [`WarpMeshOverride`](#warpmeshoverride-object)
- trackingOriginOverride: [`TrackingOriginOverride`](#trackingoriginoverride-object)
- renderScreenOverrides: Array of [`RenderScreenOverride`](#renderscreenoverride-object)
- sourceCameraInfoOverrides: Array of [`SourceCameraInfoOverride`](#sourcecamerainfooverride-object)

## WindowOverride object

Allows changing the position or size of a window configured in the camera rig. A `WindowOverride` is an object with properties:

- _name_ (required, String): must be the name of an existing window configued in the camera rig
- _position_ (Array of two integers): position of the window on the desktop (pixels)
- _size_ (Array of two integers): size of the window on the desktop (pixels)

## PresentInfoOverride object

Allows changing where content rendered by a camera is drawn for presentation. A `PresentInfoOverride` is an object with properties:

- _name_ (required, String): must be the name of an existing present info configured in the camera rig
- _targetWindow_ (String): name of the window to which the content is drawn
- _warpMesh_ (String): name of the warp mesh applied to the content when drawing
- _sourceCamera_ (String): name of the camera that renders the content to present
- _viewportCoordinateMode_ ("Normalized", "Pixel"): how values in the `viewportRect` property are interpreted
- _viewportRect_ ([Rect object](#rect-object)): viewport rectangle describing the area on the window where content is drawn

## WarpMeshOverride object

Allows changing the warping applied to content when drawing it to a window. A `WarpMeshOverride` is an object with properties:

- _name_ (required, String): must be the name of an existing warp mesh configured in the camera rig
- _style_ ("FullscreenQuad", "Linear", "Spline", "Homography", "MultiHomography"): determines the style of warping applied. For "FullscreenQuad" the region if the source camera's render texture given by `sourceRect` is directly drawn to the `viewportRect` (see [PresentInfoOverride](#presentinfooverride-object)). For the other styles a distortion described by the `controlPoints` is applied and the style controls the kind of interpolation that is used between the control points.
- _sourceResolution_ (Array of two integers): If `coordinateMode` is "Pixel" this is required, otherwise it is unused. Describes the resolution of the source render texture in order to allow converting pixel cooridintes to texture coordinates.
- _coordinateMode_ ("Normalized", "Pixel"): how values in `sourceRect` property are interpreted
- _sourceRect_ ([Rect object](#rect-object)): Area of the source render texture that is drawn with this warp mesh.
- _meshResolution_ (Array of two integers): resolution of the warp mesh (number of vertices per row/column) used for the distortion.
- _controlPoints_ ([WarpMeshControlPoints object](#warpmeshcontrolpoints-object)): Nine control points describing the distortion applied to the content.

## TrackingOriginOverride object

Allows changing the position/rotation of the tracking origin so that tracking and camera rig are in a common coordinate frame. A `TrackingOriginOverride` is an objec with properties:

- _positionOffset_ (Array of three Floats): local position of the tracking origin
- _rotationOffset_ (Array of three Floats): local rotation of the tracking origin (as euler angles)

## RenderScreenOverride object

Allows changing the position, rotation, and size of a `RenderScreen` configured in the camera rig. A `RenderScreenOverride` is an object with properties:

- _name_ (required, String): must be the name of an existing GameObject with a `RenderScreen` component in the camera rig
- _position_ (Array of three Float): local position of the render screen center
- _rotation_ (Array of three Float): local rotation of the render screen (as euler angles, degrees)
- _size_ (Array of two Floats): size of the render screen

## SourceCameraInfoOverride Object

Allows changing the IPD (interpupillary distance, distance between the eye positions) value.

- _name_ (required, string): must be the name of an existing GameObject with a 'Camera" component that is listed in the SourceCameraInfos array of the camera rig.
- _ipdValue_ (Float): interpupillary distance (meters)

## Rect object

Object describing a 2D rectangular region, has properties:

- _x_ (required, Float): x coordinate of corner
- _y_ (required, Float): y coordinate of corner
- _width_ (required, Float): width of the rectangle
- _height_ (required, Float): height of the rectangle

## WarpMeshControlPoints object

Object storing nine control points that define a warp mesh shape; has properties:

- _topLeft_ (required, Array of two Float): NDC coordinates of the top left corner of the mesh
- _top_ (required, Array of two Float): NDC coordinates of the midpoint of the top edge of the mesh
- _topRight_ (required, Array of two Float): NDC coordinates of the top right corner of the mesh
- _left_ (required, Array of two Float): NDC coordinates of the midpoint of the left edge of the mesh
- _center_ (required, Array of two Float): NDC coordinates of the center point of the mesh
- _right_ (required, Array of two Float): NDC coordinates of the midpoint of the right edge of the mesh
- _bottomLeft_ (required, Array of two Float): NDC coordinates of the bottom left corner of the mesh
- _bottom_ (required, Array of two Float): NDC coordinates of the midpoint of the bottom edge of the mesh
- _bottomRight_ (required, Array of two Float): NDC coordinates of the bottom right corner of the mesh
