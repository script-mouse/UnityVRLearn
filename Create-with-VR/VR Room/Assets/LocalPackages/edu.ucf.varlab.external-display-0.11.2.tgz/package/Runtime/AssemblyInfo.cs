
[assembly: System.Reflection.AssemblyCompany("VARLab - University of Central Florida")]
[assembly: System.Reflection.AssemblyTitle("VARLab.ExternalDisplay")]
[assembly: System.Reflection.AssemblyProduct("VARLab.ExternalDisplay")]
[assembly: System.Reflection.AssemblyVersion("0.3.0")]
