
// system namespaces
using System;
using System.Collections;
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Base class for calibrating the offset of the tracking coordinate system from the
    /// display system origin.
    /// </summary>
    public class BaseTrackingOriginCalibration
        : MonoBehaviour
    {
        // ------------------------------------------------------------------
        #region Types

        // Steps of the calibration
        public enum CalibrationStates
        {
            Start,

            PreRecordPoints,
            RecordPoint,
            PostRecordPoints,

            CalibrationSuccess,
            CalibrationFailedRestart,

            Complete,
        }

        #endregion // Types
        // ------------------------------------------------------------------
        #region Properties

        public event Action<CalibrationStates, CalibrationStates> onCalibrationStateChanged;

        public List<Pose> recordedPoses
        {
            get => m_recordedPoses;
        }

        public List<Pose> calibrationPoses
        {
            get => m_calibrationPoses;
        }

        public CalibrationStates calibrationState
        {
            get => m_stateMachine.State;
        }

        #endregion // Properties
        // ------------------------------------------------------------------

        [SerializeField]
        [Tooltip("Camera rig to calibrate")]
        protected ExternalDisplayCameraRig m_cameraRig;

        [SerializeField]
        [Tooltip("Reference points used for calibration.")]
        protected TrackingOriginCalibrationPoint[] m_calibrationPoints;

        [SerializeField]
        [Tooltip("UI the calibration uses to display information to the user")]
        protected BaseTrackingOriginCalibrationUI m_calibrationUI;

        protected TrackingOriginOverride m_trackingOriginOverride = new TrackingOriginOverride();
        protected CalibrationStateMachine m_stateMachine;
        protected List<Pose> m_recordedPoses = new List<Pose>(k_recordedPoseCount);
        protected List<Pose> m_calibrationPoses = new List<Pose>();
        protected int m_activeIdx = 0;
        protected int m_recordedPosesIndex = 0;
        protected bool m_calibrationValid = false;

        // number of poses to record
        protected const int k_recordedPoseCount = 100;

        // ------------------------------------------------------------------
        #region Types

        // State machine tracking progress through the calibration steps
        protected class CalibrationStateMachine
            : StateMachineBase<CalibrationStates>
        {
            protected BaseTrackingOriginCalibration m_owner;

            public CalibrationStateMachine(BaseTrackingOriginCalibration owner)
            {
                m_owner = owner;

                // Start -> CalibrationSuccess
                RegisterTransition(
                    CalibrationStates.Start, CalibrationStates.CalibrationSuccess,
                    m_owner.HandleStartSuccessTransition);

                RegisterTransition(
                    CalibrationStates.Start, CalibrationStates.PreRecordPoints,
                    m_owner.HandleStartPreRecordPointsTransition);

                // Step through recording of points, post recording and success/failure decision
                RegisterTransition(
                    CalibrationStates.PreRecordPoints, CalibrationStates.RecordPoint,
                    m_owner.HandlePreRecordPointsRecordPointTransition);
                RegisterTransition(
                    CalibrationStates.RecordPoint, CalibrationStates.RecordPoint,
                    m_owner.HandleRecordPointRecordPointTransition);
                RegisterTransition(
                    CalibrationStates.RecordPoint, CalibrationStates.PostRecordPoints,
                    m_owner.HandleRecordPointPostRecordPointsTransition);
                RegisterTransition(
                    CalibrationStates.PostRecordPoints, CalibrationStates.CalibrationSuccess,
                    m_owner.HandlePostRecordPointsCalibrationSuccessTransition);
                RegisterTransition(
                    CalibrationStates.PostRecordPoints, CalibrationStates.CalibrationFailedRestart,
                    m_owner.HandlePostRecordPointsCalibrationFailedRestartTransition);
                RegisterTransition(
                    CalibrationStates.CalibrationSuccess,
                    CalibrationStates.Complete,
                    m_owner.HandleCalibrationSuccessCompleteTransition);

                // Restart from any state (except complete)
                RegisterMultiTransition(new CalibrationStates[]
                    {
                        CalibrationStates.Start,
                        CalibrationStates.PreRecordPoints,
                        CalibrationStates.RecordPoint,
                        CalibrationStates.PostRecordPoints,
                        CalibrationStates.CalibrationSuccess,
                        CalibrationStates.CalibrationFailedRestart,
                    },
                    CalibrationStates.Start, m_owner.HandleAnyStartTransition);
            }
        }

        #endregion // Types
        // ------------------------------------------------------------------
        #region API

        public virtual void RecordPose(Pose pose)
        {
            Assert.IsTrue(IsRecordPointState(m_stateMachine.State));

            if (m_recordedPoses.Count < k_recordedPoseCount)
            {
                m_recordedPoses.Add(pose);
                m_calibrationUI.SetProgress(
                    (float)m_recordedPoses.Count / (k_recordedPoseCount - 1));
            }
            else
            {
                m_recordedPoses[m_recordedPosesIndex] = pose;
                m_recordedPosesIndex = (m_recordedPosesIndex + 1) % m_recordedPoses.Count;
            }
        }

        // Called when recording of poses end. If enough poses were recorded this will store
        // a calibration pose and advance the calibration state machine.
        public virtual void EndRecordPoses()
        {
            Assert.IsTrue(IsRecordPointState(m_stateMachine.State));

            if (m_recordedPoses.Count >= k_recordedPoseCount)
            {
                // store a calibration pose (derived from the recorded poses)
                Pose calibrationPose = CalcCalibrationPoseFromRecordedPoses();
                m_calibrationPoses.Add(calibrationPose);

                TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
                Transform trackingOrigin = m_cameraRig.trackingOrigin;
                Vector3 expectedPosition = CalcCalibrationPointPosition(activePoint, trackingOrigin);
                m_calibrationUI.SetDetailsText(
                    $"{activePoint.landmark} on '{activePoint.renderScreen.name}' at "
                    + $"({calibrationPose.position}), expected ({expectedPosition})");

                m_activeIdx += 1;

                if (m_activeIdx < m_calibrationPoints.Length)
                {
                    // record next point
                    m_stateMachine.Transition(CalibrationStates.RecordPoint);
                }
                else
                {
                    // all points recorded, finalize results
                    m_stateMachine.Transition(CalibrationStates.PostRecordPoints);
                }
            }
            else
            {
                // not enough poses recorded, clear and do not advance state machine
                m_recordedPoses.Clear();
            }

            m_calibrationUI.SetProgress(0.0f);
        }

        public virtual void SaveCalibration()
        {
            if (m_calibrationValid)
            {
                string settingsFilePath = SerializationUtils.GetSettingsFilePath(
                    m_cameraRig.settingsFileSuffix);

                // load existing settings (if any)
                if (!SerializationUtils.TryLoadSettings(
                    settingsFilePath, out ExternalDisplaySettings settings))
                {
                    settings = new ExternalDisplaySettings();
                }

                // update tracking origin override with calibrated one
                settings.trackingOriginOverride = m_trackingOriginOverride.Clone();

                // save updated settings
                bool success = SerializationUtils.TrySaveSettings(
                    settingsFilePath, settings, allowOverwrite: true, createBackup: true);

                if (success)
                {
                    m_calibrationUI.SetStatusText($"Calibration saved to '{settingsFilePath}'");
                }
                else
                {
                    m_calibrationUI.SetStatusText($"Failed to save calibration!");
                }
            }
            else
            {
                m_calibrationUI.SetStatusText("No valid calibration to save!");
            }
        }

        public virtual void NextScene()
        {
        }

        public static bool IsRecordPointState(CalibrationStates state)
        {
            return state == CalibrationStates.RecordPoint;
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            Assert.IsNotNull(m_cameraRig);
        }

        protected virtual void Start()
        {
            m_stateMachine = new CalibrationStateMachine(this);
            m_stateMachine.Transition(CalibrationStates.Start);
        }

        protected virtual void Update()
        {
            m_stateMachine.Update();
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected virtual void HandleStartSuccessTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandleStartPreRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationValid = false;
            m_recordedPoses.Clear();
            m_calibrationPoses.Clear();

            InvokeOnCalibrationStateChanged(sourceState, targetState);

            m_stateMachine.Transition(CalibrationStates.RecordPoint);
        }

        protected virtual void HandlePreRecordPointsRecordPointTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandleRecordPointRecordPointTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_recordedPoses.Clear();

            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandleRecordPointPostRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_recordedPoses.Clear();

            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandlePostRecordPointsCalibrationSuccessTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationValid = true;
            StartCoroutine(DelayTransitionCoro(CalibrationStates.Complete));

            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandlePostRecordPointsCalibrationFailedRestartTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationValid = false;
            m_recordedPoses.Clear();
            m_calibrationPoses.Clear();

            StartCoroutine(DelayTransitionCoro(CalibrationStates.Start));

            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandleAnyStartTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_recordedPoses.Clear();
            m_calibrationPoses.Clear();
            m_calibrationUI.SetDetailsText("");

            StartCoroutine(
                DelayTransitionCountdownCoro(
                    CalibrationStates.PreRecordPoints,
                    "Tracking Origin calibration starting in ", 3.0f));

            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected virtual void HandleCalibrationSuccessCompleteTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            InvokeOnCalibrationStateChanged(sourceState, targetState);
        }

        protected Pose CalcCalibrationPoseFromRecordedPoses()
        {
            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];

            switch (activePoint.postProcess)
            {
                case RecordPositionPostProcess.None:
                    return CalcCalibrationPosePostProcessNone();

                case RecordPositionPostProcess.ProjectRenderScreenNormal:
                    return CalcCalibrationPosePostProcessProjectRenderScreenNormal(activePoint);
            }

            Assert.IsTrue(
                false, $"Unhandled RecordPositionPostProcess value '{activePoint.postProcess}'!");
            return default;
        }

        protected Pose CalcCalibrationPosePostProcessNone()
        {
            Pose calibrationPose = new Pose();

            if (m_recordedPoses.Count > 0)
            {
                Vector3 sumPosition = Vector3.zero;
                Vector3 sumAxis = Vector3.zero;
                float sumAngle = 0.0f;

                for (int i = 0, iEnd = m_recordedPoses.Count; i < iEnd; ++i)
                {
                    sumPosition += m_recordedPoses[i].position;

                    m_recordedPoses[i].rotation.ToAngleAxis(out float angle, out Vector3 axis);
                    sumAxis += axis;
                    sumAngle += angle;
                }

                calibrationPose.position = sumPosition / m_recordedPoses.Count;
                calibrationPose.rotation = Quaternion.AngleAxis(
                    sumAngle / m_recordedPoses.Count, sumAxis / m_recordedPoses.Count);
            }

            return calibrationPose;
        }

        protected Pose CalcCalibrationPosePostProcessProjectRenderScreenNormal(
            TrackingOriginCalibrationPoint activePoint)
        {
            Pose calibrationPose = new Pose();

            if (m_recordedPoses.Count == 0)
                return calibrationPose;

            // plane of the render screen in trackingOrigin coordinate frame
            Transform trackingOrigin = m_cameraRig.trackingOrigin;
            Transform renderScreenTransform = activePoint.renderScreen.transform;
            Vector3 center = trackingOrigin.InverseTransformPoint(renderScreenTransform.position);
            Vector3 normal = trackingOrigin.InverseTransformDirection(renderScreenTransform.forward);
            Plane renderScreenPlane = new Plane(normal, center);

            Vector3 sumPosition = Vector3.zero;
            Vector3 sumAxis = Vector3.zero;
            float sumAngle = 0.0f;

            for (int i = 0, iEnd = m_recordedPoses.Count; i < iEnd; ++i)
            {
                // project recorded point to plane
                Vector3 projectedPosition = renderScreenPlane.ClosestPointOnPlane(
                    m_recordedPoses[i].position);

                sumPosition += projectedPosition;

                m_recordedPoses[i].rotation.ToAngleAxis(out float angle, out Vector3 axis);
                sumAxis += axis;
                sumAngle += angle;
            }

            calibrationPose.position = sumPosition / m_recordedPoses.Count;
            calibrationPose.rotation = Quaternion.AngleAxis(
                sumAngle / m_recordedPoses.Count, sumAxis / m_recordedPoses.Count);

            return calibrationPose;
        }

        protected void InvokeOnCalibrationStateChanged(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            onCalibrationStateChanged?.Invoke(sourceState, targetState);
        }

        protected IEnumerator DelayTransitionCountdownCoro(
            CalibrationStates nextState, string message, float delay)
        {
            int steps = Mathf.FloorToInt(delay);

            for (int i = 0; i < steps; ++i)
            {
                m_calibrationUI.SetStatusText($"{message} {steps - i}...");
                yield return new WaitForSeconds(1.0f);
            }

            m_stateMachine.Transition(nextState);
        }

        protected IEnumerator DelayTransitionCoro(CalibrationStates nextState)
        {
            yield return new WaitForSeconds(5.0f);
            m_stateMachine.Transition(nextState);
        }

        protected static Vector3 CalcCalibrationPointPosition(
            TrackingOriginCalibrationPoint calibrationPoint, Transform trackingOrigin)
        {
            RenderScreen renderScreen = calibrationPoint.renderScreen;
            Transform screenTransform = renderScreen.transform;
            Vector3 cornerPoint = Vector3.zero;

            switch (calibrationPoint.landmark)
            {
                case ScreenLandmark.TopLeftCorner:
                    cornerPoint = new Vector3(
                        -0.5f * renderScreen.size.x, 0.5f * renderScreen.size.y, 0.0f);
                    break;

                case ScreenLandmark.TopRightCorner:
                    cornerPoint = new Vector3(
                            0.5f * renderScreen.size.x, 0.5f * renderScreen.size.y, 0.0f);
                    break;

                case ScreenLandmark.BottomLeftCorner:
                    cornerPoint = new Vector3(
                        -0.5f * renderScreen.size.x, -0.5f * renderScreen.size.y, 0.0f);
                    break;

                case ScreenLandmark.BottomRightCorner:
                    cornerPoint = new Vector3(
                        0.5f * renderScreen.size.x, -0.5f * renderScreen.size.y, 0.0f);
                    break;

                case ScreenLandmark.Center:
                    // nothing to do
                    break;
            }

            cornerPoint += calibrationPoint.offset;

            return MathUtils.TransformPoint(screenTransform, trackingOrigin, cornerPoint);
        }

        protected static bool ValidateCalibrationPoses(
            List<Pose> calibrationPoses, TrackingOriginCalibrationPoint[] calibrationPoints,
            ExternalDisplayCameraRig cameraRig, BaseTrackingOriginCalibrationUI calibrationUI)
        {
            if (calibrationPoses.Count != calibrationPoints.Length)
            {
                calibrationUI.SetStatusText(
                    $"Number of recorded poses ({calibrationPoses.Count}) does not "
                    + $"match number of calibration points ({calibrationPoints.Length}).");
                return false;
            }

            Transform trackingOrigin = cameraRig.trackingOrigin;

            for (int i = 0, iEnd = calibrationPoints.Length; i < iEnd; ++i)
            {
                TrackingOriginCalibrationPoint pointI = calibrationPoints[i];
                Vector3 expectedI = CalcCalibrationPointPosition(pointI, trackingOrigin);
                Vector3 actualI = calibrationPoses[i].position;

                for (int j = i + 1, jEnd = iEnd; j < jEnd; ++j)
                {
                    TrackingOriginCalibrationPoint pointJ = calibrationPoints[j];
                    Vector3 expectedJ = CalcCalibrationPointPosition(pointJ, trackingOrigin);
                    Vector3 actualJ = calibrationPoses[j].position;

                    float expectedDist = Vector3.Distance(expectedI, expectedJ);
                    float actualDist = Vector3.Distance(actualI, actualJ);

                    if (Mathf.Abs(actualDist - expectedDist) > 0.1f * expectedDist)
                    {
                        SetValidationFailMessage(
                            calibrationUI, pointI, pointJ, expectedDist, actualDist,
                            expectedI, expectedJ, actualI, actualJ);
                        return false;
                    }
                }
            }

            return true;
        }

        protected static void SetValidationFailMessage(
            BaseTrackingOriginCalibrationUI calibrationUI, TrackingOriginCalibrationPoint pointI,
            TrackingOriginCalibrationPoint pointJ, float expectedDist, float actualDist,
            Vector3 expectedI, Vector3 expectedJ, Vector3 actualI, Vector3 actualJ)
        {
            string validationMessage =
                $"Distance between {pointI.landmark} "
                + $"{(pointI.offset != Vector3.zero ? $"+ {pointI.offset}" : "")}"
                + $"on screen '{pointI.renderScreen.name}' and "
                + $"{pointJ.landmark} {(pointJ.offset != Vector3.zero ? $"+ {pointJ.offset} " : "")}"
                + $"on screen '{pointJ.renderScreen.name}' is {actualDist:F3} which is "
                + $"outside range [{0.9f * expectedDist:F3}, {1.1f * expectedDist:F3}]. "
                + $"Expected ({pointI.renderScreen.name} {pointI.landmark}) {expectedI} "
                + $" and ({pointJ.renderScreen.name} {pointJ.landmark}) {expectedJ} "
                + $" actual {actualI} and {actualJ}";

            Debug.LogWarning(validationMessage);
            calibrationUI.SetStatusText(validationMessage);
        }
    }

} // namespace VARLab.ExternalDisplay
