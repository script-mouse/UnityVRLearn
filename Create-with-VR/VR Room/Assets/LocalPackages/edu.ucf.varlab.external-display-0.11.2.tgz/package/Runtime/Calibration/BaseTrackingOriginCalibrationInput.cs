
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public abstract class BaseTrackingOriginCalibrationInput
        : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Calibration receiving input")]
        protected BaseTrackingOriginCalibration m_calibration;

        [SerializeField]
        [Tooltip("UI displaying calibration progress/info")]
        protected BaseTrackingOriginCalibrationUI m_calibrationUI;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            Assert.IsNotNull(m_calibration);
            Assert.IsNotNull(m_calibrationUI);
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
