
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.UI;
// external namespaces
using TMPro;

namespace VARLab.ExternalDisplay
{
    public abstract class BaseTrackingOriginCalibrationUI
        : MonoBehaviour
    {
        public enum ControllerStatus
        {
            Recording,
            RecordingTrackingLost,
            Idle,
            IdleTrackingTost,
        }

        [SerializeField]
        [Tooltip("Camera rig for the calibration")]
        protected ExternalDisplayCameraRig m_cameraRig = null;

        [SerializeField]
        [Tooltip("")]
        protected Image[] m_controllerStatusImages;

        protected Canvas m_canvas = null;
        protected TextMeshProUGUI m_statusText = null;
        protected TextMeshProUGUI m_detailsText = null;
        protected Image m_cornerMarkerImage = null;
        protected Slider m_progressSlider = null;

        protected static readonly Color k_colorRecording = Color.red;
        protected static readonly Color k_colorRecordingTrackingLost = Color.yellow;
        protected static readonly Color k_colorIdle = Color.green;
        protected static readonly Color k_colorIdleTrackingLost = Color.gray;

        // ------------------------------------------------------------------
        #region API

        public abstract void SetMarker(TrackingOriginCalibrationPoint calibrationPoint);

        public virtual void SetControllerStatus(int controllerIdx, ControllerStatus status)
        {
            Assert.IsTrue(controllerIdx < m_controllerStatusImages.Length);
            Image statusImage = m_controllerStatusImages[controllerIdx];

            switch (status)
            {
                case ControllerStatus.Recording:
                    statusImage.color = k_colorRecording;
                    break;

                case ControllerStatus.RecordingTrackingLost:
                    statusImage.color = k_colorRecordingTrackingLost;
                    break;

                case ControllerStatus.Idle:
                    statusImage.color = k_colorIdle;
                    break;

                case ControllerStatus.IdleTrackingTost:
                    statusImage.color = k_colorIdleTrackingLost;
                    break;
            }
        }

        public virtual void SetProgress(float progress)
        {
            if (progress >= 0.0f)
            {
                m_progressSlider.enabled = true;
                m_progressSlider.value = progress;
            }
            else
            {
                m_progressSlider.enabled = false;
            }
        }

        public virtual void SetStatusText(string text)
        {
            m_statusText.text = text;
        }

        public virtual void SetDetailsText(string text)
        {
            m_detailsText.text = text;
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            Assert.IsNotNull(m_cameraRig);

            m_canvas = GetComponent<Canvas>();
            Assert.IsNotNull(m_canvas);

            m_statusText = MonoBehaviourUtils.GetChildComponent<TextMeshProUGUI>(
                m_canvas.gameObject, "StatusText");
            Assert.IsNotNull(m_statusText);

            m_detailsText = MonoBehaviourUtils.GetChildComponent<TextMeshProUGUI>(
                m_canvas.gameObject, "DetailsText");

            m_cornerMarkerImage = MonoBehaviourUtils.GetChildComponent<Image>(
                m_canvas.gameObject, "CornerMakerImage");
            Assert.IsNotNull(m_cornerMarkerImage);

            m_progressSlider = MonoBehaviourUtils.GetChildComponent<Slider>(
                m_canvas.gameObject, "ProgressSlider");
            Assert.IsNotNull(m_progressSlider);
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
