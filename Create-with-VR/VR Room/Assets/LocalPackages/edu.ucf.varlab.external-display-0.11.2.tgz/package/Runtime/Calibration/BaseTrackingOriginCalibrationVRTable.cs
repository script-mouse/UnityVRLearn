
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public abstract class BaseTrackingOriginCalibrationVRTable
        : BaseTrackingOriginCalibration
    {
        // ------------------------------------------------------------------
        #region API

        public override void RecordPose(Pose pose)
        {
            base.RecordPose(pose);

            float progress = (float)m_recordedPoses.Count / k_recordedPoseCount;
            m_calibrationUI.SetProgress(progress);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            // must have 4 calibration points
            Assert.AreEqual(4, m_calibrationPoints.Length);
        }

        protected void Reset()
        {
            RenderScreen horizontalScreen = null;
            RenderScreen verticalScreen = null;

            m_cameraRig = FindFirstObjectByType<ExternalDisplayCameraRigVRTable>();

            if (m_cameraRig != null)
            {
                horizontalScreen = MonoBehaviourUtils.GetChildComponent<RenderScreen>(
                    m_cameraRig.gameObject, "HorizontalOrigin");
                verticalScreen = MonoBehaviourUtils.GetChildComponent<RenderScreen>(
                    m_cameraRig.gameObject, "VerticalOrigin");
            }

            m_calibrationPoints = new TrackingOriginCalibrationPoint[4]
            {
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = horizontalScreen,
                    landmark = ScreenLandmark.BottomLeftCorner,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = verticalScreen,
                    landmark = ScreenLandmark.TopLeftCorner,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = verticalScreen,
                    landmark = ScreenLandmark.TopRightCorner,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = horizontalScreen,
                    landmark = ScreenLandmark.BottomRightCorner,
                },
            };
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region BaseTrackingOriginCalibration

        protected override void HandleStartPreRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[0];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleStartPreRecordPointsTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointRecordPointTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            Assert.IsTrue(m_activeIdx < m_calibrationPoints.Length);

            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleRecordPointRecordPointTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointPostRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationUI.SetMarker(null);
            m_calibrationUI.SetProgress(-1.0f);

            if (!ValidateCalibrationPoses(
                m_calibrationPoses, m_calibrationPoints, m_cameraRig, m_calibrationUI))
            {
                base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
                m_stateMachine.Transition(CalibrationStates.CalibrationFailedRestart);
                return;
            }

            base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
            m_stateMachine.Transition(CalibrationStates.CalibrationSuccess);
        }

        protected override void HandlePostRecordPointsCalibrationSuccessTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            // m_calibrationPoses was already validated, just calculate the resulting offsets
            CalcTrackingOriginOffset(out Vector3 positionOffset, out Quaternion rotationOffset);

            m_trackingOriginOverride
                = SettingsUtils.CreateTrackingOriginOverride(m_cameraRig);
            m_trackingOriginOverride.positionOffset = positionOffset;
            m_trackingOriginOverride.rotationOffset = rotationOffset;

            m_cameraRig.ApplyTrackingOriginOverride(m_trackingOriginOverride.Clone());

            base.HandlePostRecordPointsCalibrationSuccessTransition(
                sourceState, targetState);
        }

        protected override void HandleCalibrationSuccessCompleteTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationUI.SetStatusText("Calibration completed.");

            base.HandleCalibrationSuccessCompleteTransition(sourceState, targetState);
        }

        #endregion // BaseTrackingOriginCalibration
        // ------------------------------------------------------------------

        private void SetCalibrateLandmarkMessage(TrackingOriginCalibrationPoint activePoint)
        {
            m_calibrationUI.SetStatusText(
                $"Move controller to <b>{activePoint.landmark}</b> "
                + $"{(activePoint.offset != Vector3.zero ? $"+ {activePoint.offset} " : "")}"
                + $"on screen <b>{activePoint.renderScreen.name}</b> and hold trigger");
        }

        protected abstract void CalcTrackingOriginOffset(
            out Vector3 positionOffset, out Quaternion rotationOffset);

        protected void CalcTrackingOriginOffset(
            Transform trackingOrigin, out Vector3 positionOffset, out Quaternion rotationOffset)
        {
            Vector3 offset = Vector3.zero;

            for (int i = 0, iEnd = m_calibrationPoints.Length; i < iEnd; ++i)
            {
                TrackingOriginCalibrationPoint point = m_calibrationPoints[i];
                Vector3 expectedPos = CalcCalibrationPointPosition(point, trackingOrigin);
                Vector3 actualPos = m_calibrationPoses[i].position;

                offset += expectedPos - actualPos;
            }

            positionOffset = offset / m_calibrationPoints.Length;
            rotationOffset = Quaternion.identity;
        }
    }

} // namespace VARLab.ExternalDisplay
