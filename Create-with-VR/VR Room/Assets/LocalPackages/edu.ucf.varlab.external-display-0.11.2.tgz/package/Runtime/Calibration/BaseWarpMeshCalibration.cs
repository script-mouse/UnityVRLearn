
// system namespaces
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public enum WarpControlPointId
    {
        TopLeft,
        Top,
        TopRight,

        Left,
        Center,
        Right,

        BottomLeft,
        Bottom,
        BottomRight,

        // Artificial values
        None = -1,
        All = -2
    }

    public abstract class BaseWarpMeshCalibration
        : MonoBehaviour
    {
        // ------------------------------------------------------------------
        #region Types

        public enum Mode
        {
            SelectControlPoint,
            MoveControlPoint,
        }

        public struct CursorPosition
        {
            public string meshName;
            public WarpControlPointId controlPointId;
        }

        #endregion // Types
        // ------------------------------------------------------------------
        #region Properties

        public Mode mode
        {
            get => m_mode;
        }

        public CursorPosition cursor
        {
            get => m_cursor;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        [SerializeField]
        protected ExternalDisplayCameraRig m_cameraRig;

        protected Mode m_mode = Mode.SelectControlPoint;
        protected CursorPosition m_cursor = new CursorPosition()
        {
            meshName = string.Empty,
            controlPointId = WarpControlPointId.TopLeft,
        };

        protected ExternalDisplaySettings m_settings;

        // bounds that limit control point values
        protected static readonly Vector2 k_limitMin = new Vector2(-1.2f, -1.2f);
        protected static readonly Vector2 k_limitMax = new Vector2(1.2f, 1.2f);

        #endregion // Fields
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            Assert.IsNotNull(m_cameraRig);
        }

        protected virtual void Start()
        {
            InitializeSettings();
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region API

        public virtual void SetControlPointActive(bool active)
        {
            if (active)
            {
                Assert.AreEqual(Mode.SelectControlPoint, m_mode);
                m_mode = Mode.MoveControlPoint;
            }
            else
            {
                Assert.AreNotEqual(Mode.SelectControlPoint, m_mode);
                m_mode = Mode.SelectControlPoint;
            }
        }

        public virtual void MoveActiveControlPoint(Vector2 step)
        {
            Vector2 value = GetControlPoint(m_cursor);
            value = new Vector2(
                Math.Clamp(value.x + step.x, k_limitMin.x, k_limitMax.x),
                Math.Clamp(value.y + step.y, k_limitMin.y, k_limitMax.y));
            SetControlPoint(m_cursor, value);

            m_cameraRig.ApplyWarpMeshOverrides(m_settings.warpMeshOverrides);
        }

        // Returns new cursor position after applying a move
        public abstract void MoveCursorUp(CursorPosition cursorPosition);
        public abstract void MoveCursorDown(CursorPosition cursorPosition);
        public abstract void MoveCursorLeft(CursorPosition cursorPosition);
        public abstract void MoveCursorRight(CursorPosition cursorPosition);

        public virtual void SetWarpMeshStyle(string warpMeshName, WarpMeshStyle meshStyle)
        {
            WarpMeshOverride warpMeshOverride
                = PluginUtils.FindWarpMeshOverride(m_settings.warpMeshOverrides, warpMeshName);

            warpMeshOverride.style = meshStyle;

            m_cameraRig.ApplyWarpMeshOverrides(m_settings.warpMeshOverrides);
        }

        public virtual void SaveCalibration()
        {
            string settingsFilePath = SerializationUtils.GetSettingsFilePath(
                m_cameraRig.settingsFileSuffix);

            // load existing settings (if any)
            if (!SerializationUtils.TryLoadSettings(
                settingsFilePath, out ExternalDisplaySettings settings))
            {
                settings = new ExternalDisplaySettings();
            }

            // replace warp mesh and present info overrides with active values
            settings.warpMeshOverrides = m_cameraRig.GetWarpMeshOverrides(includeUnchanged: false);
            settings.presentOverrides
                = m_cameraRig.GetPresentInfoOverrides(includeUnchanged: false);

            // save updated settings
            SerializationUtils.TrySaveSettings(
                settingsFilePath, settings, allowOverwrite: true, createBackup: true);
        }

        public virtual void NextScene()
        {
        }

        #endregion // API
        // ------------------------------------------------------------------

        protected Vector2 GetControlPoint(CursorPosition cursorPosition)
        {
            return GetControlPoint(cursorPosition.meshName, cursorPosition.controlPointId);
        }

        protected Vector2 GetControlPoint(string warpMeshName, WarpControlPointId controlPointId)
        {
            // must not be an artificial control point
            Assert.IsTrue((int)controlPointId >= 0);
            WarpMeshOverride warpMeshOverride
                = PluginUtils.FindWarpMeshOverride(m_settings.warpMeshOverrides, warpMeshName);
            Assert.IsNotNull(warpMeshOverride);

            switch (controlPointId)
            {
                case WarpControlPointId.TopLeft:
                    return warpMeshOverride.controlPoints.topLeft;

                case WarpControlPointId.Top:
                    return warpMeshOverride.controlPoints.top;

                case WarpControlPointId.TopRight:
                    return warpMeshOverride.controlPoints.topRight;

                case WarpControlPointId.Left:
                    return warpMeshOverride.controlPoints.left;

                case WarpControlPointId.Center:
                    return warpMeshOverride.controlPoints.center;

                case WarpControlPointId.Right:
                    return warpMeshOverride.controlPoints.right;

                case WarpControlPointId.BottomLeft:
                    return warpMeshOverride.controlPoints.bottomLeft;

                case WarpControlPointId.Bottom:
                    return warpMeshOverride.controlPoints.bottom;

                case WarpControlPointId.BottomRight:
                    return warpMeshOverride.controlPoints.bottomRight;

                default:
                    Assert.IsTrue(false, $"Invalid WarpControlPointId '{controlPointId}'!");
                    break;
            }

            return Vector2.zero;
        }

        protected void SetControlPoint(CursorPosition cursorPosition, Vector2 value)
        {
            SetControlPoint(cursorPosition.meshName, cursorPosition.controlPointId, value);
        }

        protected void SetControlPoint(
            string meshName, WarpControlPointId controlPointId, Vector2 value)
        {
            // must not be an artificial control point
            Assert.IsTrue((int)controlPointId >= 0);
            WarpMeshOverride warpMeshOverride
                = PluginUtils.FindWarpMeshOverride(m_settings.warpMeshOverrides, meshName);
            Assert.IsNotNull(warpMeshOverride);

            switch (controlPointId)
            {
                case WarpControlPointId.TopLeft:
                    warpMeshOverride.controlPoints.topLeft = value;
                    break;

                case WarpControlPointId.Top:
                    warpMeshOverride.controlPoints.top = value;
                    break;

                case WarpControlPointId.TopRight:
                    warpMeshOverride.controlPoints.topRight = value;
                    break;

                case WarpControlPointId.Left:
                    warpMeshOverride.controlPoints.left = value;
                    break;

                case WarpControlPointId.Center:
                    warpMeshOverride.controlPoints.center = value;
                    break;

                case WarpControlPointId.Right:
                    warpMeshOverride.controlPoints.right = value;
                    break;

                case WarpControlPointId.BottomLeft:
                    warpMeshOverride.controlPoints.bottomLeft = value;
                    break;

                case WarpControlPointId.Bottom:
                    warpMeshOverride.controlPoints.bottom = value;
                    break;

                case WarpControlPointId.BottomRight:
                    warpMeshOverride.controlPoints.bottomRight = value;
                    break;

                default:
                    Assert.IsTrue(false, $"Invalid WarpControlPointId '{controlPointId}'!");
                    break;
            }
        }

        protected void InitializeSettings()
        {
            string settingsFilePath = SerializationUtils.GetSettingsFilePath(
                m_cameraRig.settingsFileSuffix);

            // load existing settings (if any)
            if (!SerializationUtils.TryLoadSettings(settingsFilePath, out m_settings))
            {
                m_settings = new ExternalDisplaySettings();
            }

            IList<WarpMeshInfo> warpMeshInfos = m_cameraRig.warpMeshInfos;

            if (m_settings.warpMeshOverrides.Count != warpMeshInfos.Count)
            {
                // Make sure number of warpMeshOverrides matches number of warpMeshInfos
                IList<WarpMeshOverride> warpMeshOverrides = m_settings.warpMeshOverrides;
                warpMeshOverrides.Clear();

                for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
                {
                    WarpMeshInfo warpMeshInfo = warpMeshInfos[i];
                    warpMeshOverrides.Add(new WarpMeshOverride()
                    {
                        name = warpMeshInfo.name,
                        style = warpMeshInfo.warpStyle,
                        meshResolution = warpMeshInfo.meshResolution,
                        controlPoints = warpMeshInfo.controlPoints.Clone(),
                    });
                }
            }
        }

        // Helper to apply settings after a short delay (so that camera rig Start has run)
        protected IEnumerator DelayApplySettingsCoro()
        {
            // wait one frame
            yield return null;

            // apply settings
            m_cameraRig.ApplyWarpMeshOverrides(m_settings.warpMeshOverrides);
        }

        protected static bool IsTopRow(WarpControlPointId controlPointId)
        {
            return (controlPointId == WarpControlPointId.TopLeft
                || controlPointId == WarpControlPointId.Top
                || controlPointId == WarpControlPointId.TopRight);
        }

        protected static bool IsBottomRow(WarpControlPointId controlPointId)
        {
            return (controlPointId == WarpControlPointId.BottomLeft
                || controlPointId == WarpControlPointId.Bottom
                || controlPointId == WarpControlPointId.BottomRight);
        }

        protected static bool IsLeftColumn(WarpControlPointId controlPointId)
        {
            return (controlPointId == WarpControlPointId.TopLeft
                || controlPointId == WarpControlPointId.Left
                || controlPointId == WarpControlPointId.BottomLeft);
        }

        protected static bool IsRightColumn(WarpControlPointId controlPointId)
        {
            return (controlPointId == WarpControlPointId.TopRight
                || controlPointId == WarpControlPointId.Right
                || controlPointId == WarpControlPointId.BottomRight);
        }

        protected static WarpMeshInfo[] FindAllWarpMeshInfos(
            ReadOnlyCollection<WarpMeshInfo> warpMeshInfos, string name)
        {
            int count = 0;

            for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
            {
                if (warpMeshInfos[i].name.Equals(name))
                    ++count;
            }

            WarpMeshInfo[] foundWarpMeshInfos = new WarpMeshInfo[count];
            count = 0;

            for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
            {
                if (warpMeshInfos[i].name.Equals(name))
                {
                    foundWarpMeshInfos[count++] = warpMeshInfos[i];

                    if (count == foundWarpMeshInfos.Length)
                        break;
                }
            }

            return foundWarpMeshInfos;
        }
    }

} // namespace VARLab.ExternalDisplay
