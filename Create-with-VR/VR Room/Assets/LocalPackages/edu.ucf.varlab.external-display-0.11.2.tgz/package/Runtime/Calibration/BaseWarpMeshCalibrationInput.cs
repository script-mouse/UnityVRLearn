
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public abstract class BaseWarpMeshCalibrationInput
        : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Calibration receiving input (default: same GameObject)")]
        protected BaseWarpMeshCalibration m_calibration;

        protected const float k_normalStep = 0.01f;
        protected const float k_smallStep = 0.001f;
        protected const float k_largeStep = 0.05f;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            if (m_calibration == null)
                m_calibration = GetComponent<BaseWarpMeshCalibration>();
            Assert.IsNotNull(m_calibration);
        }

        protected virtual void Update()
        {
            switch (m_calibration.mode)
            {
                case BaseWarpMeshCalibration.Mode.SelectControlPoint:
                    UpdateSelectControlPoint();
                    break;

                case BaseWarpMeshCalibration.Mode.MoveControlPoint:
                    UpdateMoveControlPoint();
                    break;
            }
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected virtual void UpdateSelectControlPoint()
        {
        }

        protected virtual void UpdateMoveControlPoint()
        {
        }
    }

} // namespace VARLab.ExternalDisplay
