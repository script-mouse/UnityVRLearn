// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

namespace VARLab.ExternalDisplay
{
    public class InputSystemTrackingOriginCalibrationInput
        : BaseTrackingOriginCalibrationInput
    {
        // ------------------------------------------------------------------
        #region Types

        [Serializable]
        public class ControllerInput
        {
            public InputActionProperty recordAction
            {
                get => m_recordAction;
            }

            public InputActionProperty positionAction
            {
                get => m_positionAction;
            }

            public InputActionProperty rotationAction
            {
                get => m_rotationAction;
            }

            public InputActionProperty trackingStateAction
            {
                get => m_trackingStateAction;
            }

            public bool ignoreTrackingState
            {
                get => m_ignoreTrackingState;
            }

            [SerializeField]
            internal InputActionProperty m_recordAction;

            [SerializeField]
            internal InputActionProperty m_positionAction;

            [SerializeField]
            internal InputActionProperty m_rotationAction;

            [SerializeField]
            internal InputActionProperty m_trackingStateAction;

            [SerializeField]
            internal bool m_ignoreTrackingState;

            [NonSerialized]
            internal Action<InputAction.CallbackContext> m_recordPerformedHandler;

            [NonSerialized]
            internal Action<InputAction.CallbackContext> m_recordCanceledHandler;
        }

        #endregion // Types
        // ------------------------------------------------------------------ 

        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        private InputActionAsset m_inputAsset;

        [Header("Calibration Control")]

        [SerializeField]
        private InputActionProperty m_saveAction;

        [SerializeField]
        private InputActionProperty m_nextSceneAction;

        [Header("Tracked Controllers")]

        [SerializeField]
        private ControllerInput[] m_inputs;

        // index into m_inputs if recording that controller
        private int m_recordingIdx = -1;

        // action names, used to lookup actions in m_inputAsset if they are not configured
        // in the scene
        private const string k_saveActionName = "TrackingOriginCalibration/SaveSettings";
        private const string k_nextSceneActionName = "TrackingOriginCalibration/NextScene";

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(ref m_saveAction, m_inputAsset, k_saveActionName);
                InputSystemUtils.LookupAction(
                    ref m_nextSceneAction, m_inputAsset, k_nextSceneActionName);
            }
        }

        protected void OnEnable()
        {
            for (int i = 0, iEnd = m_inputs.Length; i < iEnd; ++i)
            {
                int inputIdx = i;

                m_inputs[i].m_recordPerformedHandler
                    = (InputAction.CallbackContext context) =>
                    {
                        HandleRecordPerformed(inputIdx, context);
                    };
                m_inputs[i].m_recordCanceledHandler
                    = (InputAction.CallbackContext context) =>
                    {
                        HandleRecordCanceled(inputIdx, context);
                    };

                InputSystemUtils.ConnectPerformedHandler(
                    ref m_inputs[i].m_recordAction, m_inputs[i].m_recordPerformedHandler);
                InputSystemUtils.ConnectCanceledHandler(
                    ref m_inputs[i].m_recordAction, m_inputs[i].m_recordCanceledHandler);

                InputSystemUtils.EnableAction(ref m_inputs[i].m_positionAction);
                InputSystemUtils.EnableAction(ref m_inputs[i].m_rotationAction);
                InputSystemUtils.EnableAction(ref m_inputs[i].m_trackingStateAction);
            }

            InputSystemUtils.ConnectPerformedHandler(ref m_saveAction, HandleSavePerformed);
            InputSystemUtils.ConnectPerformedHandler(ref m_nextSceneAction, HandleNextScenePerformed);
        }

        protected void OnDisable()
        {
            for (int i = 0, iEnd = m_inputs.Length; i < iEnd; ++i)
            {
                InputSystemUtils.DisconnectPerformedHandler(
                    ref m_inputs[i].m_recordAction, m_inputs[i].m_recordPerformedHandler);
                InputSystemUtils.DisconnectCanceledHandler(
                    ref m_inputs[i].m_recordAction, m_inputs[i].m_recordCanceledHandler);
                m_inputs[i].m_recordPerformedHandler = null;
                m_inputs[i].m_recordCanceledHandler = null;

                InputSystemUtils.DisableAction(ref m_inputs[i].m_positionAction);
                InputSystemUtils.DisableAction(ref m_inputs[i].m_rotationAction);
                InputSystemUtils.DisableAction(ref m_inputs[i].m_trackingStateAction);
            }

            InputSystemUtils.DisconnectPerformedHandler(ref m_saveAction, HandleSavePerformed);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_nextSceneAction, HandleNextScenePerformed);
        }

        protected void Update()
        {
            if (m_recordingIdx >= 0)
            {
                ControllerInput input = m_inputs[m_recordingIdx];

                int trackedState = input.m_trackingStateAction.action.ReadValue<int>();
                bool positionValid
                    = input.m_ignoreTrackingState
                    || (trackedState & (int)InputTrackingState.Position) != 0;
                bool rotationValid
                    = input.m_ignoreTrackingState
                    || (trackedState & (int)InputTrackingState.Rotation) != 0;

                if (positionValid && rotationValid)
                {
                    Vector3 position = input.m_positionAction.action.ReadValue<Vector3>();
                    Quaternion rotation = input.m_rotationAction.action.ReadValue<Quaternion>();

                    m_calibration.RecordPose(new Pose(position, rotation));
                }
            }

            for (int i = 0, iEnd = m_inputs.Length; i < iEnd; ++i)
            {
                ControllerInput input = m_inputs[i];
                int trackedState = input.m_trackingStateAction.action.ReadValue<int>();
                bool positionValid
                    = input.m_ignoreTrackingState
                    || (trackedState & (int)InputTrackingState.Position) != 0;
                bool rotationValid
                    = input.m_ignoreTrackingState
                    || (trackedState & (int)InputTrackingState.Rotation) != 0;

                if (positionValid && rotationValid)
                {
                    if (i == m_recordingIdx)
                    {
                        m_calibrationUI.SetControllerStatus(
                            i, BaseTrackingOriginCalibrationUI.ControllerStatus.Recording);
                    }
                    else
                    {
                        m_calibrationUI.SetControllerStatus(
                            i, BaseTrackingOriginCalibrationUI.ControllerStatus.Idle);
                    }
                }
                else
                {
                    if (i == m_recordingIdx)
                    {
                        m_calibrationUI.SetControllerStatus(
                            i,
                            BaseTrackingOriginCalibrationUI.ControllerStatus.RecordingTrackingLost);
                    }
                    else
                    {
                        m_calibrationUI.SetControllerStatus(
                            i,
                            BaseTrackingOriginCalibrationUI.ControllerStatus.IdleTrackingTost);
                    }
                }
            }
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        private void HandleSavePerformed(InputAction.CallbackContext context)
        {
            m_calibration.SaveCalibration();
        }

        private void HandleNextScenePerformed(InputAction.CallbackContext context)
        {
            m_calibration.NextScene();
        }

        private void HandleRecordPerformed(int inputIdx, InputAction.CallbackContext context)
        {
            if (m_recordingIdx == -1
                && BaseTrackingOriginCalibration.IsRecordPointState(m_calibration.calibrationState))
            {
                m_recordingIdx = inputIdx;
            }
        }

        private void HandleRecordCanceled(int inputIdx, InputAction.CallbackContext context)
        {
            if (m_recordingIdx == inputIdx
                && BaseTrackingOriginCalibration.IsRecordPointState(m_calibration.calibrationState))
            {
                m_recordingIdx = -1;
                m_calibration.EndRecordPoses();
            }
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
