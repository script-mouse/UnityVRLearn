// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Uses Input System (com.unity.inputsystem package) as input for warp mesh calibration.
    /// </summary>
    public class InputSystemWarpMeshCalibationInput
        : BaseWarpMeshCalibrationInput
    {
        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        private InputActionAsset m_inputAsset;

        [Header("Calibration Control")]

        [SerializeField]
        private InputActionProperty m_save;

        [SerializeField]
        private InputActionProperty m_nextScene;

        [Header("Cursor/Control Point Motion")]

        [SerializeField]
        private InputActionProperty m_select;

        [SerializeField]
        private InputActionProperty m_stepMove;

        [SerializeField]
        private InputActionProperty m_smoothMove;

        [SerializeField]
        private InputActionProperty m_slowModifier;

        [SerializeField]
        private InputActionProperty m_fastModifier;

        [Header("Warp Mesh Style")]

        [SerializeField]
        private InputActionProperty m_styleFullscreenQuad;

        [SerializeField]
        private InputActionProperty m_styleLinear;

        [SerializeField]
        private InputActionProperty m_styleSpline;

        [SerializeField]
        private InputActionProperty m_styleHomography;

        [SerializeField]
        private InputActionProperty m_styleMultiHomography;

        // action names, used to lookup actions in m_inputAsset if they are not configured
        // in the scene
        private const string k_saveActionName = "WarpMeshCalibration/SaveSettings";
        private const string k_nextSceneActionName = "WarpMeshCalibration/NextScene";
        private const string k_selectActionName = "WarpMeshCalibration/Select";
        private const string k_stepMoveActionName = "WarpMeshCalibration/StepMove";
        private const string k_smoothMoveActionName = "WarpMeshCalibration/SmoothMove";
        private const string k_slowModifierActionName = "WarpMeshCalibration/SlowModifier";
        private const string k_fastModifierActionName = "WarpMeshCalibration/FastModifier";
        private const string k_styleFullscreenQuadActionName
            = "WarpMeshCalibration/WarpStyleFullscreenQuad";
        private const string k_styleLinearActionName = "WarpMeshCalibration/WarpStyleLinear";
        private const string k_styleSplineActionName = "WarpMeshCalibration/WarpStyleSpline";
        private const string k_styleHomographyActionName
            = "WarpMeshCalibration/WarpStyleHomography";
        private const string k_styleMultuHomographyActionName
            = "WarpMeshCalibratio/WarpStyleMultiHomography";

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(
                    ref m_save, m_inputAsset, k_saveActionName);
                InputSystemUtils.LookupAction(
                    ref m_nextScene, m_inputAsset, k_nextSceneActionName);
                InputSystemUtils.LookupAction(
                    ref m_select, m_inputAsset, k_selectActionName);
                InputSystemUtils.LookupAction(
                    ref m_stepMove, m_inputAsset, k_stepMoveActionName);
                InputSystemUtils.LookupAction(
                    ref m_smoothMove, m_inputAsset, k_smoothMoveActionName);
                InputSystemUtils.LookupAction(
                    ref m_slowModifier, m_inputAsset, k_slowModifierActionName);
                InputSystemUtils.LookupAction(
                    ref m_fastModifier, m_inputAsset, k_fastModifierActionName);

                InputSystemUtils.LookupAction(
                    ref m_styleFullscreenQuad, m_inputAsset, k_styleFullscreenQuadActionName);
                InputSystemUtils.LookupAction(
                    ref m_styleLinear, m_inputAsset, k_styleLinearActionName);
                InputSystemUtils.LookupAction(
                    ref m_styleSpline, m_inputAsset, k_styleSplineActionName);
                InputSystemUtils.LookupAction(
                    ref m_styleHomography, m_inputAsset, k_styleHomographyActionName);
                InputSystemUtils.LookupAction(
                    ref m_styleMultiHomography, m_inputAsset, k_styleMultuHomographyActionName);
            }
        }

        protected void OnEnable()
        {
            InputSystemUtils.ConnectPerformedHandler(ref m_save, HandleSavePerformed);
            InputSystemUtils.ConnectPerformedHandler(ref m_nextScene, HandleNextScenePerformed);
            InputSystemUtils.ConnectPerformedHandler(ref m_select, HandleSelectPerformed);
            InputSystemUtils.ConnectStartedHandler(ref m_stepMove, HandleStepMoveStarted);
            InputSystemUtils.ConnectStartedHandler(ref m_smoothMove, HandleSmoothStepStarted);
            InputSystemUtils.EnableAction(ref m_slowModifier);
            InputSystemUtils.EnableAction(ref m_fastModifier);

            InputSystemUtils.ConnectPerformedHandler(
                ref m_styleFullscreenQuad, HandleStyleFullscreenQuadPerformed);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_styleLinear, HandleStyleLinearPerformed);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_styleSpline, HandleStyleSplinePerformed);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_styleHomography, HandleStyleHomographyPerformed);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_styleMultiHomography, HandleStyleMultiHomographyPerformed);
        }

        protected void OnDisable()
        {
            InputSystemUtils.DisconnectPerformedHandler(ref m_save, HandleSavePerformed);
            InputSystemUtils.DisconnectPerformedHandler(ref m_nextScene, HandleNextScenePerformed);
            InputSystemUtils.DisconnectPerformedHandler(ref m_select, HandleSelectPerformed);
            InputSystemUtils.DisconnectStartedHandler(ref m_stepMove, HandleStepMoveStarted);
            InputSystemUtils.DisconnectStartedHandler(ref m_smoothMove, HandleSmoothStepStarted);
            InputSystemUtils.DisableAction(ref m_slowModifier);
            InputSystemUtils.DisableAction(ref m_fastModifier);

            InputSystemUtils.DisconnectPerformedHandler(
                ref m_styleFullscreenQuad, HandleStyleFullscreenQuadPerformed);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_styleLinear, HandleStyleLinearPerformed);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_styleSpline, HandleStyleSplinePerformed);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_styleHomography, HandleStyleHomographyPerformed);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_styleMultiHomography, HandleStyleMultiHomographyPerformed);
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region WarpMeshCalibrationInputBase

        protected override void UpdateSelectControlPoint()
        {
        }

        protected override void UpdateMoveControlPoint()
        {
            InputAction smoothMoveAction = m_smoothMove.action;
            if (smoothMoveAction.inProgress)
            {
                Vector2 step = smoothMoveAction.ReadValue<Vector2>();
                step = Time.deltaTime * GetStepSize() * step;

                m_calibration.MoveActiveControlPoint(step);
            }
        }

        #endregion // WarpMeshCalibrationInputBase
        // ------------------------------------------------------------------

        private void HandleSavePerformed(InputAction.CallbackContext context)
        {
            m_calibration.SaveCalibration();
        }

        private void HandleNextScenePerformed(InputAction.CallbackContext context)
        {
            m_calibration.NextScene();
        }

        private void HandleSelectPerformed(InputAction.CallbackContext context)
        {
            switch (m_calibration.mode)
            {
                case BaseWarpMeshCalibration.Mode.SelectControlPoint:
                    m_calibration.SetControlPointActive(true);
                    break;

                case BaseWarpMeshCalibration.Mode.MoveControlPoint:
                    m_calibration.SetControlPointActive(false);
                    break;
            }
        }

        private void HandleStepMoveStarted(InputAction.CallbackContext context)
        {
            Vector2 step = context.ReadValue<Vector2>();

            switch (m_calibration.mode)
            {
                case BaseWarpMeshCalibration.Mode.SelectControlPoint:
                    MoveSelectControlPoint(step);
                    break;

                case BaseWarpMeshCalibration.Mode.MoveControlPoint:
                    m_calibration.MoveActiveControlPoint(GetStepSize() * step);
                    break;
            }
        }

        private void HandleSmoothStepStarted(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                Vector2 step = context.ReadValue<Vector2>();
                MoveSelectControlPoint(step);
            }
        }

        private void HandleStyleFullscreenQuadPerformed(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                m_calibration.SetWarpMeshStyle(
                    m_calibration.cursor.meshName, WarpMeshStyle.FullscreenQuad);
            }
        }

        private void HandleStyleLinearPerformed(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                m_calibration.SetWarpMeshStyle(
                    m_calibration.cursor.meshName, WarpMeshStyle.Linear);
            }
        }

        private void HandleStyleSplinePerformed(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                m_calibration.SetWarpMeshStyle(
                    m_calibration.cursor.meshName, WarpMeshStyle.Spline);
            }
        }

        private void HandleStyleHomographyPerformed(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                m_calibration.SetWarpMeshStyle(
                    m_calibration.cursor.meshName, WarpMeshStyle.Homography);
            }
        }

        private void HandleStyleMultiHomographyPerformed(InputAction.CallbackContext context)
        {
            if (m_calibration.mode == BaseWarpMeshCalibration.Mode.SelectControlPoint)
            {
                m_calibration.SetWarpMeshStyle(
                    m_calibration.cursor.meshName, WarpMeshStyle.MultiHomography);
            }
        }

        private void MoveSelectControlPoint(Vector2 input)
        {
            if (Mathf.Abs(input.x) > Mathf.Abs(input.y))
            {
                if (input.x > 0.0f)
                {
                    m_calibration.MoveCursorRight(m_calibration.cursor);
                }
                else
                {
                    m_calibration.MoveCursorLeft(m_calibration.cursor);
                }
            }
            else
            {
                if (input.y > 0.0f)
                {
                    m_calibration.MoveCursorUp(m_calibration.cursor);
                }
                else
                {
                    m_calibration.MoveCursorDown(m_calibration.cursor);
                }
            }
        }

        private float GetStepSize()
        {
            float stepSize = k_normalStep;

            if (m_slowModifier.action.IsPressed())
            {
                stepSize = k_smallStep;
            }
            else if (m_fastModifier.action.IsPressed())
            {
                stepSize = k_largeStep;
            }

            return stepSize;
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
