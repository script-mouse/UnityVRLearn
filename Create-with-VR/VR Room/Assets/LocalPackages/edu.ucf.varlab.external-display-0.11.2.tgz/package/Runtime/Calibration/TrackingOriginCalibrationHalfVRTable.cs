
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class TrackingOriginCalibrationHalfVRTable
        : BaseTrackingOriginCalibrationVRTable
    {
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            Assert.IsNotNull(GetCameraRig());
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        private ExternalDisplayCameraRigHalfVRTable GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigHalfVRTable;
        }

        protected override void CalcTrackingOriginOffset(
            out Vector3 positionOffset, out Quaternion rotationOffset)
        {
            ExternalDisplayCameraRigHalfVRTable cameraRig = GetCameraRig();
            Transform trackingOrigin = cameraRig.trackingOrigin;

            CalcTrackingOriginOffset(trackingOrigin, out positionOffset, out rotationOffset);
        }
    }

} // namespace VARLab.ExternalDisplay
