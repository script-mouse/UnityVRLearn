
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class TrackingOriginCalibrationLEDWall
        : BaseTrackingOriginCalibration
    {
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            Assert.IsNotNull(GetCameraRig());
        }

        protected override void Start()
        {
            base.Start();

            // must have 2 calibration points
            Assert.AreEqual(
                2, m_calibrationPoints.Length,
                $"LED Wall Tracking Origin Calibration expects 2 calibration points, "
                + $"got {m_calibrationPoints.Length}.");
        }

        protected void Reset()
        {
            m_cameraRig = FindFirstObjectByType<ExternalDisplayCameraRigLEDWall>();
            RenderScreen wallScreen = null;

            if (m_cameraRig != null)
            {
                wallScreen = MonoBehaviourUtils.GetChildComponent<RenderScreen>(
                    m_cameraRig.gameObject, "TileWallScreenOrigin");
            }

            m_calibrationPoints = new TrackingOriginCalibrationPoint[2]
            {
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = wallScreen,
                    landmark = ScreenLandmark.BottomLeftCorner,
                    offset = new Vector3(-0.4f, -0.08f, -0.03f),
                    postProcess = RecordPositionPostProcess.None,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = wallScreen,
                    landmark = ScreenLandmark.BottomRightCorner,
                    offset = new Vector3(0.4f, -0.08f, -0.03f),
                    postProcess = RecordPositionPostProcess.None,
                },
            };
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region BaseTrackingOriginCalibration

        protected override void HandleStartPreRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_activeIdx = 0;

            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleStartPreRecordPointsTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointRecordPointTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            Assert.IsTrue(m_activeIdx < m_calibrationPoints.Length);

            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleRecordPointRecordPointTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointPostRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationUI.SetMarker(null);
            m_calibrationUI.SetProgress(-1.0f);

            if (!ValidateCalibrationPoses(
                m_calibrationPoses, m_calibrationPoints, m_cameraRig, m_calibrationUI))
            {
                base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
                m_stateMachine.Transition(CalibrationStates.CalibrationFailedRestart);
                return;
            }

            base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
            m_stateMachine.Transition(CalibrationStates.CalibrationSuccess);
        }

        protected override void HandlePostRecordPointsCalibrationSuccessTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            // m_calibrationPoses was already validated, just calculate the resulting offsets
            CalcTrackingOriginOffset(out Vector3 positionOffset, out Quaternion rotationOffset);

            m_trackingOriginOverride
                = SettingsUtils.CreateTrackingOriginOverride(m_cameraRig);
            m_trackingOriginOverride.positionOffset = positionOffset;
            m_trackingOriginOverride.rotationOffset = rotationOffset;

            m_cameraRig.ApplyTrackingOriginOverride(m_trackingOriginOverride.Clone());

            base.HandlePostRecordPointsCalibrationSuccessTransition(
                sourceState, targetState);
        }

        protected override void HandleCalibrationSuccessCompleteTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationUI.SetStatusText("Calibration completed.");

            base.HandleCalibrationSuccessCompleteTransition(sourceState, targetState);
        }

        #endregion // BaseTrackingOriginCalibration
        // ------------------------------------------------------------------

        private ExternalDisplayCameraRigLEDWall GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigLEDWall;
        }

        private void SetCalibrateLandmarkMessage(TrackingOriginCalibrationPoint activePoint)
        {
            m_calibrationUI.SetStatusText(
                $"Move controller to <b>{activePoint.landmark}</b> "
                + $"{(activePoint.offset != Vector3.zero ? $"+ {activePoint.offset} " : "")}"
                + $"on screen <b>{activePoint.renderScreen.name}</b> and hold trigger.");
        }

        private void CalcTrackingOriginOffset(
            out Vector3 positionOffset, out Quaternion rotationOffset)
        {
            Transform trackingOrigin = m_cameraRig.trackingOrigin;
            Vector3 offset = Vector3.zero;

            for (int i = 0, iEnd = m_calibrationPoints.Length; i < iEnd; ++i)
            {
                TrackingOriginCalibrationPoint point = m_calibrationPoints[i];
                Vector3 expectedPos = CalcCalibrationPointPosition(point, trackingOrigin);
                Vector3 actualPos = m_calibrationPoses[i].position;

                offset += expectedPos - actualPos;
            }

            positionOffset = offset / m_calibrationPoints.Length;

            // use line connecting the two points to derive rotation offset
            // of tracking coordinate space
            Vector3 posBL = m_calibrationPoses[0].position;
            Vector3 posBR = m_calibrationPoses[1].position;
            Vector3 dirX = (posBR - posBL).normalized;
            Vector3 dirY = Vector3.up;
            Vector3 dirZ = Vector3.Cross(dirX, dirY);
            Vector3.OrthoNormalize(ref dirY, ref dirX, ref dirZ);

            rotationOffset = Quaternion.Inverse(Quaternion.LookRotation(dirZ, dirY));
        }
    }


} // namespace VARLab.ExternalDisplay
