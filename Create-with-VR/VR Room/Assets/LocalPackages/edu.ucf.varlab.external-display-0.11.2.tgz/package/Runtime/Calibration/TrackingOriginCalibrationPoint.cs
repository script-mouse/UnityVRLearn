
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    public enum ScreenLandmark
    {
        TopLeftCorner,
        TopRightCorner,
        BottomLeftCorner,
        BottomRightCorner,
        Center,
    }

    public enum RecordPositionPostProcess
    {
        None,
        ProjectRenderScreenNormal,
    }

    [Serializable]
    public class TrackingOriginCalibrationPoint
    {
        [Tooltip("RenderScreen that contains the calibration point")]
        public RenderScreen renderScreen;

        [Tooltip("Point on the screen to use for calibration (modified by offset)")]
        public ScreenLandmark landmark;

        [Tooltip(
            "Offset from landmark that defines calibration point - "
            + "in renderScreen coordinate system")]
        public Vector3 offset = Vector3.zero;

        [Tooltip("Modification to apply to recorded calibration positions")]
        public RecordPositionPostProcess postProcess = RecordPositionPostProcess.None;
    }

} // namespace VARLab.ExternalDisplay
