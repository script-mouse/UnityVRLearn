
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class TrackingOriginCalibrationUILEDWall
        : BaseTrackingOriginCalibrationUI
    {
        // ------------------------------------------------------------------
        #region API

        public override void SetMarker(TrackingOriginCalibrationPoint calibrationPoint)
        {
            if (calibrationPoint != null)
            {
                m_cornerMarkerImage.enabled = true;

                RenderScreen renderScreen = calibrationPoint.renderScreen;
                Transform screenTransform = renderScreen.GetComponent<Transform>();

                RectTransform canvasTransform = m_canvas.GetComponent<RectTransform>();
                Vector2 canvasLocalScale = canvasTransform.localScale;
                canvasTransform.SetParent(screenTransform, worldPositionStays: false);
                canvasTransform.sizeDelta = renderScreen.size / canvasLocalScale;

                switch (calibrationPoint.landmark)
                {
                    case ScreenLandmark.TopLeftCorner:
                        SetMarkerImagePosition(canvasTransform, new Vector2(-0.5f, 0.5f));
                        break;

                    case ScreenLandmark.TopRightCorner:
                        SetMarkerImagePosition(canvasTransform, new Vector2(0.5f, 0.5f));
                        break;

                    case ScreenLandmark.BottomLeftCorner:
                        SetMarkerImagePosition(canvasTransform, new Vector2(-0.5f, -0.5f));
                        break;

                    case ScreenLandmark.BottomRightCorner:
                        SetMarkerImagePosition(canvasTransform, new Vector2(0.5f, -0.5f));
                        break;

                    case ScreenLandmark.Center:
                        SetMarkerImagePosition(canvasTransform, new Vector2(0.0f, 0.0f));
                        break;
                }
            }
            else
            {
                m_cornerMarkerImage.enabled = false;
            }
        }

        #endregion // API
        // ------------------------------------------------------------------

        private void SetMarkerImagePosition(RectTransform canvasTransform, Vector2 corner)
        {
            RectTransform rectTransform = m_cornerMarkerImage.GetComponent<RectTransform>();
            Vector2 canvasSize = canvasTransform.sizeDelta;
            rectTransform.anchoredPosition = corner * canvasSize;
        }
    }

} // namespace VARLab.ExternalDisplay
