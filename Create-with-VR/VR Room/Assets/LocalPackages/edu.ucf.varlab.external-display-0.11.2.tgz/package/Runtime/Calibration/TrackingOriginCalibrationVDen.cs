
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.SceneManagement;

namespace VARLab.ExternalDisplay
{
    public class TrackingOriginCalibrationVDen
        : BaseTrackingOriginCalibration
    {
        private const string k_nextSceneName = "VDenCalibration";

        // ------------------------------------------------------------------
        #region API

        public override void NextScene()
        {
            SceneManager.LoadScene(k_nextSceneName, LoadSceneMode.Single);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            // must have a ExternalDisplayCameraRigVDen m_cameraRig
            Assert.IsNotNull(GetCameraRig());
        }

        protected override void Start()
        {
            base.Start();

            // must have 4 calibration points
            Assert.AreEqual(
                4, m_calibrationPoints.Length,
                $"VDen Tracking Origin Calibration expects 4 calibration points, "
                + $"got {m_calibrationPoints.Length}.");
        }

        protected void Reset()
        {
            RenderScreen floorScreen = null;

            m_cameraRig = FindFirstObjectByType<ExternalDisplayCameraRigVDen>();

            if (m_cameraRig != null)
            {
                floorScreen = MonoBehaviourUtils.GetChildComponent<RenderScreen>(
                    m_cameraRig.gameObject, "FloorScreenOrigin");
            }

            m_calibrationPoints = new TrackingOriginCalibrationPoint[4]
            {
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = floorScreen,
                    landmark = ScreenLandmark.BottomLeftCorner,
                    postProcess = RecordPositionPostProcess.ProjectRenderScreenNormal,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = floorScreen,
                    landmark = ScreenLandmark.TopLeftCorner,
                    postProcess = RecordPositionPostProcess.ProjectRenderScreenNormal,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = floorScreen,
                    landmark  = ScreenLandmark.TopRightCorner,
                    postProcess = RecordPositionPostProcess.ProjectRenderScreenNormal,
                },
                new TrackingOriginCalibrationPoint()
                {
                    renderScreen = floorScreen,
                    landmark = ScreenLandmark.BottomRightCorner,
                    postProcess = RecordPositionPostProcess.ProjectRenderScreenNormal,
                },
            };
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region BaseTrackingOriginCalibration

        protected override void HandleStartPreRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_activeIdx = 0;

            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleStartPreRecordPointsTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointRecordPointTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            Assert.IsTrue(m_activeIdx < m_calibrationPoints.Length);

            TrackingOriginCalibrationPoint activePoint = m_calibrationPoints[m_activeIdx];
            m_calibrationUI.SetMarker(activePoint);
            m_calibrationUI.SetProgress(0.0f);
            SetCalibrateLandmarkMessage(activePoint);

            base.HandleRecordPointRecordPointTransition(sourceState, targetState);
        }

        protected override void HandleRecordPointPostRecordPointsTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            m_calibrationUI.SetMarker(null);
            m_calibrationUI.SetProgress(-1.0f);

            if (!ValidateCalibrationPoses(
                m_calibrationPoses, m_calibrationPoints, m_cameraRig, m_calibrationUI))
            {
                base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
                m_stateMachine.Transition(CalibrationStates.CalibrationFailedRestart);
                return;
            }

            base.HandleRecordPointPostRecordPointsTransition(sourceState, targetState);
            m_stateMachine.Transition(CalibrationStates.CalibrationSuccess);
        }

        protected override void HandlePostRecordPointsCalibrationSuccessTransition(
            CalibrationStates sourceState, CalibrationStates targetState)
        {
            // m_calibrationPoses was already validated, just calculate the resulting offsets
            CalcTrackingOriginOffset(out Vector3 positionOffset, out Quaternion rotationOffset);

            m_trackingOriginOverride
                = SettingsUtils.CreateTrackingOriginOverride(m_cameraRig);
            m_trackingOriginOverride.positionOffset = positionOffset;
            m_trackingOriginOverride.rotationOffset = rotationOffset;

            m_cameraRig.ApplyTrackingOriginOverride(m_trackingOriginOverride.Clone());

            base.HandlePostRecordPointsCalibrationSuccessTransition(sourceState, targetState);
        }

        #endregion // BaseTrackingOriginCalibration
        // ------------------------------------------------------------------

        private ExternalDisplayCameraRigVDen GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigVDen;
        }

        private void SetCalibrateLandmarkMessage(TrackingOriginCalibrationPoint activePoint)
        {
            m_calibrationUI.SetStatusText(
                $"Move controller to <b>{activePoint.landmark}</b> "
                + $"{(activePoint.offset != Vector3.zero ? $"+ {activePoint.offset} " : "")}"
                + $"on screen {activePoint.renderScreen.name} and holder trigger");
        }

        private Vector3 AveragePositions()
        {
            Vector3 average = Vector3.zero;

            for (int i = 0, iEnd = m_calibrationPoses.Count; i < iEnd; ++i)
            {
                average += m_calibrationPoses[i].position;
            }

            return average / m_calibrationPoses.Count;
        }

        private void CalcTrackingOriginOffset(
            out Vector3 positionOffset, out Quaternion rotationOffset)
        {
            // NOTE: this relies on the order of m_calibrationPoints
            Vector3 posBL = m_calibrationPoses[0].position;
            Vector3 posTL = m_calibrationPoses[1].position;
            Vector3 posTR = m_calibrationPoses[2].position;
            Vector3 posBR = m_calibrationPoses[3].position;

            Vector3 center = AveragePositions();
            // direction of left/right (Z) and top/bottom (X) edge of the floor
            Vector3 dirZL = (posTL - posBL).normalized;
            Vector3 dirZR = (posTR - posBR).normalized;
            Vector3 dirXT = (posTR - posTL).normalized;
            Vector3 dirXB = (posBR - posBL).normalized;

            // average Z and X directions, re-normalize
            Vector3 dirZ = Vector3.Lerp(dirZL, dirZR, 0.5f).normalized;
            Vector3 dirX = Vector3.Lerp(dirXT, dirXB, 0.5f).normalized;
            Vector3 dirY = Vector3.up;
            Vector3.OrthoNormalize(ref dirY, ref dirX, ref dirZ);

            positionOffset = -center;
            rotationOffset = Quaternion.Inverse(Quaternion.LookRotation(dirZ, dirY));
        }
    }

} // namespace VARLab.ExternalDisplay
