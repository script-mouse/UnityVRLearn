
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class TrackingOriginCalibrationVRTable
        : BaseTrackingOriginCalibrationVRTable
    {
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            Assert.IsNotNull(GetCameraRig());
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        private ExternalDisplayCameraRigVRTable GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigVRTable;
        }

        protected override void CalcTrackingOriginOffset(
            out Vector3 positionOffset, out Quaternion rotationOffset)
        {
            ExternalDisplayCameraRigVRTable cameraRig = GetCameraRig();
            Transform trackingOrigin = cameraRig.trackingOrigin;

            CalcTrackingOriginOffset(trackingOrigin, out positionOffset, out rotationOffset);
        }
    }

} // namespace VARLab.ExternalDisplay
