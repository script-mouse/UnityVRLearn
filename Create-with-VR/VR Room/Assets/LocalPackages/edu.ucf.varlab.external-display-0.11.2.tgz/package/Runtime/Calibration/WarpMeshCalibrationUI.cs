
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.UI;
// external namespaces
using TMPro;

namespace VARLab.ExternalDisplay
{
    public class WarpMeshCalibrationUI
        : MonoBehaviour
    {
        // ------------------------------------------------------------------
        #region Properties

        public Canvas canvas
        {
             get => m_canvas;
        }

        #endregion // Properties
        // ------------------------------------------------------------------

        protected Canvas m_canvas = null;
        protected TextMeshProUGUI m_statusText = null;

        protected WarpControlPointId m_selectedCP = WarpControlPointId.None;
        protected WarpControlPointId m_activeCP = WarpControlPointId.None;
        protected Image[] m_controlPointImages = new Image[9];

        protected static readonly Color k_selectedColor = Color.yellow;
        protected static readonly Color k_activeColor = Color.red;
        protected static readonly Color k_defaultColor = Color.white;

        // ------------------------------------------------------------------
        #region API

        public void SelectControlPoint(WarpControlPointId controlPointId)
        {
            if (m_activeCP != WarpControlPointId.None)
            {
                MarkControlPointInactive(m_activeCP);
                m_activeCP = WarpControlPointId.None;
            }

            if (controlPointId != m_selectedCP)
            {
                MarkControlPointDeselected(m_selectedCP);
                m_selectedCP = controlPointId;
                MarkControlPointSelected(m_selectedCP);
            }
        }

        public void ActivateControlPoint(WarpControlPointId controlPointId)
        {
            if (controlPointId != m_activeCP)
            {
                MarkControlPointInactive(m_activeCP);
                m_activeCP = controlPointId;
                MarkControlPointActive(m_activeCP);
            }
        }

        public virtual void UpdateStatusTextSelectControlPoint(WarpMeshStyle warpMeshStyle)
        {
            if (m_selectedCP != WarpControlPointId.None)
            {
                m_statusText.text
                    = $"Mode: Select CP\n"
                    + $"Control Point: {m_selectedCP}\n"
                    + $"Style: {warpMeshStyle}";
            }
            else
            {
                m_statusText.text
                    = $"Mode: Select CP\n"
                    + $"Style: {warpMeshStyle}";
            }
        }

        public virtual void UpdateStatusTextMoveControlPoint(
            Vector2 cpValue, WarpMeshStyle warpMeshStyle)
        {
            if (m_activeCP != WarpControlPointId.None)
            {
                m_statusText.text
                    = $"Mode: Move CP\n"
                    + $"Control Point: {m_activeCP}\n"
                    + $"Position: {cpValue.x,5:F3} {cpValue.y,5:F3}\n"
                    + $"Style: {warpMeshStyle}";
            }
            else
            {
                m_statusText.text
                    = $"Mode: Move CP\n"
                    + $"Style: {warpMeshStyle}";
            }
        }

        public virtual void UpdateStatusText(string text)
        {
            m_statusText.text = text;
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            m_canvas = GetComponent<Canvas>();
            Assert.IsNotNull(m_canvas);

            m_statusText = MonoBehaviourUtils.GetChildComponent<TextMeshProUGUI>(
                gameObject, "StatusText");
            Assert.IsNotNull(m_statusText);

            for (int i = 0, iEnd = m_controlPointImages.Length; i < iEnd; ++i)
            {
                WarpControlPointId cpId = (WarpControlPointId)i;
                string cpName = $"P_ControlPointMarkerImage_{cpId}";
                GameObject cpGO = MonoBehaviourUtils.GetChildGameObject(gameObject, cpName);
                Assert.IsNotNull(cpGO, $"Failed to find '{cpName}'!");

                m_controlPointImages[i] = MonoBehaviourUtils.GetChildComponent<Image>(
                    cpGO, "ControlPointActiveImage");
                Assert.IsNotNull(m_controlPointImages[i]);
            }
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected void MarkControlPointSelected(WarpControlPointId controlPointId)
        {
            if (controlPointId != WarpControlPointId.None)
            {
                m_controlPointImages[(int)controlPointId].color = k_selectedColor;
                m_controlPointImages[(int)controlPointId].enabled = true;
            }
        }

        protected void MarkControlPointDeselected(WarpControlPointId controlPointId)
        {
            if (controlPointId != WarpControlPointId.None)
            {
                m_controlPointImages[(int)controlPointId].color = k_defaultColor;
                m_controlPointImages[(int)controlPointId].enabled = false;
            }
        }

        protected void MarkControlPointActive(WarpControlPointId controlPointId)
        {
            if (controlPointId != WarpControlPointId.None)
            {
                m_controlPointImages[(int)controlPointId].color = k_activeColor;
                m_controlPointImages[(int)controlPointId].enabled = true;
            }
        }

        protected void MarkControlPointInactive(WarpControlPointId controlPointId)
        {
            if (controlPointId != WarpControlPointId.None)
            {
                if (controlPointId == m_selectedCP)
                {
                    m_controlPointImages[(int)controlPointId].color = k_selectedColor;
                }
                else
                {
                    m_controlPointImages[(int)controlPointId].color = k_defaultColor;
                    m_controlPointImages[(int)controlPointId].enabled = false;
                }
            }
        }
    }

} // namespace VARLab.ExternalDisplay
