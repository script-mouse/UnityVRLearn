

// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class WarpMeshCalibrationUIVDen
        : WarpMeshCalibrationUI
    {
        [SerializeField]
        [Tooltip("RenderScreen determining UI size (default: from parents)")]
        protected RenderScreen m_renderScreen = null;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_renderScreen == null)
                m_renderScreen = GetComponentInParent<RenderScreen>();
            Assert.IsNotNull(m_renderScreen);

            UpdateCanvasTransform();
        }

        protected virtual void Update()
        {
            UpdateCanvasTransform();
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected void UpdateCanvasTransform()
        {
            RectTransform canvasTransform = m_canvas.GetComponent<RectTransform>();
            Vector2 canvasLocalScale = canvasTransform.localScale;
            canvasTransform.sizeDelta = m_renderScreen.size / canvasLocalScale;
        }
    }

} // namespace VARLab.ExternalDisplay
