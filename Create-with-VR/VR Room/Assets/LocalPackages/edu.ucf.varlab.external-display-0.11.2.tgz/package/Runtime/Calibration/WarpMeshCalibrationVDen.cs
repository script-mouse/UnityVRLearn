
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.SceneManagement;

namespace VARLab.ExternalDisplay
{
    public class WarpMeshCalibrationVDen
        : BaseWarpMeshCalibration
    {
        [SerializeField]
        private WarpMeshCalibrationUIVDen m_frontUI;

        [SerializeField]
        private WarpMeshCalibrationUIVDen m_leftUI;

        [SerializeField]
        private WarpMeshCalibrationUIVDen m_rightUI;

        [SerializeField]
        private WarpMeshCalibrationUIVDen m_floorUI;

        private const string k_nextSceneName = "VDenTrackingOriginCalibration";

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            Assert.IsNotNull(m_frontUI);
            Assert.IsNotNull(m_leftUI);
            Assert.IsNotNull(m_rightUI);
            Assert.IsNotNull(m_floorUI);
        }

        protected override void Start()
        {
            base.Start();

            m_cursor.meshName = ExternalDisplayCameraRigVDen.k_frontMeshName;
            m_frontUI.SelectControlPoint(m_cursor.controlPointId);

            // Use a coroutine to apply the settings loaded from config - this ensures that
            // 'Start' of the camera rig has run (otherwise the camera rig might not be fully
            // initialized when we apply the settings).
            StartCoroutine(DelayApplySettingsCoro());
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region API

        public override void SetControlPointActive(bool active)
        {
            base.SetControlPointActive(active);

            WarpMeshCalibrationUIVDen cursorUI = GetCursorUI(m_cursor);
            WarpMeshOverride warpMeshOverride
                = PluginUtils.FindWarpMeshOverride(m_settings.warpMeshOverrides, m_cursor.meshName);

            if (active)
            {
                cursorUI.ActivateControlPoint(m_cursor.controlPointId);

                Vector2 value = GetControlPoint(m_cursor);
                cursorUI.UpdateStatusTextMoveControlPoint(value, warpMeshOverride.style);
            }
            else
            {
                cursorUI.SelectControlPoint(m_cursor.controlPointId);
                cursorUI.UpdateStatusTextSelectControlPoint(warpMeshOverride.style);
            }
        }

        public override void MoveActiveControlPoint(Vector2 step)
        {
            base.MoveActiveControlPoint(step);

            WarpMeshCalibrationUIVDen cursorUI = GetCursorUI(m_cursor);
            Vector2 value = GetControlPoint(m_cursor);
            WarpMeshOverride warpMeshOverride
                = PluginUtils.FindWarpMeshOverride(m_settings.warpMeshOverrides, m_cursor.meshName);

            cursorUI.UpdateStatusTextMoveControlPoint(value, warpMeshOverride.style);
        }

        // Returns new cursor position after applying a move
        public override void MoveCursorUp(CursorPosition cursorPosition)
        {
            if (IsTopRow(cursorPosition.controlPointId))
            {
                if (cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_floorMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_frontMeshName,
                        controlPointId = cursorPosition.controlPointId + 6,
                    });
                }

                // cannot move up
                return;
            }

            // same mesh, move one row up
            UpdateCursorPosition(new CursorPosition()
            {
                meshName = cursorPosition.meshName,
                controlPointId = cursorPosition.controlPointId - 3
            });
        }

        public override void MoveCursorDown(CursorPosition cursorPosition)
        {
            if (IsBottomRow(cursorPosition.controlPointId))
            {
                if (cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_frontMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_floorMeshName,
                        controlPointId = cursorPosition.controlPointId - 6
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_leftMeshName))
                {
                    WarpControlPointId newControlPointId
                        = cursorPosition.controlPointId == WarpControlPointId.Bottom
                        ? WarpControlPointId.Left
                        : cursorPosition.controlPointId == WarpControlPointId.BottomRight
                        ? WarpControlPointId.TopLeft
                        : WarpControlPointId.BottomLeft;

                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_floorMeshName,
                        controlPointId = newControlPointId,
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_rightMeshName))
                {
                    WarpControlPointId newControlPointId
                        = cursorPosition.controlPointId == WarpControlPointId.Bottom
                        ? WarpControlPointId.Right
                        : cursorPosition.controlPointId == WarpControlPointId.BottomLeft
                        ? WarpControlPointId.TopRight
                        : WarpControlPointId.BottomRight;

                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_floorMeshName,
                        controlPointId = newControlPointId,
                    });
                }

                // cannot move down
                return;
            }

            // same mesh, move one row down
            UpdateCursorPosition(new CursorPosition()
            {
                meshName = cursorPosition.meshName,
                controlPointId = cursorPosition.controlPointId + 3
            });
        }

        public override void MoveCursorLeft(CursorPosition cursorPosition)
        {
            if (IsLeftColumn(cursorPosition.controlPointId))
            {
                if (cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_frontMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_leftMeshName,
                        controlPointId = cursorPosition.controlPointId + 2,
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_rightMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_frontMeshName,
                        controlPointId = cursorPosition.controlPointId + 2,
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_floorMeshName))
                {
                    WarpControlPointId newControlPointId
                        = cursorPosition.controlPointId == WarpControlPointId.TopLeft
                        ? WarpControlPointId.BottomRight
                        : cursorPosition.controlPointId == WarpControlPointId.Left
                        ? WarpControlPointId.Bottom
                        : WarpControlPointId.BottomLeft;

                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_leftMeshName,
                        controlPointId = newControlPointId,
                    });
                }

                // cannot move left
                return;
            }

            // same mesh, move one column left
            UpdateCursorPosition(new CursorPosition()
            {
                meshName = cursorPosition.meshName,
                controlPointId = cursorPosition.controlPointId - 1,
            });
        }

        public override void MoveCursorRight(CursorPosition cursorPosition)
        {
            if (IsRightColumn(cursorPosition.controlPointId))
            {
                if (cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_leftMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_frontMeshName,
                        controlPointId = cursorPosition.controlPointId - 2,
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_frontMeshName))
                {
                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_rightMeshName,
                        controlPointId = cursorPosition.controlPointId - 2,
                    });
                }
                else if (
                    cursorPosition.meshName.Equals(ExternalDisplayCameraRigVDen.k_floorMeshName))
                {
                    WarpControlPointId newControlPointId
                        = cursorPosition.controlPointId == WarpControlPointId.TopRight
                        ? WarpControlPointId.BottomLeft
                        : cursorPosition.controlPointId == WarpControlPointId.Right
                        ? WarpControlPointId.Bottom
                        : WarpControlPointId.BottomRight;

                    UpdateCursorPosition(new CursorPosition()
                    {
                        meshName = ExternalDisplayCameraRigVDen.k_rightMeshName,
                        controlPointId = newControlPointId,
                    });
                }

                // cannot move right
                return;
            }

            // same mesh, move one column right
            UpdateCursorPosition(new CursorPosition()
            {
                meshName = cursorPosition.meshName,
                controlPointId = cursorPosition.controlPointId + 1,
            });
        }

        public override void SetWarpMeshStyle(string warpMeshName, WarpMeshStyle meshStyle)
        {
            base.SetWarpMeshStyle(warpMeshName, meshStyle);

            WarpMeshCalibrationUIVDen cursorUI = GetCursorUI(warpMeshName);
            cursorUI.UpdateStatusTextSelectControlPoint(meshStyle);
        }

        public override void SaveCalibration()
        {
            m_frontUI.UpdateStatusText("Saving Calibration");

            base.SaveCalibration();
        }

        public override void NextScene()
        {
            SceneManager.LoadScene(k_nextSceneName, LoadSceneMode.Single);
        }

        #endregion // API
        // ------------------------------------------------------------------

        private WarpMeshCalibrationUIVDen GetCursorUI(CursorPosition cursorPosition)
        {
            return GetCursorUI(cursorPosition.meshName);
        }

        private WarpMeshCalibrationUIVDen GetCursorUI(string meshName)
        {
            if (meshName.Equals(ExternalDisplayCameraRigVDen.k_frontMeshName))
            {
                return m_frontUI;
            }
            else if (meshName.Equals(ExternalDisplayCameraRigVDen.k_leftMeshName))
            {
                return m_leftUI;
            }
            else if (meshName.Equals(ExternalDisplayCameraRigVDen.k_rightMeshName))
            {
                return m_rightUI;
            }
            else if (meshName.Equals(ExternalDisplayCameraRigVDen.k_floorMeshName))
            {
                return m_floorUI;
            }

            Assert.IsTrue(false, $"Invalid mesh name '{meshName}'!");
            return null;
        }

        private void UpdateCursorPosition(CursorPosition newPosition)
        {
            UpdateUICursorPosition(m_cursor, newPosition);
            m_cursor = newPosition;
        }

        private void UpdateUICursorPosition(CursorPosition oldPosition, CursorPosition newPosition)
        {
            if (!oldPosition.meshName.Equals(newPosition.meshName))
            {
                // mesh changes - deselect on old mesh
                WarpMeshCalibrationUIVDen oldUI = GetCursorUI(oldPosition);
                oldUI.SelectControlPoint(WarpControlPointId.None);

                WarpMeshOverride oldWarpMeshOverride = PluginUtils.FindWarpMeshOverride(
                    m_settings.warpMeshOverrides, oldPosition.meshName);
                oldUI.UpdateStatusTextSelectControlPoint(oldWarpMeshOverride.style);
            }

            WarpMeshCalibrationUIVDen newUI = GetCursorUI(newPosition);
            newUI.SelectControlPoint(newPosition.controlPointId);

            WarpMeshOverride newWarpMeshOverride = PluginUtils.FindWarpMeshOverride(
                m_settings.warpMeshOverrides, newPosition.meshName);
            newUI.UpdateStatusTextSelectControlPoint(newWarpMeshOverride.style);
        }
    }

} // namespace VARLab.ExternalDisplay
