
namespace VARLab.ExternalDisplay
{
    public enum CoordinateMode
    {
        Normalized,
        Pixel
    }

} // namespace VARLab.ExternalDisplay