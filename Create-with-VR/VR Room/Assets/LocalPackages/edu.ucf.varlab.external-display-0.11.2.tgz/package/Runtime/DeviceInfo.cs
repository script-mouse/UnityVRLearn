
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Information about a graphics device.
    /// </summary>
    [Serializable]
    public sealed class DeviceInfo
        : ICloneable
    {
        [Tooltip("Name of this device (must be unique)")]
        public string name = string.Empty;

        [Tooltip("Use same adapter (GPU) as Unity")]
        public bool useUnityAdapter = true;

        [Tooltip("Index of the adapter (GPU) to use (only if useUnityAdapter is false)")]
        public UInt32 adapterIdx = NativeDeviceDesc.InvalidIndex;

        [NonSerialized]
        internal NativeDeviceDesc deviceDesc = null;

        // --------------------------------------------------------------
        #region ICloneable

        public DeviceInfo Clone()
        {
            DeviceInfo clone = (DeviceInfo)MemberwiseClone();
            // deviceDesc is not cloned!
            clone.deviceDesc = null;

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
