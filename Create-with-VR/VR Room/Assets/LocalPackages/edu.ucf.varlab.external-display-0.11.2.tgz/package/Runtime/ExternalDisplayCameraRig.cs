
// system namespaces
using System;
using System.Collections;
using System.Collections.Generic;

// unity namespaces
using Unity.Collections;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.Pool;
using UnityEngine.Rendering;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayCameraRig
        : MonoBehaviour
    {
        // ------------------------------------------------------------------
        #region Properties

        public UInt32 swapInterval
        {
            get => m_swapInterval;
            set => SetSwapInterval(value);
        }

        public IList<WindowInfo> windowInfos
        {
            get => m_windowInfos;
        }

        public IList<WindowInfo> initialWindowInfos
        {
            get => m_initialWindowInfos;
        }

        public IList<SourceCameraInfo> sourceCameraInfos
        {
            get => m_sourceCameraInfos;
        }

        public IList<SourceCameraInfo> initialSourceCameraInfos
        {
            get => m_initializeSourceCameraInfos;
        }

        public IList<WarpMeshInfo> warpMeshInfos
        {
            get => m_warpMeshInfos;
        }

        public IList<WarpMeshInfo> initialWarpMeshInfos
        {
            get => m_initialWarpMeshInfos;
        }

        public IList<PresentInfo> presentInfos
        {
            get => m_presentInfos;
        }

        public IList<PresentInfo> initialPresentInfos
        {
            get => m_initialPresentInfos;
        }

        public string settingsFileSuffix
        {
            get => m_settingsFileSuffix;
        }

        public virtual Transform trackingOrigin
        {
            get => null;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        [Header("Swap")]
        [SerializeField]
        [Tooltip("Enable Nvidia swap group synchronization (requires Quadro class GPU)")]
        protected bool m_enableSwapGroup = false;

        [SerializeField]
        [Range(0, 4)]
        [Tooltip("Swap interval (0: vsync-off, 1+: vsync period)")]
        protected UInt32 m_swapInterval = 1u;

        [Header("ExternalDisplay Configuration")]
        [SerializeField]
        [Tooltip("Graphics devices (in addition to the one Unity uses)")]
        protected DeviceInfo[] m_deviceInfos;

        [SerializeField]
        [Tooltip("Windows to create for displaying content")]
        protected WindowInfo[] m_windowInfos;

        [SerializeField]
        [Tooltip("Cameras that render content (into RenderTextures) to be displayed")]
        protected SourceCameraInfo[] m_sourceCameraInfos;

        [SerializeField]
        [Tooltip("Warping meshes applied to content when displaying")]
        protected WarpMeshInfo[] m_warpMeshInfos;

        [SerializeField]
        [Tooltip("Describe which camera output to display on which window")]
        protected PresentInfo[] m_presentInfos;

        [Header("Overrides")]
        [SerializeField]
        [Tooltip("Should override settings be applied when running from the editor?")]
        protected bool m_applyOverridesInEditor = false;

        [SerializeField]
        [Tooltip("Suffix appended to the settings file name (e.g. FOO -> settings_FOO.json)")]
        protected string m_settingsFileSuffix = string.Empty;

        protected ExternalDisplayManager m_manager = null;
        protected Coroutine m_onFrameEndCoro = null;
        protected HashSet<Camera> m_sourceCameraSet = null;
        protected int m_renderedSourceCameraCount = 0;
        protected CommandBuffer m_onFrameEndCmds = null;

        // copy of settings configured in the scene (before applying any overrides)
        protected WindowInfo[] m_initialWindowInfos;
        protected SourceCameraInfo[] m_initializeSourceCameraInfos;
        protected WarpMeshInfo[] m_initialWarpMeshInfos;
        protected PresentInfo[] m_initialPresentInfos;
        protected RenderScreenInfo[] m_initialRenderScreenInfos;
        protected Pose m_initialTrackingOriginPose;

        #endregion // Fields
        // ------------------------------------------------------------------
        #region API

        public virtual void SetSwapInterval(UInt32 swapInterval, bool force = false)
        {
            if (swapInterval != m_swapInterval || force)
            {
                if (PluginAPI.SetSwapInterval(swapInterval) == ErrorCode.Success)
                {
                    m_swapInterval = swapInterval;
                }
            }
        }

        public virtual void ApplyWindowOverrides(IList<WindowOverride> windowOverrides)
        {
            for (int i = 0, iEnd = windowOverrides.Count; i < iEnd; ++i)
            {
                WindowOverride windowOverride = windowOverrides[i];

                WindowInfo windowInfo
                    = PluginUtils.FindWindowInfo(m_windowInfos, windowOverride.name);
                WindowInfo initialWindowInfo
                    = PluginUtils.FindWindowInfo(m_initialWindowInfos, windowOverride.name);

                if (windowInfo == null)
                {
                    Debug.LogError($"No window with name '{windowOverride.name}' to override!");
                    continue;
                }

                if (initialWindowInfo == null)
                {
                    Debug.LogError($"No initial window with name '{windowOverride.name}' found!");
                    continue;
                }

                ApplyWindowOverride(windowInfo, initialWindowInfo, windowOverride);
            }
        }

        public virtual void ApplyWarpMeshOverrides(IList<WarpMeshOverride> meshOverrides)
        {
            for (int i = 0, iEnd = meshOverrides.Count; i < iEnd; ++i)
            {
                WarpMeshOverride meshOverride = meshOverrides[i];
                ApplyWarpMeshOverride(meshOverride);
            }
        }

        public virtual void ApplyWarpMeshOverride(WarpMeshOverride meshOverride)
        {
            WarpMeshInfo meshInfo
                = PluginUtils.FindWarpMeshInfo(m_warpMeshInfos, meshOverride.name);
            WarpMeshInfo initialMeshInfo
                = PluginUtils.FindWarpMeshInfo(m_initialWarpMeshInfos, meshOverride.name);

            if (meshInfo == null)
            {
                Debug.LogError($"No warp mesh with name '{meshOverride.name}' to override!");
                return;
            }

            if (initialMeshInfo == null)
            {
                Debug.LogError($"No initial warp mesh with name '{meshOverride.name}' found!");
                return;
            }

            ApplyWarpMeshOverride(meshInfo, initialMeshInfo, meshOverride);
        }

        public virtual List<WarpMeshOverride> GetWarpMeshOverrides(bool includeUnchanged)
        {
            Assert.AreEqual(m_initialWarpMeshInfos.Length, m_warpMeshInfos.Length);

            List<WarpMeshOverride> warpMeshOverrides = new List<WarpMeshOverride>(
                m_warpMeshInfos.Length);

            for (int i = 0, iEnd = m_warpMeshInfos.Length; i < iEnd; ++i)
            {
                WarpMeshInfo initialWarpMeshInfo = m_initialWarpMeshInfos[i];
                WarpMeshInfo activeWarpMeshInfo
                    = PluginUtils.FindWarpMeshInfo(m_warpMeshInfos, initialWarpMeshInfo.name);

                WarpMeshOverride warpMeshOverride = SettingsUtils.CreateWarpMeshOverride(
                    initialWarpMeshInfo, activeWarpMeshInfo);

                if (warpMeshOverride.hasOverrides || includeUnchanged)
                    warpMeshOverrides.Add(warpMeshOverride);
            }

            return warpMeshOverrides;
        }

        public virtual void ApplyPresentInfoOverrides(IList<PresentInfoOverride> presentOverrides)
        {
            for (int i = 0, iEnd = presentOverrides.Count; i < iEnd; ++i)
            {
                PresentInfoOverride presentOverride = presentOverrides[i];

                ApplyPresentInfoOverride(presentOverride);
            }
        }

        public virtual void ApplyPresentInfoOverride(PresentInfoOverride presentOverride)
        {
            PresentInfo presentInfo = PluginUtils.FindPresentInfo(
                m_presentInfos, presentOverride.name);
            PresentInfo initialPresentInfo = PluginUtils.FindPresentInfo(
                m_initialPresentInfos, presentOverride.name);

            if (presentInfo == null)
            {
                Debug.LogError(
                    $"No present info with name '{presentOverride.name}' to override!");
                return;
            }

            if (initialPresentInfo == null)
            {
                Debug.LogError(
                    $"No initial present info with name '{presentOverride.name}' found!");
                return;
            }

            ApplyPresentInfoOverride(presentInfo, initialPresentInfo, presentOverride);
        }

        public virtual List<PresentInfoOverride> GetPresentInfoOverrides(bool includeUnchanged)
        {
            Assert.AreEqual(m_initialPresentInfos.Length, m_presentInfos.Length);

            List<PresentInfoOverride> presentInfoOverrides = new List<PresentInfoOverride>(
                m_presentInfos.Length);

            for (int i = 0, iEnd = m_presentInfos.Length; i < iEnd; ++i)
            {
                PresentInfo initialPresentInfo = m_initialPresentInfos[i];
                PresentInfo activePresentInfo
                    = PluginUtils.FindPresentInfo(m_presentInfos, initialPresentInfo.name);

                PresentInfoOverride presentInfoOverride = SettingsUtils.CreatePresentInfoOverride(
                    initialPresentInfo, activePresentInfo);

                if (presentInfoOverride.hasOverrides || includeUnchanged)
                    presentInfoOverrides.Add(presentInfoOverride);
            }

            return presentInfoOverrides;
        }

        public virtual void ApplyTrackingOriginOverride(
            TrackingOriginOverride trackingOriginOverride)
        {
            if (trackingOriginOverride != null)
            {
                // only warn if called with an actual override
                Debug.LogWarning(
                    "ApplyTrackingOriginOverride is not supported for base class "
                    + "ExternalDisplayCameraRig; use a derived class instead!");
            }
        }

        public virtual void ApplyRenderScreenOverrides(
            IList<RenderScreenOverride> renderScreenOverrides)
        {
            for (int i = 0, iEnd = renderScreenOverrides.Count; i < iEnd; ++i)
            {
                RenderScreenOverride renderScreenOverride = renderScreenOverrides[i];
                ApplyRenderScreenOverride(renderScreenOverride);
            }
        }

        public virtual void ApplyRenderScreenOverride(RenderScreenOverride renderScreenOverride)
        {
            // locate RenderScreen
            if (!MonoBehaviourUtils.TryGetChildComponent(
                gameObject, renderScreenOverride.name, out RenderScreen renderScreen))
            {
                Debug.LogError(
                    $"No render screen with name '{renderScreenOverride.name}' to override!");
                return;
            }

            RenderScreenInfo initialRenderScreenInfo = PluginUtils.FindRenderScreenInfo(
                m_initialRenderScreenInfos, renderScreenOverride.name);

            if (initialRenderScreenInfo == null)
            {
                Debug.LogError(
                    $"No initial render screen info with name '{renderScreenOverride.name}' found!");
                return;
            }

            ApplyRenderScreenOverride(renderScreen, initialRenderScreenInfo, renderScreenOverride);
        }

        public virtual void ApplySourceCameraInfoOverrides(
            IList<SourceCameraInfoOverride> sourceCameraOverrides)
        {
            for (int i = 0, iEnd = sourceCameraOverrides.Count; i < iEnd; ++i)
            {
                SourceCameraInfoOverride sourceCameraOverride = sourceCameraOverrides[i];
                ApplySourceCameraInfoOverride(sourceCameraOverride);
            }
        }

        public virtual void ApplySourceCameraInfoOverride(
            SourceCameraInfoOverride sourceCameraOverride)
        {
            SourceCameraInfo sourceCameraInfo = PluginUtils.FindSourceCameraInfo(
                m_sourceCameraInfos, sourceCameraOverride.name);

            if (sourceCameraInfo == null)
            {
                Debug.LogError(
                    $"No source camera info with name '{sourceCameraOverride.name}' found");
                return;
            }

            SourceCameraInfo initialSourceCameraInfo = PluginUtils.FindSourceCameraInfo(
                m_initializeSourceCameraInfos, sourceCameraOverride.name);

            if (initialSourceCameraInfo == null)
            {
                Debug.LogError(
                    $"No initial source camera info with name '{sourceCameraOverride.name}' found");
                return;
            }

            ApplySourceCameraInfoOverride(
                sourceCameraInfo, initialSourceCameraInfo, sourceCameraOverride);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            Debug.Log($"[ExternalDisplayCameraRigBase.Awake] '{name}'");
        }

        protected virtual void Start()
        {
            Debug.Log($"[ExternalDisplayCameraRigBase.Start] '{name}'");

            m_manager = MonoBehaviourUtils.GetUniqueComponentInstance<ExternalDisplayManager>();
            Assert.IsNotNull(m_manager);

            SaveInitialConfiguration();
            TryApplyFileSettings();

            if (m_manager != null)
            {
                m_manager.onStateChangingEvent += HandleManagerStateChangingEvent;
                m_manager.onStateChangedEvent += HandleManagerStateChangedEvent;

                // If this component is spawned at runtime (i.e. is not part of a scene)
                // the manager may have already emitted the state change events, ensure
                // initialization happens.

                if (m_manager.activeState == ExternalDisplayManager.States.PluginEnabled)
                {
                    CreateDevices(m_deviceInfos);
                    CreateWindows(m_windowInfos);
                }
                else if (m_manager.activeState == ExternalDisplayManager.States.ManagerEnabled)
                {
                    CreateDevices(m_deviceInfos);
                    CreateWindows(m_windowInfos);
                    InitializeSwapSettings(m_enableSwapGroup, m_swapInterval);
                    InitializeCameras(m_sourceCameraInfos);
                    InitializeWarpMeshes(m_warpMeshInfos);
                    InitializePresentOperations(m_presentInfos);
                    InitializePresentWindowsEvent();
                }
            }
        }

        protected virtual void OnDestroy()
        {
            if (m_manager != null)
            {
                m_manager.onStateChangingEvent -= HandleManagerStateChangingEvent;
                m_manager.onStateChangedEvent -= HandleManagerStateChangedEvent;
            }
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected virtual void HandleManagerStateChangingEvent(
            ExternalDisplayManager manager, ExternalDisplayManager.States prevState,
            ExternalDisplayManager.States newState)
        {
            if (prevState == ExternalDisplayManager.States.PluginEnabled
                && newState == ExternalDisplayManager.States.PluginDisabled)
            {
                // plugin is about to be disabled - destroy devices, windows
                DestroyWindows(m_windowInfos);
                DestroyDevices(m_deviceInfos);
            }
            else if (prevState == ExternalDisplayManager.States.ManagerEnabled
                && newState == ExternalDisplayManager.States.PluginEnabled)
            {
                // manager is about to be disabled - cleanup everything but windows
                ShutdownPresentWindowsEvent();
                ShutdownPresentOperations(m_presentInfos);
                ShutdownWarpMeshes(m_warpMeshInfos);
                ShutdownCameras(m_sourceCameraInfos);
            }
        }

        protected virtual void HandleManagerStateChangedEvent(
            ExternalDisplayManager manager, ExternalDisplayManager.States prevState,
            ExternalDisplayManager.States newState)
        {
            if (prevState == ExternalDisplayManager.States.PluginDisabled
                && newState == ExternalDisplayManager.States.PluginEnabled)
            {
                // plugin is now enabled - create windows, devices
                CreateDevices(m_deviceInfos);
                CreateWindows(m_windowInfos);
            }
            else if (prevState == ExternalDisplayManager.States.PluginEnabled
                && newState == ExternalDisplayManager.States.ManagerEnabled)
            {
                // manager is now enabled - initialize cameras
                InitializeSwapSettings(m_enableSwapGroup, m_swapInterval);
                InitializeCameras(m_sourceCameraInfos);
                InitializeWarpMeshes(m_warpMeshInfos);
                InitializePresentOperations(m_presentInfos);
                InitializePresentWindowsEvent();
            }
        }

        protected virtual void SaveInitialConfiguration()
        {
            m_initialWindowInfos = SerializationUtils.CloneArray(m_windowInfos);
            m_initializeSourceCameraInfos = SerializationUtils.CloneArray(m_sourceCameraInfos);
            m_initialWarpMeshInfos = SerializationUtils.CloneArray(m_warpMeshInfos);
            m_initialPresentInfos = SerializationUtils.CloneArray(m_presentInfos);
            m_initialRenderScreenInfos = PluginUtils.MakeRenderScreenInfos(this);
        }

        protected virtual void TryApplyFileSettings()
        {
#if UNITY_EDITOR
            if (m_applyOverridesInEditor)
#endif
            {
                string settingsPath = SerializationUtils.GetSettingsFilePath(m_settingsFileSuffix);
                if (SerializationUtils.TryLoadSettings(
                    settingsPath, out ExternalDisplaySettings settings))
                {
                    ApplyWindowOverrides(settings.windowOverrides);
                    ApplyWarpMeshOverrides(settings.warpMeshOverrides);
                    ApplyPresentInfoOverrides(settings.presentOverrides);
                    ApplyTrackingOriginOverride(settings.trackingOriginOverride);
                    ApplyRenderScreenOverrides(settings.renderScreenOverrides);
                    ApplySourceCameraInfoOverrides(settings.sourceCameraInfoOverrides);
                }
                else
                {
                    Debug.Log($"Could not load settings from '{settingsPath}'.");
                }
            }
        }

        protected virtual void ApplyWindowOverride(
            WindowInfo windowInfo, WindowInfo initialWindowInfo, WindowOverride windowOverride)
        {
            // if the window is already created, update it after applying the override
            bool updateWindowDesc = windowInfo.windowDesc != null;

            if (windowOverride.hasPositionOverride)
            {
                windowInfo.position = windowOverride.position;
            }
            else
            {
                windowInfo.position = initialWindowInfo.position;
            }

            if (windowOverride.hasSizeOverride)
            {
                windowInfo.size = windowOverride.size;
            }
            else
            {
                windowInfo.size = initialWindowInfo.size;
            }

            if (updateWindowDesc)
            {
                windowInfo.windowDesc.Position = windowInfo.position;
                windowInfo.windowDesc.Size = windowInfo.size;
                PluginAPI.UpdatePresentWindow(windowInfo.windowDesc);
            }
        }

        protected virtual void ApplyWarpMeshOverride(
            WarpMeshInfo warpMeshInfo, WarpMeshInfo initialWarpMeshInfo,
            WarpMeshOverride warpMeshOverride)
        {
            // if the meshDesc was already created, re-create it after applying the override
            bool recreateMeshDesc = warpMeshInfo.meshDesc != null;
            List<PresentInfo> updatePresentInfos = null;

            if (recreateMeshDesc)
            {
                // destroy meshInfo.meshDesc, but keep meshInfo.mesh alive
                DestroyWarpMesh(warpMeshInfo, destroyMesh: false);

                // record which present infos use this warp mesh, they must be recreated also
                updatePresentInfos = ListPool<PresentInfo>.Get();

                for (int j = 0, jEnd = m_presentInfos.Length; j < jEnd; ++j)
                {
                    PresentInfo presentInfo = m_presentInfos[j];

                    if (presentInfo.warpMesh.Equals(warpMeshInfo.name))
                    {
                        updatePresentInfos.Add(presentInfo);
                        DestroyPresentOperation(presentInfo);
                    }
                }
            }

            if (warpMeshOverride.hasStyleOverride)
            {
                warpMeshInfo.warpStyle = warpMeshOverride.style;
            }
            else
            {
                warpMeshInfo.warpStyle = initialWarpMeshInfo.warpStyle;
            }

            if (warpMeshOverride.hasSourceResolutionOverride)
            {
                warpMeshInfo.sourceResolution = warpMeshOverride.sourceResolution;
            }
            else
            {
                warpMeshInfo.sourceResolution = initialWarpMeshInfo.sourceResolution;
            }

            if (warpMeshOverride.hasCoordinateModeOverride)
            {
                warpMeshInfo.coordinateMode = warpMeshOverride.coordinateMode;
            }
            else
            {
                warpMeshInfo.coordinateMode = initialWarpMeshInfo.coordinateMode;
            }

            if (warpMeshOverride.hasSourceRectOverride)
            {
                warpMeshInfo.sourceRect = warpMeshOverride.sourceRect;
            }
            else
            {
                warpMeshInfo.sourceRect = initialWarpMeshInfo.sourceRect;
            }

            if (warpMeshOverride.hasMeshResolutionOverride)
            {
                warpMeshInfo.meshResolution = warpMeshOverride.meshResolution;
            }
            else
            {
                warpMeshInfo.meshResolution = initialWarpMeshInfo.meshResolution;
            }

            if (warpMeshOverride.hasControlPointsOverride)
            {
                warpMeshInfo.controlPoints = warpMeshOverride.controlPoints.Clone();
            }
            else
            {
                warpMeshInfo.controlPoints = initialWarpMeshInfo.controlPoints.Clone();
            }

            if (recreateMeshDesc)
            {
                CreateWarpMesh(warpMeshInfo);

                for (int j = 0, jEnd = updatePresentInfos.Count; j < jEnd; ++j)
                {
                    CreatePresentOperation(updatePresentInfos[j]);
                }

                ListPool<PresentInfo>.Release(updatePresentInfos);
            }
        }

        protected virtual void ApplyPresentInfoOverride(
            PresentInfo presentInfo, PresentInfo initialPresentInfo,
            PresentInfoOverride presentOverride)
        {
            // present desc must be re-created after applying override
            bool recreatePresentDesc = presentInfo.presentDesc != null;

            if (recreatePresentDesc)
            {
                DestroyPresentOperation(presentInfo);
            }

            if (presentOverride.hasTargetWindowOverride)
            {
                presentInfo.targetWindow = presentOverride.targetWindow;
            }
            else
            {
                presentInfo.targetWindow = initialPresentInfo.targetWindow;
            }

            if (presentOverride.hasWarpMeshOverride)
            {
                presentInfo.warpMesh = presentOverride.warpMesh;
            }
            else
            {
                presentInfo.warpMesh = initialPresentInfo.warpMesh;
            }

            if (presentOverride.hasSourceCameraOverride)
            {
                SourceCameraInfo cameraInfo = PluginUtils.FindSourceCameraInfo(
                    m_sourceCameraInfos, presentOverride.sourceCamera);

                if (cameraInfo == null)
                {
                    Debug.LogError(
                        $"No source camera info for name '{presentOverride.sourceCamera}' found!");
                    return;
                }

                presentInfo.sourceCamera = cameraInfo.camera;
            }
            else
            {
                presentInfo.sourceCamera = initialPresentInfo.sourceCamera;
            }

            if (presentOverride.hasViewportCoordinateModeOverride)
            {
                presentInfo.viewportCoordinateMode = presentOverride.viewportCoordinateMode;
            }
            else
            {
                presentInfo.viewportCoordinateMode = initialPresentInfo.viewportCoordinateMode;
            }

            if (presentOverride.hasViewportRectOverride)
            {
                presentInfo.viewportRect = presentOverride.viewportRect;
            }
            else
            {
                presentInfo.viewportRect = initialPresentInfo.viewportRect;
            }

            if (recreatePresentDesc)
            {
                CreatePresentOperation(presentInfo);
            }
        }

        protected virtual void ApplyRenderScreenOverride(
            RenderScreen renderScreen, RenderScreenInfo initialRenderScreenInfo,
            RenderScreenOverride renderScreenOverride)
        {
            if (renderScreenOverride.hasPositionOverride)
            {
                renderScreen.transform.localPosition = renderScreenOverride.position;
            }
            else
            {
                renderScreen.transform.localPosition = initialRenderScreenInfo.position;
            }

            if (renderScreenOverride.hasRotationOverride)
            {
                renderScreen.transform.localRotation = renderScreenOverride.rotation;
            }
            else
            {
                renderScreen.transform.localRotation = initialRenderScreenInfo.rotation;
            }

            if (renderScreenOverride.hasSizeOverride)
            {
                renderScreen.size = renderScreenOverride.size;
            }
            else
            {
                renderScreen.size = initialRenderScreenInfo.size;
            }
        }

        protected static void ApplyTrackingOriginOverride(
            Transform trackingOrigin, TrackingOriginOverride trackingOriginOverride,
            Pose initialPose)
        {
            if (trackingOriginOverride == null)
                return;

            if (trackingOriginOverride.hasPositionOffsetOverride
                && trackingOriginOverride.hasRotationOffsetOverride)
            {
                trackingOrigin.SetLocalPositionAndRotation(
                    trackingOriginOverride.positionOffset, trackingOriginOverride.rotationOffset);
                return;
            }

            if (trackingOriginOverride.hasPositionOffsetOverride)
            {
                trackingOrigin.localPosition = trackingOriginOverride.positionOffset;
            }
            else
            {
                trackingOrigin.localPosition = initialPose.position;
            }

            if (trackingOriginOverride.hasRotationOffsetOverride)
            {
                trackingOrigin.localRotation = trackingOriginOverride.rotationOffset;
            }
            else
            {
                trackingOrigin.localRotation = initialPose.rotation;
            }
        }

        protected virtual void ApplySourceCameraInfoOverride(
            SourceCameraInfo sourceCameraInfo, SourceCameraInfo initialSourceCameraInfo,
            SourceCameraInfoOverride sourceCameraOverride)
        {
            float ipdValue
                = sourceCameraOverride.hasIPDValueOverride
                ? sourceCameraOverride.ipdValue : initialSourceCameraInfo.ipdValue;

            sourceCameraInfo.ipdValue = ipdValue;

            if (sourceCameraInfo.renderViewCamera != null)
            {
                sourceCameraInfo.renderViewCamera.ipdValue = ipdValue;
            }
        }

        protected virtual void CreateDevices(DeviceInfo[] deviceInfos)
        {
            Assert.IsNotNull(m_manager);

            for (int i = 0, iEnd = deviceInfos.Length; i < iEnd; ++i)
            {
                DeviceInfo deviceInfo = deviceInfos[i];
                Assert.IsFalse(string.IsNullOrWhiteSpace(deviceInfo.name));
                Assert.IsTrue(
                    deviceInfo.useUnityAdapter == true ||
                    deviceInfo.adapterIdx != NativeDeviceDesc.InvalidIndex);

                // already created?
                if (deviceInfo.deviceDesc != null)
                    continue;

                NativeDeviceDesc existingDeviceDesc = m_manager.FindDevice(deviceInfo.name);

                if (existingDeviceDesc != null)
                {
                    deviceInfo.deviceDesc = existingDeviceDesc;
                    continue;
                }

                deviceInfo.deviceDesc = new NativeDeviceDesc()
                {
                    Name = deviceInfo.name,
                    AdapterIndex
                        = deviceInfo.useUnityAdapter
                        ? NativeDeviceDesc.InvalidIndex : deviceInfo.adapterIdx,
                };

                m_manager.CreateDevice(deviceInfo.deviceDesc);
            }
        }

        protected virtual void DestroyDevices(DeviceInfo[] deviceInfos)
        {
            Assert.IsNotNull(m_manager);

            for (int i = 0, iEnd = deviceInfos.Length; i < iEnd; ++i)
            {
                DeviceInfo deviceInfo = deviceInfos[i];

                if (deviceInfo.deviceDesc == null)
                    continue;

                if (deviceInfo.deviceDesc.Index != NativeDeviceDesc.InvalidIndex)
                {
                    m_manager.DestroyDevice(deviceInfo.deviceDesc);
                    deviceInfo.deviceDesc = null;
                }
            }
        }

        protected virtual void CreateWindows(WindowInfo[] windowInfos)
        {
            Assert.IsNotNull(m_manager);

            for (int i = 0, iEnd = windowInfos.Length; i < iEnd; ++i)
            {
                WindowInfo windowInfo = windowInfos[i];
                Assert.IsFalse(string.IsNullOrWhiteSpace(windowInfo.name));

                if (windowInfo.windowDesc != null)
                    continue;

                // check if window already exists
                NativeWindowDesc existingWindowDesc = m_manager.FindWindow(windowInfos[i].name);

                if (existingWindowDesc != null)
                {
                    windowInfo.windowDesc = existingWindowDesc;
                    continue;
                }

                // find device index associated with window
                UInt32 deviceIndex = NativeWindowDesc.UnityDeviceIndex;
                if (!string.IsNullOrEmpty(windowInfo.deviceName))
                {
                    DeviceInfo deviceInfo
                        = PluginUtils.FindDeviceInfo(m_deviceInfos, windowInfo.deviceName);
                    Assert.IsNotNull(deviceInfo);

                    deviceIndex = deviceInfo.deviceDesc.Index;
                }

                windowInfo.windowDesc = new NativeWindowDesc()
                {
                    Name = windowInfo.name,
                    DeviceIndex = deviceIndex,
                    Position = windowInfo.position,
                    Size = windowInfo.size
                };

                m_manager.CreatePresentWindow(windowInfo.windowDesc);
            }
        }

        protected virtual void DestroyWindows(WindowInfo[] windowInfos)
        {
            Assert.IsNotNull(m_manager);

            for (int i = 0, iEnd = windowInfos.Length; i < iEnd; ++i)
            {
                WindowInfo windowInfo = windowInfos[i];

                if (windowInfo.windowDesc == null)
                    continue;

                if (windowInfo.windowDesc.Index != NativeWindowDesc.InvalidIndex)
                {
                    m_manager.DestroyPresentWindow(windowInfo.windowDesc);
                    windowInfo.windowDesc = null;
                }
            }
        }

        protected virtual void InitializeSwapSettings(bool swapGroupEnabled, UInt32 swapInterval)
        {
            if (swapGroupEnabled)
            {
                if (PluginAPI.SetSwapGroupEnabled(true) != ErrorCode.Success)
                {
                    Debug.LogError("Failed to enable swap group!");
                }
            }

            SetSwapInterval(swapInterval, force: true);
        }

        protected virtual void InitializeCameras(SourceCameraInfo[] cameraInfos)
        {
            for (int i = 0, iEnd = cameraInfos.Length; i < iEnd; ++i)
            {
                SourceCameraInfo cameraInfo = cameraInfos[i];

                // present source already registered?
                if (cameraInfo.sourceDesc != null
                    && cameraInfo.sourceDesc.Index != NativePresentSourceDesc.InvalidIndex)
                {
                    continue;
                }

                RenderTexture renderTexture = cameraInfo.camera.targetTexture;

                if (!renderTexture.IsCreated())
                    renderTexture.Create();

                IntPtr renderTexturePtr = renderTexture.GetNativeTexturePtr();

                if (renderTexturePtr == IntPtr.Zero)
                {
                    Debug.LogError("ExternalDisplayCamera render texture native ptr is null!");
                    continue;
                }

                NativePresentSourceDesc sourceDesc = new NativePresentSourceDesc()
                {
                    NativeTexture = renderTexturePtr
                };

                ErrorCode ec = PluginAPI.RegisterPresentSource(sourceDesc);

                if (ec != ErrorCode.Success)
                {
                    Debug.LogError(
                        $"Failed to register present source for camera '{cameraInfo.camera.name}'");
                    continue;
                }

                cameraInfo.sourceDesc = sourceDesc;
                cameraInfo.nativeTextureValidated = false;

                if (cameraInfo.camera.TryGetComponent(out cameraInfo.renderViewCamera))
                {
                    cameraInfo.renderViewCamera.ipdValue = cameraInfo.ipdValue;
                }
            }
        }

        protected virtual void ShutdownCameras(SourceCameraInfo[] cameraInfos)
        {
            for (int i = 0, iEnd = cameraInfos.Length; i < iEnd; ++i)
            {
                SourceCameraInfo cameraInfo = cameraInfos[i];

                // present source not registered?
                if (cameraInfo.sourceDesc == null
                    || cameraInfo.sourceDesc.Index == NativePresentSourceDesc.InvalidIndex)
                {
                    continue;
                }

                ErrorCode ec = PluginAPI.UnregisterPresentSource(cameraInfo.sourceDesc.Index);

                if (ec != ErrorCode.Success)
                {
                    Debug.LogError(
                        $"Failed to unregister present source {cameraInfo.sourceDesc.Index} "
                        + $"for camera '{cameraInfo.camera.name}'");
                }

                cameraInfo.sourceDesc = null;
            }
        }

        protected virtual void InitializeWarpMeshes(WarpMeshInfo[] warpMeshes)
        {
            for (int i = 0, iEnd = warpMeshes.Length; i < iEnd; ++i)
            {
                WarpMeshInfo warpMeshInfo = warpMeshes[i];
                Assert.IsFalse(string.IsNullOrWhiteSpace(warpMeshInfo.name));

                // mesh already created?
                if (warpMeshInfo.meshDesc != null
                    && warpMeshInfo.meshDesc.Index != NativeWarpMeshDesc.InvalidIndex)
                {
                    continue;
                }

                CreateWarpMesh(warpMeshInfo);
            }
        }

        protected virtual void CreateWarpMesh(WarpMeshInfo warpMeshInfo)
        {
            Assert.IsNull(warpMeshInfo.meshDesc);

            Rect sourceRect = MathUtils.ConvertToNormalizedRect(
                warpMeshInfo.coordinateMode, warpMeshInfo.sourceRect, warpMeshInfo.sourceResolution);

            if (warpMeshInfo.mesh != null
                && WarpMeshBuilder.CanUpdateVertexData(
                    warpMeshInfo.mesh, warpMeshInfo.warpStyle, warpMeshInfo.meshResolution))
            {
                // warp mesh can be updated
                WarpMeshBuilder.UpdateVertexData(
                    warpMeshInfo.mesh, warpMeshInfo.warpStyle, warpMeshInfo.controlPoints,
                    warpMeshInfo.meshResolution, warpMeshInfo.sourceRect);
            }
            else
            {
                // (re-)create the mesh
                warpMeshInfo.mesh = WarpMeshBuilder.CreateWarpMesh(
                    warpMeshInfo.warpStyle, warpMeshInfo.controlPoints,
                    warpMeshInfo.meshResolution, sourceRect);
                warpMeshInfo.mesh.name = warpMeshInfo.name;
            }

            NativeWarpMeshDesc meshDesc = WarpMeshBuilder.CreateWarpMeshDesc(warpMeshInfo.mesh);
            meshDesc.Name = warpMeshInfo.name;

            // Make mesh data available to plugin so it can create copies on all devices (GPUs)
            Mesh.MeshDataArray meshDataArray = Mesh.AcquireReadOnlyMeshData(warpMeshInfo.mesh);
            NativeArray<byte> indexData = meshDataArray[0].GetIndexData<byte>();
            NativeArray<byte> vertexData = meshDataArray[0].GetVertexData<byte>(0);

            unsafe
            {
                fixed (byte* indexDataPtr = indexData.AsReadOnlySpan())
                fixed (byte* vertexDataPtr = vertexData.AsReadOnlySpan())
                {
                    meshDesc.IndexData = new IntPtr(indexDataPtr);
                    meshDesc.VertexData = new IntPtr(vertexDataPtr);

                    m_manager.RegisterWarpMesh(meshDesc);

                    // IndexData/VertexData are only valid inside the 'fixed' block
                    meshDesc.IndexData = IntPtr.Zero;
                    meshDesc.VertexData = IntPtr.Zero;
                }
            }

            indexData.Dispose();
            vertexData.Dispose();
            meshDataArray.Dispose();

            warpMeshInfo.meshDesc = meshDesc;
        }

        protected virtual void ShutdownWarpMeshes(WarpMeshInfo[] warpMeshes)
        {
            for (int i = 0, iEnd = warpMeshes.Length; i < iEnd; ++i)
            {
                // mesh not created?
                if (warpMeshes[i].meshDesc == null
                    || warpMeshes[i].meshDesc.Index == NativeWarpMeshDesc.InvalidIndex)
                {
                    continue;
                }

                DestroyWarpMesh(warpMeshes[i], destroyMesh: true);
            }
        }

        protected virtual void DestroyWarpMesh(WarpMeshInfo warpMeshInfo, bool destroyMesh)
        {
            m_manager.UnregisterWarpMesh(warpMeshInfo.meshDesc);
            warpMeshInfo.meshDesc = null;

            if (destroyMesh)
                warpMeshInfo.mesh = null;
        }

        protected virtual void InitializePresentOperations(PresentInfo[] presentInfos)
        {
            for (int i = 0, iEnd = presentInfos.Length; i < iEnd; ++i)
            {
                PresentInfo presentInfo = presentInfos[i];
                Assert.IsFalse(string.IsNullOrWhiteSpace(presentInfo.name));
                Assert.IsFalse(string.IsNullOrWhiteSpace(presentInfo.targetWindow));
                Assert.IsFalse(string.IsNullOrWhiteSpace(presentInfo.warpMesh));

                // present operation already created?
                if (presentInfo.presentDesc != null
                    && presentInfo.presentDesc.Index != NativePresentOperationDesc.InvalidIndex)
                {
                    continue;
                }

                ValidatePresentOperation(presentInfo);
                CreatePresentOperation(presentInfo);
            }
        }

        protected virtual void ValidatePresentOperation(PresentInfo presentInfo)
        {
            WindowInfo windowInfo
                = PluginUtils.FindWindowInfo(m_windowInfos, presentInfo.targetWindow);

            if (windowInfo == null)
            {
                Debug.LogError(
                    $"PresentInfo '{presentInfo.name}' has invalid window "
                    + $"name '{presentInfo.targetWindow}'!");
                return;
            }

            WarpMeshInfo warpMeshInfo
                = PluginUtils.FindWarpMeshInfo(m_warpMeshInfos, presentInfo.warpMesh);

            if (warpMeshInfo == null)
            {
                Debug.LogError(
                    $"PresentInfo '{presentInfo.name}' for window '{presentInfo.targetWindow}' "
                    + $"has invalid warp mesh name '{presentInfo.warpMesh}'!");
                return;
            }

            if (warpMeshInfo.coordinateMode == CoordinateMode.Pixel)
            {
                RenderTexture sourceTexture = presentInfo.sourceCamera.targetTexture;

                // Conversion of pixel coordinates can only work when the resolution of the
                // render texture is known - check if the value used in presentInfo matches
                // the actual render texture dimensions.
                if (sourceTexture.width != warpMeshInfo.sourceResolution.x
                    || sourceTexture.height != warpMeshInfo.sourceResolution.y)
                {
                    Debug.LogError(
                        $"PresentInfo '{presentInfo.name}' for window '{presentInfo.targetWindow}' "
                        + $"with warp mesh '{warpMeshInfo.name}' has non matching "
                        + $"source resolution {warpMeshInfo.sourceResolution} for source camera "
                        + $"{presentInfo.sourceCamera.name} render texture ({sourceTexture.width}x"
                        + $"{sourceTexture.height}).");
                }
            }
        }

        protected virtual void CreatePresentOperation(PresentInfo presentInfo)
        {
            Assert.IsNull(presentInfo.presentDesc);

            NativePresentSourceDesc sourceDesc = FindSourceDesc(presentInfo.sourceCamera);
            Assert.IsNotNull(sourceDesc);

            NativeWarpMeshDesc meshDesc = m_manager.FindWarpMesh(presentInfo.warpMesh);
            Assert.IsNotNull(meshDesc);

            NativeWindowDesc windowDesc = m_manager.FindWindow(presentInfo.targetWindow);
            Assert.IsNotNull(windowDesc);

            Rect pixelViewport = MathUtils.ConvertToPixelRect(
                presentInfo.viewportCoordinateMode, presentInfo.viewportRect,
                windowDesc.Size);

            NativePresentOperationDesc presentDesc = new NativePresentOperationDesc()
            {
                SourceIndex = sourceDesc.Index,
                MeshIndex = meshDesc.Index,
                WindowIndex = windowDesc.Index,
                ViewportOrigin = pixelViewport.position,
                ViewportSize = pixelViewport.size
            };

            ErrorCode ec = PluginAPI.CreatePresentOperation(presentDesc);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError(
                    $"Failed to create present operation '{presentInfo.name}' for window "
                    + $"'{windowDesc.Name}' source camera '{presentInfo.sourceCamera}'");
                return;
            }

            presentInfo.presentDesc = presentDesc;
        }

        protected virtual void ShutdownPresentOperations(PresentInfo[] presentInfos)
        {
            for (int i = 0, iEnd = presentInfos.Length; i < iEnd; ++i)
            {
                PresentInfo presentInfo = presentInfos[i];

                if (presentInfo.presentDesc == null
                    || presentInfo.presentDesc.Index == NativePresentOperationDesc.InvalidIndex)
                {
                    // present operation not created - nothing to do
                    continue;
                }

                DestroyPresentOperation(presentInfos[i]);
            }
        }

        protected virtual void DestroyPresentOperation(PresentInfo presentInfo)
        {
            ErrorCode ec = PluginAPI.DestroyPresentOperation(presentInfo.presentDesc.Index);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError(
                    $"Failed to destroy present operation '{presentInfo.name}' for window "
                    + $"'{presentInfo.targetWindow}' source camera "
                    + $"'{presentInfo.sourceCamera}'");
            }

            presentInfo.presentDesc = null;
        }

        protected virtual void InitializePresentWindowsEvent()
        {
            if (m_onFrameEndCmds == null)
            {
                m_onFrameEndCmds = new CommandBuffer()
                {
                    name = "ExternalDisplayManager.m_onFrameEndCmds"
                };

                PluginAPI.CmdDrawWindows(m_onFrameEndCmds);
                PluginAPI.CmdPresentWindows(m_onFrameEndCmds);
            }

            if (m_onFrameEndCoro == null)
            {
                m_onFrameEndCoro = StartCoroutine(OnFrameEndCoro());
            }
        }

        protected virtual void ShutdownPresentWindowsEvent()
        {
            if (m_onFrameEndCoro != null)
            {
                StopCoroutine(m_onFrameEndCoro);
                m_onFrameEndCoro = null;
            }

            m_onFrameEndCmds = null;
        }

        protected void ValidatePresentSources(SourceCameraInfo[] cameraInfos)
        {
            for (int i = 0, iEnd = cameraInfos.Length; i < iEnd; ++i)
            {
                SourceCameraInfo cameraInfo = cameraInfos[i];

                if (cameraInfo.nativeTextureValidated)
                    continue;

                if (cameraInfo.sourceDesc == null)
                    continue;

                RenderTexture renderTexture = cameraInfo.camera.targetTexture;

                if (!renderTexture.IsCreated())
                    continue;

                IntPtr renderTexturePtr = renderTexture.GetNativeTexturePtr();

                if (renderTexturePtr == IntPtr.Zero)
                {
                    Debug.LogError(
                        $"ExternalDisplayCamera camera '{cameraInfo.camera.name}' "
                        + "render texture native ptr is null!");
                    continue;
                }

                if (renderTexturePtr != cameraInfo.sourceDesc.NativeTexture)
                {
                    Debug.LogWarning(
                        $"ExternalDisplayCamera camera '{cameraInfo.camera.name}' "
                        + "render texture native ptr changed "
                        + $"(was: 0x{cameraInfo.sourceDesc.NativeTexture.ToInt64():x}, "
                        + $"now: 0x{renderTexturePtr.ToInt64():x})");

                    cameraInfo.sourceDesc.NativeTexture = renderTexturePtr;
                    PluginAPI.UpdatePresentSource(cameraInfo.sourceDesc);

                    cameraInfo.nativeTextureValidated = true;
                }
            }
        }

        private IEnumerator OnFrameEndCoro()
        {
            while (true)
            {
                yield return new WaitForEndOfFrame();

                ValidatePresentSources(m_sourceCameraInfos);

                // Call into plugin from render thread to process draw, present operations
                Graphics.ExecuteCommandBuffer(m_onFrameEndCmds);
            }
        }

        protected NativePresentSourceDesc FindSourceDesc(Camera camera)
        {
            SourceCameraInfo cameraInfo = Array.Find(
                m_sourceCameraInfos, x => x.camera == camera);

            return cameraInfo != null ? cameraInfo.sourceDesc : null;
        }
    }

} // namespace VARLab.ExternalDisplay
