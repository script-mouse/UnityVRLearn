
// system namespaces
using System;
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayCameraRigLEDWall
        : ExternalDisplayCameraRig
    {
        private static readonly DeviceInfo[] k_editorStereoDeviceInfos = new DeviceInfo[1]
        {
            new DeviceInfo()
            {
                name = "GPU_Unity",
                useUnityAdapter = true,
            },
        };

        private static readonly WindowInfo[] k_editorMonoWindowInfos = new WindowInfo[1]
        {
            new WindowInfo()
            {
                name = "Window_Mono",
                position = new Vector2Int(10, 160),
                size = new Vector2Int(1200, 990),
            },
        };

        private static readonly WindowInfo[] k_editorStereoWindowInfos = new WindowInfo[2]
        {
            new WindowInfo()
            {
                name = "Window_Left",
                position = new Vector2Int(10, 160),
                size = new Vector2Int(1200, 990),
            },
            new WindowInfo()
            {
                name = "Window_Right",
                deviceName = k_editorStereoDeviceInfos[0].name,
                position = new Vector2Int(1220, 160),
                size = new Vector2Int(1200, 990),
            },
        };

        private static readonly string[] k_editorMonoCameraNames = new string[1]
        {
            "Camera (Mono)",
        };

        private static readonly string[] k_editorStereoCameraNames = new string[2]
        {
            "Camera (LeftEye)",
            "Camera (RightEye)",
        };

        protected static readonly WarpMeshInfo[] k_editorWarpMeshInfos = new WarpMeshInfo[1]
        {
            new WarpMeshInfo()
            {
                name = "Warp_Fullscreen",
                warpStyle = WarpMeshStyle.FullscreenQuad,
                sourceResolution = new Vector2Int(4800, 3960),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one),
            },
        };

        private static readonly PresentInfo[] k_editorMonoPresentInfos = new PresentInfo[1]
        {
            new PresentInfo()
            {
                name = "Present_Mono",
                targetWindow = k_editorMonoWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.0f, 1.0f, 1.0f),
            },
        };

        private static readonly PresentInfo[] k_editorStereoPresentInfos = new PresentInfo[2]
        {
            new PresentInfo()
            {
                name = "Present_LeftEye",
                targetWindow = k_editorStereoWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.0f, 1.0f, 1.0f),
            },
            new PresentInfo()
            {
                name = "Present_RightEye",
                targetWindow = k_editorStereoWindowInfos[1].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.0f, 1.0f, 1.0f),
            },
        };

        private const string k_trackingOriginName = "TrackingOrigin";

        // ------------------------------------------------------------------
        #region Properties

        public override Transform trackingOrigin
        {
            get => m_trackingOrigin;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        [Header("LED Wall")]
        [SerializeField]
        protected Transform m_trackingOrigin;

        #endregion // Fields
        // ------------------------------------------------------------------
        #region API

        public void ResetMonoConfig()
        {
            PluginUtils.ResetWindowInfos(ref m_windowInfos, k_editorMonoWindowInfos);
            PluginUtils.ResetSourceCameras(
                ref m_sourceCameraInfos, k_editorMonoCameraNames, gameObject);
            PluginUtils.ResetWarpMeshes(ref m_warpMeshInfos, k_editorWarpMeshInfos);

            if (PluginUtils.ResetPresentInfos(ref m_presentInfos, k_editorMonoPresentInfos))
            {
                m_presentInfos[0].sourceCamera = m_sourceCameraInfos[0].camera;
            }

            // disable stereo cameras
            if (MonoBehaviourUtils.TryGetChildComponent(
                gameObject, k_editorStereoCameraNames[0], out Camera leftCamera))
            {
                leftCamera.enabled = false;
            }

            if (MonoBehaviourUtils.TryGetChildComponent(
                gameObject, k_editorStereoCameraNames[1], out Camera rightCamera))
            {
                rightCamera.enabled = false;
            }

            // enable mono camera
            m_presentInfos[0].sourceCamera.enabled = true;

            m_trackingOrigin
                = MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, k_trackingOriginName);
            m_enableSwapGroup = true;
            m_swapInterval = 1u;
            m_settingsFileSuffix = "ledwall_mono";
        }

        public void ResetStereoConfig()
        {
            PluginUtils.ResetDeviceInfos(ref m_deviceInfos, k_editorStereoDeviceInfos);
            PluginUtils.ResetWindowInfos(ref m_windowInfos, k_editorStereoWindowInfos);
            PluginUtils.ResetSourceCameras(
                ref m_sourceCameraInfos, k_editorStereoCameraNames, gameObject);
            PluginUtils.ResetWarpMeshes(ref m_warpMeshInfos, k_editorWarpMeshInfos);

            if (PluginUtils.ResetPresentInfos(ref m_presentInfos, k_editorStereoPresentInfos))
            {
                m_presentInfos[0].sourceCamera = m_sourceCameraInfos[0].camera;
                m_presentInfos[1].sourceCamera = m_sourceCameraInfos[1].camera;
            }

            // disable mono camera
            if (MonoBehaviourUtils.TryGetChildComponent(
                gameObject, k_editorMonoCameraNames[0], out Camera monoCamera))
            {
                monoCamera.enabled = false;
            }

            // enable stereo cameras
            m_presentInfos[0].sourceCamera.enabled = true;
            m_presentInfos[1].sourceCamera.enabled = true;

            m_trackingOrigin
                = MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, k_trackingOriginName);
            m_enableSwapGroup = true;
            m_swapInterval = 1u;
            m_settingsFileSuffix = "ledwall_stereo";
        }

        public void SwapEyes()
        {
            if (m_presentInfos.Length != 2)
            {
                Debug.LogWarning(
                    $"Unexpected number of Present Infos ({m_presentInfos.Length}), expected 2");
                return;
            }

            // create present overrides matching the active present infos
            List<PresentInfoOverride> presentOverrides
                = SettingsUtils.CreatePresentInfoOverrides(m_presentInfos);

            if (presentOverrides[0].targetWindow == k_editorStereoWindowInfos[0].name)
            {
                presentOverrides[0].targetWindow = k_editorStereoWindowInfos[1].name;
                presentOverrides[1].targetWindow = k_editorStereoWindowInfos[0].name;
            }
            else
            {
                presentOverrides[0].targetWindow = k_editorStereoWindowInfos[0].name;
                presentOverrides[1].targetWindow = k_editorStereoWindowInfos[1].name;
            }

            ApplyPresentInfoOverrides(presentOverrides);
        }

        public override void ApplyTrackingOriginOverride(
            TrackingOriginOverride trackingOriginOverride)
        {
            ApplyTrackingOriginOverride(
                m_trackingOrigin, trackingOriginOverride, m_initialTrackingOriginPose);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Start()
        {
            // XXX TODO: examine command line to switch mono/stereo?

            base.Start();
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
    }

#if UNITY_EDITOR
    public static class ExternalDisplayCameraRigLEDWallContextMenu
    {
        [MenuItem("CONTEXT/ExternalDisplayCameraRigLEDWall/Reset Mono Config")]
        public static void ResetMonoConfig(MenuCommand command)
        {
            ExternalDisplayCameraRigLEDWall cameraRig
                = command.context as ExternalDisplayCameraRigLEDWall;

            if (cameraRig != null)
            {
                cameraRig.ResetMonoConfig();
            }
            else
            {
                Debug.LogWarning("No ExternalDisplayCameraRigLEDWall in MenuCommand context!");
            }
        }

        [MenuItem("CONTEXT/ExternalDisplayCameraRigLEDWall/Reset Stereo Config")]
        public static void ResetStereoConfig(MenuCommand command)
        {
            ExternalDisplayCameraRigLEDWall cameraRig
                = command.context as ExternalDisplayCameraRigLEDWall;

            if (cameraRig != null)
            {
                cameraRig.ResetStereoConfig();
            }
            else
            {
                Debug.LogWarning("No ExternalDisplayCameraRigLEDWall in MenuCommand context!");
            }
        }
    }

#endif // UNITY_EDITOR

} // namespace VARLab.ExternalDisplay
