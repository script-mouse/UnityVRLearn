

// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayCameraRigMagnetic3D
        : ExternalDisplayCameraRig
    {
        public float cameraOffset
        {
            get => m_cameraOffset;
            set => SetCameraOffsetStep(value);
        }

        // ------------------------------------------------------------------
        #region Fields

        private const string k_screenOriginName = "Magnetic3DScreenOrigin";

        // WindowInfo for testing in the editor, actual values are in
        // Settings/settings_magnetic3d_55.json (or similar, depending on display size).
        // NOTE: Settings must be copied to
        //       StreamingAssets/VARLab_ExternalDisplay/settings_magnetic3d_55.json
        private static readonly WindowInfo[] k_editorWindowInfos = new WindowInfo[1]
        {
            new WindowInfo()
            {
                name = "Window_Magnetic3D",
                position = new Vector2Int(240, 135),
                size = new Vector2Int(1440, 810)
            }
        };

        // Names of the GameObjects used to position the cameras (along the x axis) from
        // left to right
        private static readonly string[] k_cameraOffsetNames = new string[7]
        {
            "CameraOffset Left 2",
            "CameraOffset Left 1",
            "CameraOffset Left 0",

            "CameraOffset Center",

            "CameraOffset Right 0",
            "CameraOffset Right 1",
            "CameraOffset Right 2",
        };

        private static readonly string[] k_editorCameraNames = new string[7]
        {
            "Camera Left 2",
            "Camera Left 1",
            "Camera Left 0",

            "Camera Center",

            "Camera Right 0",
            "Camera Right 1",
            "Camera Right 2",
        };

        private static readonly WarpMeshInfo[] k_editorWarpMeshInfos = new WarpMeshInfo[1]
        {
            new WarpMeshInfo()
            {
                name = "Warp_Magnetic3D",
                sourceResolution = new Vector2Int(1280, 720),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one)
            }
        };

        const float k_oneOverThree = 1.0f / 3.0f;
        const float k_twoOverThree = 2.0f / 3.0f;

        private static readonly PresentInfo[] k_editorPresentInfos = new PresentInfo[9]
        {
            // Left 3..0
            new PresentInfo()
            {
                name = "Present_Left3",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.0f, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Left2",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(k_oneOverThree, 0.0f, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Left1",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(k_twoOverThree, 0.0f, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Left0",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, k_oneOverThree, k_oneOverThree, k_oneOverThree),
            },

            // Center
            new PresentInfo()
            {
                name = "Present_Center",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(
                    k_oneOverThree, k_oneOverThree, k_oneOverThree, k_oneOverThree),
            },

            // Right 0..3
            new PresentInfo()
            {
                name = "Present_Right0",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(
                    k_twoOverThree, k_oneOverThree, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Right1",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, k_twoOverThree, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Right2",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(
                    k_oneOverThree, k_twoOverThree, k_oneOverThree, k_oneOverThree),
            },
            new PresentInfo()
            {
                name = "Present_Right3",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode= CoordinateMode.Normalized,
                viewportRect = new Rect(
                    k_twoOverThree, k_twoOverThree, k_oneOverThree, k_oneOverThree),
            },
        };

        [SerializeField]
        [Tooltip("Distance between cameras")]
        private float m_cameraOffset = 0.025f;

        private Transform[] m_cameraOffsetTransforms;

#if UNITY_EDITOR
        // Used to detect changes to m_cameraOffset
        private float m_cameraOffsetLatch;
#endif

        #endregion // Fields
        // ------------------------------------------------------------------
        #region API

        public void SetCameraOffsetStep(float offset)
        {
            for (int i = 0, iEnd = m_cameraOffsetTransforms.Length; i < iEnd; ++i)
            {
                m_cameraOffsetTransforms[i].localPosition
                    = new Vector3((i - 3) * offset, 0.0f, 0.0f);
            }

            m_cameraOffset = offset;
#if UNITY_EDITOR
            m_cameraOffsetLatch = offset;
#endif
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Start()
        {
            base.Start();

            m_cameraOffsetTransforms = new Transform[k_cameraOffsetNames.Length];

            for (int i = 0, iEnd = m_cameraOffsetTransforms.Length; i < iEnd; ++i)
            {
                m_cameraOffsetTransforms[i] = MonoBehaviourUtils.GetChildComponent<Transform>(
                    gameObject, k_cameraOffsetNames[i]);
            }

            SetCameraOffsetStep(m_cameraOffset);
        }

#if UNITY_EDITOR
        protected void Update()
        {
            // detect change of serialized field
            if (m_cameraOffset != m_cameraOffsetLatch)
            {
                SetCameraOffsetStep(m_cameraOffset);
            }
        }
#endif

        protected void Reset()
        {
            PluginUtils.ResetWindowInfos(ref m_windowInfos, k_editorWindowInfos);
            PluginUtils.ResetSourceCameras(
                ref m_sourceCameraInfos, k_editorCameraNames, gameObject);
            PluginUtils.ResetWarpMeshes(ref m_warpMeshInfos, k_editorWarpMeshInfos);

            if (PluginUtils.ResetPresentInfos(ref m_presentInfos, k_editorPresentInfos))
            {
                // left 3..0 (Camera Left 0 is displayed twice!)
                m_presentInfos[0].sourceCamera = m_sourceCameraInfos[2].camera;
                m_presentInfos[1].sourceCamera = m_sourceCameraInfos[0].camera;
                m_presentInfos[2].sourceCamera = m_sourceCameraInfos[1].camera;
                m_presentInfos[3].sourceCamera = m_sourceCameraInfos[2].camera;

                // center
                m_presentInfos[4].sourceCamera = m_sourceCameraInfos[3].camera;

                // right 0..3 (Camera Right 0 is displayed twice!)
                m_presentInfos[5].sourceCamera = m_sourceCameraInfos[4].camera;
                m_presentInfos[6].sourceCamera = m_sourceCameraInfos[5].camera;
                m_presentInfos[7].sourceCamera = m_sourceCameraInfos[6].camera;
                m_presentInfos[8].sourceCamera = m_sourceCameraInfos[4].camera;
            }

            m_settingsFileSuffix = "magnetic3d";
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
