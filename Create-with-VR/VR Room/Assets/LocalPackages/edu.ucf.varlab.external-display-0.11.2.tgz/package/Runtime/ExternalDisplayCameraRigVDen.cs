
// system namespaces
using System;
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Camera rig for the VDen CAVE-like virtual environment.
    /// This camera rig comes pre-configured for displaying content in the VDen and has
    /// additional API that requires understanding the semantics of the windows, cameras, and
    /// present infos.
    /// </summary>
    public class ExternalDisplayCameraRigVDen
        : ExternalDisplayCameraRig
    {
        public enum ScreenId
        {
            Front,
            Left,
            Right,
            Floor,
        }

        // ------------------------------------------------------------------
        #region Properties

        public override Transform trackingOrigin
        {
            get => m_trackingOrigin;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        [Header("VDen")]
        [SerializeField]
        protected Transform m_trackingOrigin;

        // These are internal, so that WarpMeshCalibrationVDen can access them
        internal const string k_frontMeshName = "Warp_Front";
        internal const string k_leftMeshName = "Warp_Left";
        internal const string k_rightMeshName = "Warp_Right";
        internal const string k_floorMeshName = "Warp_Floor";

        private const string k_trackingOriginName = "TrackingOrigin";
        private static readonly string[] k_screenOriginNames = new string[4]
        {
            "FrontScreenOrigin",
            "LeftScreenOrigin",
            "RightScreenOrigin",
            "FloorScreenOrigin",
        };

        // Window settings are for testing in the editor, actual settings are in
        // Settings/settings_vden.json
        // and must be copied to StreamingAssets/VARLab_ExternalDisplay/settings_vden.json
        private static readonly WindowInfo[] k_editorWindowInfos = new WindowInfo[4]
        {
            new WindowInfo()
            {
                name = "Window_Front",
                position = new Vector2Int(640, 50),
                size = new Vector2Int(640, 360),
            },
            new WindowInfo()
            {
                name = "Window_Left",
                position = new Vector2Int(0, 50),
                size = new Vector2Int(640, 360),
            },
            new WindowInfo()
            {
                name = "Window_Right",
                position = new Vector2Int(1280, 50),
                size = new Vector2Int(640, 360),
            },
            new WindowInfo()
            {
                name = "Window_Floor",
                position = new Vector2Int(640, 410),
                size = new Vector2Int(640, 360),
            }
        };

        // Names of Camera GameObjects - these must exists as (indirect) children
        private static readonly string[] k_editorCameraNames = new string[8]
        {
            "Front (LeftEye)",
            "Front (RightEye)",
            "Left (LeftEye)",
            "Left (RightEye)",
            "Right (LeftEye)",
            "Right (RightEye)",
            "Floor (LeftEye)",
            "Floor (RightEye)",
        };

        private static readonly WarpMeshInfo[] k_editorWarpMeshInfos = new WarpMeshInfo[4]
        {
            new WarpMeshInfo()
            {
                name = k_frontMeshName,
                sourceResolution = new Vector2Int(960, 1200),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one)
            },
            new WarpMeshInfo()
            {
                name = k_leftMeshName,
                sourceResolution = new Vector2Int(960, 1200),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one)
            },
            new WarpMeshInfo()
            {
                name = k_rightMeshName,
                sourceResolution = new Vector2Int(960, 1200),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one)
            },
            new WarpMeshInfo()
            {
                name = k_floorMeshName,
                sourceResolution = new Vector2Int(960, 1200),
                coordinateMode = CoordinateMode.Normalized,
                sourceRect = new Rect(Vector2.zero, Vector2.one)
            },
        };

        private static readonly PresentInfo[] k_editorPresentInfos = new PresentInfo[8]
        {
            new PresentInfo()
            {
                name = "Present_Front_LeftEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(0.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Front_RightEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(320.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Left_LeftEye",
                targetWindow = k_editorWindowInfos[1].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(0.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Left_RightEye",
                targetWindow = k_editorWindowInfos[1].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(320.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Right_LeftEye",
                targetWindow = k_editorWindowInfos[2].name,
                warpMesh = k_editorWarpMeshInfos[2].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(0.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Right_RightEye",
                targetWindow = k_editorWindowInfos[2].name,
                warpMesh = k_editorWarpMeshInfos[2].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(320.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Floor_LeftEye",
                targetWindow = k_editorWindowInfos[3].name,
                warpMesh = k_editorWarpMeshInfos[3].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(0.0f, 0.0f, 320.0f, 360.0f),
            },
            new PresentInfo()
            {
                name = "Present_Floor_RightEye",
                targetWindow = k_editorWindowInfos[3].name,
                warpMesh = k_editorWarpMeshInfos[3].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Pixel,
                viewportRect = new Rect(320.0f, 0.0f, 320.0f, 360.0f),
            },
        };

        #endregion // Fields
        // ------------------------------------------------------------------
        #region API

        public Transform GetScreenOrigin(ScreenId screenId)
        {
            string screenOriginName = k_screenOriginNames[(int)screenId];
            return MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, screenOriginName);
        }

        public void SwapEyes(ScreenId screenId)
        {
            switch (screenId)
            {
                case ScreenId.Front:
                    SwapEyes(k_editorPresentInfos[0], k_editorPresentInfos[1]);
                    break;

                case ScreenId.Left:
                    SwapEyes(k_editorPresentInfos[2], k_editorPresentInfos[3]);
                    break;

                case ScreenId.Right:
                    SwapEyes(k_editorPresentInfos[4], k_editorPresentInfos[5]);
                    break;

                case ScreenId.Floor:
                    SwapEyes(k_editorPresentInfos[6], k_editorPresentInfos[7]);
                    break;
            }
        }

        public void SwapEyesAllScreens()
        {
            SwapEyes(ScreenId.Front);
            SwapEyes(ScreenId.Left);
            SwapEyes(ScreenId.Right);
            SwapEyes(ScreenId.Floor);
        }

        // Swaps all present infos that target screenA to target screenB instead (and vice versa).
        public void SwapWindows(ScreenId screenA, ScreenId screenB)
        {
            // find the two present infos each for screenA, screenB
            PresentInfo[] presentInfos = new PresentInfo[4];
            int writeIdx = 0;
            FindAllPresentInfos(ref presentInfos, ref writeIdx, screenA);
            Assert.AreEqual(2, writeIdx);
            FindAllPresentInfos(ref presentInfos, ref writeIdx, screenB);
            Assert.AreEqual(4, writeIdx);

            // create present overrides matching current present infos
            List<PresentInfoOverride> presentOverrides
                = SettingsUtils.CreatePresentInfoOverrides(presentInfos);
            Assert.AreEqual(4, presentOverrides.Count);

            // swap target windows, viewports and warp mesh
            (presentOverrides[0].targetWindow, presentOverrides[2].targetWindow)
                = (presentOverrides[2].targetWindow, presentOverrides[0].targetWindow);
            (presentOverrides[1].targetWindow, presentOverrides[3].targetWindow)
                = (presentOverrides[3].targetWindow, presentOverrides[1].targetWindow);

            (presentOverrides[0].warpMesh, presentOverrides[2].warpMesh)
                = (presentOverrides[2].warpMesh, presentOverrides[0].warpMesh);
            (presentOverrides[1].warpMesh, presentOverrides[3].warpMesh)
                = (presentOverrides[3].warpMesh, presentOverrides[1].warpMesh);

            (presentOverrides[0].viewportRect, presentOverrides[2].viewportRect)
                = (presentOverrides[2].viewportRect, presentOverrides[0].viewportRect);
            (presentOverrides[1].viewportRect, presentOverrides[3].viewportRect)
                = (presentOverrides[3].viewportRect, presentOverrides[1].viewportRect);

            ApplyPresentInfoOverrides(presentOverrides);
        }

        public override void ApplyTrackingOriginOverride(
            TrackingOriginOverride trackingOriginOverride)
        {
            ApplyTrackingOriginOverride(
                m_trackingOrigin, trackingOriginOverride, m_initialTrackingOriginPose);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected void Reset()
        {
            PluginUtils.ResetWindowInfos(ref m_windowInfos, k_editorWindowInfos);
            PluginUtils.ResetSourceCameras(
                ref m_sourceCameraInfos, k_editorCameraNames, gameObject);
            PluginUtils.ResetWarpMeshes(ref m_warpMeshInfos, k_editorWarpMeshInfos);

            if (PluginUtils.ResetPresentInfos(ref m_presentInfos, k_editorPresentInfos))
            {
                m_presentInfos[0].sourceCamera = m_sourceCameraInfos[0].camera;
                m_presentInfos[1].sourceCamera = m_sourceCameraInfos[1].camera;

                m_presentInfos[2].sourceCamera = m_sourceCameraInfos[2].camera;
                m_presentInfos[3].sourceCamera = m_sourceCameraInfos[3].camera;

                m_presentInfos[4].sourceCamera = m_sourceCameraInfos[4].camera;
                m_presentInfos[5].sourceCamera = m_sourceCameraInfos[5].camera;

                m_presentInfos[6].sourceCamera = m_sourceCameraInfos[6].camera;
                m_presentInfos[7].sourceCamera = m_sourceCameraInfos[7].camera;
            }

            m_trackingOrigin
                = MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, k_trackingOriginName);

            m_settingsFileSuffix = "vden";
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region ExternalDisplayCameraRig

        protected override void SaveInitialConfiguration()
        {
            base.SaveInitialConfiguration();

            m_initialTrackingOriginPose.position = m_trackingOrigin.localPosition;
            m_initialTrackingOriginPose.rotation = m_trackingOrigin.localRotation;
        }

        #endregion // ExternalDisplayCameraRig
        // ------------------------------------------------------------------

        private void SwapEyes(PresentInfo presentInfoLeft, PresentInfo presentInfoRight)
        {
            // find the two present infos that match the passed in k_editorPresentInfos
            PresentInfo[] presentInfos = Array.FindAll(
                m_presentInfos, x =>
                {
                    return x.name.Equals(presentInfoLeft.name)
                        || x.name.Equals(presentInfoRight.name);
                });
            Assert.AreEqual(2, presentInfos.Length);

            // create present overrides matching the active present infos
            List<PresentInfoOverride> presentOverrides
                = SettingsUtils.CreatePresentInfoOverrides(presentInfos);
            Assert.AreEqual(2, presentOverrides.Count);

            // swap viewport rects
            (presentOverrides[0].viewportRect, presentOverrides[1].viewportRect)
                = (presentOverrides[1].viewportRect, presentOverrides[0].viewportRect);

            ApplyPresentInfoOverrides(presentOverrides);
        }

        private void FindAllPresentInfos(
            ref PresentInfo[] foundPresentInfos, ref int writeIdx, ScreenId screenId)
        {
            for (int i = 0, iEnd = m_presentInfos.Length; i < iEnd; ++i)
            {
                if (m_presentInfos[i].name.StartsWith($"Present_{screenId}"))
                {
                    Assert.IsTrue(writeIdx < foundPresentInfos.Length);
                    foundPresentInfos[writeIdx++] = m_presentInfos[i];
                }
            }
        }
    }

} // namespace VARLab.ExternalDisplay
