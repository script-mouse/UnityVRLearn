
// system namespaces
using System.Collections.Generic;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayCameraRigVRTable
        : ExternalDisplayCameraRig
    {
        public enum ScreenId
        {
            VerticalLeft,
            VerticalRight,
            HorizontalLeft,
            HorizontalRight,
        }

        // ------------------------------------------------------------------
        #region Properties

        public override Transform trackingOrigin
        {
            get => m_trackingOrigin;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        [Header("VRTable")]
        [SerializeField]
        protected Transform m_trackingOrigin;

        // Window settings are for testing in the editor, actual settings are in
        // Settings/settings_vrtable.json
        // and must be copied to StreamingAssets/VARLab_ExternalDisplay/settings_vrtable.json
        private static readonly WindowInfo[] k_editorWindowInfos = new WindowInfo[1]
        {
            new WindowInfo()
            {
                name = "Window_VRTable",
                position = new Vector2Int(0, 0),
                size = new Vector2Int(1920, 1080)
            },
        };

        private static readonly string[] k_editorCameraNames = new string[4]
        {
            "Vertical (LeftEye)",
            "Vertical (RightEye)",
            "Horizontal (LeftEye)",
            "Horizontal (RightEye)",
        };

        private static readonly WarpMeshInfo[] k_editorWarpMeshInfos = new WarpMeshInfo[2]
        {
            new WarpMeshInfo()
            {
                name = "Warp_Left",
                sourceResolution = new Vector2Int(1943, 1080),
                coordinateMode = CoordinateMode.Pixel,
                sourceRect = new Rect(0.0f, 0.0f, 960.0f, 1080.0f),
            },
            new WarpMeshInfo()
            {
                name = "Warp_Right",
                sourceResolution = new Vector2Int(1943, 1080),
                coordinateMode = CoordinateMode.Pixel,
                sourceRect = new Rect(983.0f, 0.0f, 960.0f, 1080.0f),
            },
        };

        private static readonly PresentInfo[] k_editorPresentInfos = new PresentInfo[8]
        {
            // vertical left, left eye
            new PresentInfo()
            {
                name = "Present_VerticalLeft_LeftEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.0f, 0.25f, 0.5f),
            },
            // vertical left, right eye
            new PresentInfo()
            {
                name = "Present_VerticalLeft_RightEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.25f, 0.0f, 0.25f, 0.5f),
            },
            // vertical right, left eye
            new PresentInfo()
            {
                name = "Present_VerticalRight_LeftEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.5f, 0.0f, 0.25f, 0.5f),
            },
            // vertical right, right eye
            new PresentInfo()
            {
                name = "Present_VerticalRight_RightEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.75f, 0.0f, 0.25f, 0.5f),
            },
            // horizontal left, left eye
            new PresentInfo()
            {
                name = "Present_HorizontalLeft_LeftEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.0f, 0.5f, 0.25f, 0.5f),
            },
            // horiztonal left, right eye
            new PresentInfo()
            {
                name = "Present_HorizontalLeft_RightEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[0].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.25f, 0.5f, 0.25f, 0.5f),
            },
            // horizontal right, left eye
            new PresentInfo()
            {
                name = "Present_HorizontalRight_LeftEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.5f, 0.5f, 0.25f, 0.5f),
            },
            // horizontal right, right eye
            new PresentInfo()
            {
                name = "Present_HorizontalRight_RightEye",
                targetWindow = k_editorWindowInfos[0].name,
                warpMesh = k_editorWarpMeshInfos[1].name,
                sourceCamera = null,
                viewportCoordinateMode = CoordinateMode.Normalized,
                viewportRect = new Rect(0.75f, 0.5f, 0.25f, 0.5f),
            },
        };

        private const string k_trackingOriginName = "TrackingOrigin";
        private static readonly string[] k_screenOriginNames = new string[4]
        {
            "VerticalLeftScreenOrigin",
            "VerticalRightScreenOrigin",
            "HorizontalLeftScreenOrigin",
            "HorizontalRightScreenOrigin",
        };

        #endregion // Fields
        // ------------------------------------------------------------------
        #region API

        public Transform GetScreenOrigin(ScreenId screenId)
        {
            string screenOriginName = k_screenOriginNames[(int)screenId];
            return MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, screenOriginName);
        }

        public void SwapEyes(ScreenId screenId)
        {
            switch (screenId)
            {
                case ScreenId.VerticalLeft:
                    {
                        PresentInfo presentInfoLeftEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[0].name);
                        PresentInfo presentInfoRightEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[1].name);
                        SwapEyes(presentInfoLeftEye, presentInfoRightEye);
                    }
                    break;

                case ScreenId.VerticalRight:
                    {
                        PresentInfo presentInfoLeftEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[2].name);
                        PresentInfo presentInfoRightEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[3].name);
                        SwapEyes(presentInfoLeftEye, presentInfoRightEye);
                    }
                    break;

                case ScreenId.HorizontalLeft:
                    {
                        PresentInfo presentInfoLeftEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[4].name);
                        PresentInfo presentInfoRightEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[5].name);
                        SwapEyes(presentInfoLeftEye, presentInfoRightEye);
                    }
                    break;

                case ScreenId.HorizontalRight:
                    {
                        PresentInfo presentInfoLeftEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[6].name);
                        PresentInfo presentInfoRightEye
                            = PluginUtils.FindPresentInfo(
                                m_presentInfos, k_editorPresentInfos[7].name);
                        SwapEyes(presentInfoLeftEye, presentInfoRightEye);
                    }
                    break;
            }
        }

        public void SwapEyesAllScreens()
        {
            SwapEyes(ScreenId.VerticalLeft);
            SwapEyes(ScreenId.VerticalRight);
            SwapEyes(ScreenId.HorizontalLeft);
            SwapEyes(ScreenId.HorizontalRight);
        }

        public override void ApplyTrackingOriginOverride(
            TrackingOriginOverride trackingOriginOverride)
        {
            ApplyTrackingOriginOverride(
                m_trackingOrigin, trackingOriginOverride, m_initialTrackingOriginPose);
        }

        #endregion // API
        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected void Reset()
        {
            PluginUtils.ResetWindowInfos(ref m_windowInfos, k_editorWindowInfos);
            PluginUtils.ResetSourceCameras(
                ref m_sourceCameraInfos, k_editorCameraNames, gameObject);
            PluginUtils.ResetWarpMeshes(ref m_warpMeshInfos, k_editorWarpMeshInfos);

            if (PluginUtils.ResetPresentInfos(ref m_presentInfos, k_editorPresentInfos))
            {
                m_presentInfos[0].sourceCamera = m_sourceCameraInfos[0].camera;
                m_presentInfos[1].sourceCamera = m_sourceCameraInfos[1].camera;
                m_presentInfos[2].sourceCamera = m_sourceCameraInfos[0].camera;
                m_presentInfos[3].sourceCamera = m_sourceCameraInfos[1].camera;

                m_presentInfos[4].sourceCamera = m_sourceCameraInfos[2].camera;
                m_presentInfos[5].sourceCamera = m_sourceCameraInfos[3].camera;
                m_presentInfos[6].sourceCamera = m_sourceCameraInfos[2].camera;
                m_presentInfos[7].sourceCamera = m_sourceCameraInfos[3].camera;
            }

            m_trackingOrigin
                = MonoBehaviourUtils.GetChildComponent<Transform>(gameObject, k_trackingOriginName);

            m_settingsFileSuffix = "vrtable";
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------
        #region ExternalDisplayCameraRig

        protected override void SaveInitialConfiguration()
        {
            base.SaveInitialConfiguration();

            m_initialTrackingOriginPose.position = m_trackingOrigin.localPosition;
            m_initialTrackingOriginPose.rotation = m_trackingOrigin.localRotation;
        }

        #endregion // ExternalDisplayCameraRig
        // ------------------------------------------------------------------

        private void SwapEyes(PresentInfo presentInfoLeftEye, PresentInfo presentInfoRightEye)
        {
            List<PresentInfoOverride> presentOverrides = new List<PresentInfoOverride>()
            {
                SettingsUtils.CreatePresentInfoOverride(presentInfoLeftEye),
                SettingsUtils.CreatePresentInfoOverride(presentInfoRightEye)
            };

            // swap viewport rects
            (presentOverrides[0].viewportRect, presentOverrides[1].viewportRect)
                = (presentOverrides[1].viewportRect, presentOverrides[0].viewportRect);

            ApplyPresentInfoOverrides(presentOverrides);
        }
    }

} // namespace VARLab.ExternalDisplay
