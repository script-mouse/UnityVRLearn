
// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayManager
        : MonoBehaviour
    {
        // When switching scenes most resources need to be destroyed, except devices and windows,
        // which must persist, otherwise unpleasant flickering might occur.
        // Therefore three states are used to represent disabled, devices & windows only,
        // everything enabled conditions.
        public enum States
        {
            // No resources currently exist, initial and final state
            PluginDisabled,

            // Plugin is active and only devices, windows can exist
            PluginEnabled,

            // All plugin resources can exist and external windows are presented
            ManagerEnabled,
        }

        // ===================================================================
        #region Events

        public event Action<ExternalDisplayManager, States, States> onStateChangingEvent;
        public event Action<ExternalDisplayManager, States, States> onStateChangedEvent;

        #endregion // Events
        // ===================================================================
        #region Properties

        public States activeState
        {
            get => m_state != null ? m_state.activeState : States.PluginDisabled;
        }

        #endregion // Properties
        // ===================================================================
        #region Fields

        private ExternalDisplayPluginState m_state = null;

        #endregion // Fields
        // ===================================================================
        #region MonoBehaviour

        private void Awake()
        {
            Debug.Log($"[ExternalDisplayManager.Awake] '{name}'");
            InitializePluginState();
        }

        private void OnEnable()
        {
            switch (m_state.activeState)
            {
                case States.PluginDisabled:
                    EnablePlugin();
                    EnableManager();
                    break;

                case States.PluginEnabled:
                    EnableManager();
                    break;

                case States.ManagerEnabled:
                    Debug.LogWarning($"Unexpected state '{activeState}'");
                    break;

                default:
                    Debug.LogError($"Unknown state '{activeState}'!");
                    break;
            }
        }

        private void OnDisable()
        {
            switch (m_state.activeState)
            {
                case States.PluginDisabled:
                case States.PluginEnabled:
                    // nothing to do - plugin remains enabled until OnApplicationQuit
                    break;

                case States.ManagerEnabled:
                    DisableManager();
                    break;

                default:
                    Debug.LogError($"Unknown state '{activeState}'!");
                    break;
            }
        }

        private void OnApplicationQuit()
        {
            switch (m_state.activeState)
            {
                case States.PluginDisabled:
                    Debug.LogWarning($"Unexpected state '{activeState}'");
                    break;

                case States.PluginEnabled:
                    DisablePlugin();
                    break;

                case States.ManagerEnabled:
                    DisableManager();
                    DisablePlugin();
                    break;

                default:
                    Debug.LogError($"Unknown state '{activeState}'!");
                    break;
            }
        }

        #endregion // MonoBehaviour
        // ===================================================================
        #region API

        public void CreateDevice(NativeDeviceDesc deviceDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.IsTrue(States.PluginEnabled <= m_state.activeState);

            if (PluginAPI.CreateDevice(deviceDesc) == ErrorCode.Success)
            {
                m_state.SetDevice(deviceDesc);
            }
        }

        public void DestroyDevice(NativeDeviceDesc deviceDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.IsTrue(States.PluginEnabled <= m_state.activeState);
            Assert.AreNotEqual(NativeDeviceDesc.InvalidIndex, deviceDesc.Index);

            if (PluginAPI.DestroyDevice(deviceDesc.Index) == ErrorCode.Success)
            {
                m_state.ClearDevice(deviceDesc.Index);
                deviceDesc.Index = NativeDeviceDesc.InvalidIndex;
            }
        }

        public NativeDeviceDesc FindDevice(string name)
        {
            Assert.IsNotNull(m_state);

            return m_state.FindDeviceDesc(name);
        }

        public void CreatePresentWindow(NativeWindowDesc windowDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.IsTrue(States.PluginEnabled <= m_state.activeState);

            if (PluginAPI.CreatePresentWindow(windowDesc) == ErrorCode.Success)
            {
                m_state.SetWindow(windowDesc);
            }
        }

        public void DestroyPresentWindow(NativeWindowDesc windowDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.IsTrue(States.PluginEnabled <= m_state.activeState);
            Assert.AreNotEqual(NativeWindowDesc.InvalidIndex, windowDesc.Index);

            if (PluginAPI.DestroyPresentWindow(windowDesc.Index) == ErrorCode.Success)
            {
                m_state.ClearWindow(windowDesc.Index);
                windowDesc.Index = NativeWindowDesc.InvalidIndex;
            }
        }

        public NativeWindowDesc FindWindow(string name)
        {
            Assert.IsNotNull(m_state);

            return m_state.FindWindow(name);
        }

        public void RegisterWarpMesh(NativeWarpMeshDesc meshDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.AreEqual(States.ManagerEnabled, m_state.activeState);

            if (PluginAPI.RegisterWarpMesh(meshDesc) == ErrorCode.Success)
            {
                m_state.SetMesh(meshDesc);
            }
        }

        public void UnregisterWarpMesh(NativeWarpMeshDesc meshDesc)
        {
            Assert.IsNotNull(m_state);
            Assert.AreEqual(States.ManagerEnabled, m_state.activeState);
            Assert.AreNotEqual(NativeWarpMeshDesc.InvalidIndex, meshDesc.Index);

            if (PluginAPI.UnregisterWarpMesh(meshDesc.Index) == ErrorCode.Success)
            {
                m_state.ClearMesh(meshDesc.Index);
                meshDesc.Index = NativeWarpMeshDesc.InvalidIndex;
            }
        }

        public NativeWarpMeshDesc FindWarpMesh(string name)
        {
            Assert.IsNotNull(m_state);

            return m_state.FindMesh(name);
        }

        #endregion // API
        // ===================================================================

        private void InitializePluginState()
        {
            Debug.Log("[ExternalDisplayManager.InitializeNativePluginState]");

            MonoBehaviourUtils.InitializeUniqueInstance(ref m_state, CreatePluginState);
        }

        private static ExternalDisplayPluginState CreatePluginState()
        {
            // create state instance and make it persist across level loads
            GameObject stateGO = new GameObject("[ExternalDisplay] Plugin State")
            {
                hideFlags = HideFlags.HideInInspector | HideFlags.HideInHierarchy
            };
            DontDestroyOnLoad(stateGO);

            ExternalDisplayPluginState state = stateGO.AddComponent<ExternalDisplayPluginState>();
            return state;
        }

        private void EnablePlugin()
        {
            States prevState = m_state.activeState;
            States newState = States.PluginEnabled;
            InvokeStateChangingEvent(prevState, newState);

            if (PluginAPI.Enable() == ErrorCode.Success)
            {
                m_state.activeState = newState;
                InvokeStateChangedEvent(prevState, newState);
            }
        }

        private void DisablePlugin()
        {
            States prevState = m_state.activeState;
            States newState = States.PluginDisabled;
            InvokeStateChangingEvent(prevState, newState);

            if (PluginAPI.Disable() == ErrorCode.Success)
            {
                m_state.activeState = newState;
                InvokeStateChangedEvent(prevState, newState);
            }
        }

        private void EnableManager()
        {
            States prevState = m_state.activeState;
            States newState = States.ManagerEnabled;
            InvokeStateChangingEvent(prevState, newState);

            m_state.activeState = newState;
            InvokeStateChangedEvent(prevState, newState);
        }

        private void DisableManager()
        {
            States prevState = m_state.activeState;
            States newState = States.PluginEnabled;
            InvokeStateChangingEvent(prevState, newState);

            m_state.activeState = newState;
            InvokeStateChangedEvent(prevState, newState);
        }

        private void InvokeStateChangingEvent(States prevState, States newState)
        {
            onStateChangingEvent?.Invoke(this, prevState, newState);
        }

        private void InvokeStateChangedEvent(States prevState, States newState)
        {
            onStateChangedEvent?.Invoke(this, prevState, newState);
        }
    }

} // namespace VARLab.ExternalDisplay
