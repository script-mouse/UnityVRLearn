
// system namespaces
using System;
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplayPluginState
        : MonoBehaviour
    {
        public ExternalDisplayManager.States activeState
        {
            get => m_activeState;

            // Set from ExternalDisplayManager
            internal set => m_activeState = value;
        }

        public List<NativeDeviceDesc> deviceDesc
        {
            get => m_deviceDescs;
        }

        public List<NativeWindowDesc> windows
        {
            get => m_windows;
        }

        private ExternalDisplayManager.States m_activeState
            = ExternalDisplayManager.States.PluginDisabled;
        private List<NativeDeviceDesc> m_deviceDescs = new List<NativeDeviceDesc>();
        private List<NativeWindowDesc> m_windows = new List<NativeWindowDesc>();
        private List<NativeWarpMeshDesc> m_meshes = new List<NativeWarpMeshDesc>();

        internal void SetDevice(NativeDeviceDesc deviceDesc)
        {
            Assert.AreNotEqual(NativeDeviceDesc.InvalidIndex, deviceDesc.Index);

            while (m_deviceDescs.Count <= deviceDesc.Index)
                m_deviceDescs.Add(null);

            m_deviceDescs[(int)deviceDesc.Index] = deviceDesc;
        }

        internal void ClearDevice(UInt32 deviceIdx)
        {
            if (deviceIdx != NativeDeviceDesc.InvalidIndex && deviceIdx < m_deviceDescs.Count)
            {
                m_deviceDescs[(int)deviceIdx] = null;
            }
        }

        internal NativeDeviceDesc FindDeviceDesc(string name)
        {
            return m_deviceDescs.Find(x => x.Name.Equals(name));
        }

        internal void SetWindow(NativeWindowDesc windowDesc)
        {
            Assert.AreNotEqual(NativeWindowDesc.InvalidIndex, windowDesc.Index);

            while (m_windows.Count <= windowDesc.Index)
                m_windows.Add(null);

            m_windows[(int)windowDesc.Index] = windowDesc;
        }

        internal void ClearWindow(UInt32 windowIdx)
        {
            if (windowIdx != NativeWindowDesc.InvalidIndex && windowIdx < m_windows.Count)
            {
                m_windows[(int)windowIdx] = null;
            }
        }

        internal NativeWindowDesc FindWindow(string name)
        {
            return m_windows.Find(x => x.Name.Equals(name));
        }

        internal void SetMesh(NativeWarpMeshDesc meshDesc)
        {
            Assert.AreNotEqual(NativeWarpMeshDesc.InvalidIndex, meshDesc.Index);

            while (m_meshes.Count <= meshDesc.Index)
                m_meshes.Add(null);

            m_meshes[(int)meshDesc.Index] = meshDesc;
        }

        internal void ClearMesh(UInt32 meshIdx)
        {
            if (meshIdx != NativeWarpMeshDesc.InvalidIndex && meshIdx < m_meshes.Count)
            {
                m_meshes[(int)meshIdx] = null;
            }
        }

        internal NativeWarpMeshDesc FindMesh(string name)
        {
            return m_meshes.Find(x => x.Name.Equals(name));
        }
    }

} // namespace VARLab.ExternalDisplay
