
// unity namespaces
using UnityEngine;
using UnityEngine.XR;
// external namespaces
using Valve.VR;

namespace VARLab.ExternalDisplay.OpenVR
{
    public class RenderViewCameraOriginOpenVR
        : RenderViewCameraOriginBase
    {
        // ----------------------------------------------------------------------
        #region Properties

        public SteamVR_Action_Pose poseAction
        {
            get => m_poseAction;
            set => UpdatePoseAction(value);
        }

        public SteamVR_Input_Sources poseSource
        {
            get => m_poseSource;
            set => UpdatePoseSource(value);
        }

        #endregion // Properties
        // ----------------------------------------------------------------------
        #region Fields

        [SerializeField]
        protected SteamVR_Action_Pose m_poseAction;

        [SerializeField]
        protected SteamVR_Input_Sources m_poseSource = SteamVR_Input_Sources.Chest;

        protected Vector3 m_inputPosition = Vector3.zero;
        protected Quaternion m_inputRotation = Quaternion.identity;
        protected InputTrackingState m_inputTrackingState = InputTrackingState.None;

        protected bool m_poseActionBound = false;

        #endregion // Fields
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void OnEnable()
        {
            base.OnEnable();

            BindPoseAction();
        }

        protected override void OnDisable()
        {
            UnbindPoseAction();

            base.OnDisable();
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------
        #region API

        public void SetActions(SteamVR_Action_Pose poseAction, SteamVR_Input_Sources poseSource)
        {
            UnbindPoseAction();

            m_poseAction = poseAction;
            m_poseSource = poseSource;

            BindPoseAction();
        }

        #endregion // API
        // ----------------------------------------------------------------------

        protected void BindPoseAction()
        {
            if (!m_poseActionBound && m_poseAction != null)
            {
                m_poseAction.AddOnUpdateListener(m_poseSource, HandlePoseUpdate);
                m_poseActionBound = true;
            }
        }

        protected void UnbindPoseAction()
        {
            if (m_poseActionBound)
            {
                m_poseAction.RemoveOnUpdateListener(m_poseSource, HandlePoseUpdate);
                m_poseActionBound = false;
            }
        }

        protected void HandlePoseUpdate(SteamVR_Action_Pose action, SteamVR_Input_Sources source)
        {
            Vector3 position = m_poseAction.GetLocalPosition(m_poseSource);
            Quaternion rotation = m_poseAction.GetLocalRotation(m_poseSource);
            ETrackingResult trackingResult = m_poseAction.GetTrackingResult(m_poseSource);

            UpdateTrackerPose(
                position, rotation, MapTrackingResult(trackingResult), m_ignoreTrackingState);
        }

        protected void UpdatePoseAction(SteamVR_Action_Pose newAction)
        {
            if (Application.isPlaying)
                UnbindPoseAction();

            m_poseAction = newAction;

            if (Application.isPlaying && isActiveAndEnabled)
                BindPoseAction();
        }

        protected void UpdatePoseSource(SteamVR_Input_Sources newSource)
        {
            if (Application.isPlaying)
                UnbindPoseAction();

            m_poseSource = newSource;

            if (Application.isPlaying && isActiveAndEnabled)
                BindPoseAction();
        }

        private static InputTrackingState MapTrackingResult(ETrackingResult trackingResult)
        {
            switch (trackingResult)
            {
                default:
                case ETrackingResult.Uninitialized:
                case ETrackingResult.Calibrating_InProgress:
                case ETrackingResult.Calibrating_OutOfRange:
                    return InputTrackingState.None;

                case ETrackingResult.Running_OK:
                    return InputTrackingState.Position | InputTrackingState.Rotation;

                case ETrackingResult.Fallback_RotationOnly:
                    return InputTrackingState.Rotation;
            }
        }
    }

} // namespace VARLab.ExternalDisplay.OpenVR
