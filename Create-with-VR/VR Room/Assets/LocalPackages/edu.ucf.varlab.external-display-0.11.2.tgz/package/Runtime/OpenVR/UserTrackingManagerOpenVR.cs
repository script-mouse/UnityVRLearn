
// system namespaces
using System;
// unity namespaces
using UnityEngine;
// external namespaces
using Valve.VR;

namespace VARLab.ExternalDisplay.OpenVR
{
    [Serializable]
    public class UserTrackingConfigOpenVR
        : UserTrackingConfigBase
    {
        [Tooltip("User head pose")]
        public SteamVR_Action_Pose poseAction;

        [Tooltip("User head pose source")]
        public SteamVR_Input_Sources poseSource;
    }

    /// <summary>
    /// Allows switching between OpenVR based head tracking sources.
    /// </summary>
    public class UserTrackingManagerOpenVR
        : UserTrackingManagerBase
    {
        // ----------------------------------------------------------------------
        #region Properties

        public override UserTrackingConfigBase activeUserConfig
        {
            get
            {
                return m_activeUserIndex != k_inactiveUserIndex
                    ? m_userTrackingConfigs[m_activeUserIndex] : null;
            }
        }

        #endregion // Properties
        // ----------------------------------------------------------------------

        [SerializeField]
        private UserTrackingConfigOpenVR[] m_userTrackingConfigs;

        // ----------------------------------------------------------------------
        #region API

        public override void SwitchActiveUser(int index)
        {
            RenderViewCameraOriginOpenVR cameraOrigin = GetCameraOrigin();

            if (index != k_inactiveUserIndex)
            {
                UserTrackingConfigOpenVR config = m_userTrackingConfigs[index];
                cameraOrigin.SetActions(config.poseAction, config.poseSource);
            }
            else
            {
                cameraOrigin.SetActions(null, SteamVR_Input_Sources.Any);
            }

            m_activeUserIndex = index;
        }

        #endregion // API
        // ----------------------------------------------------------------------

        private RenderViewCameraOriginOpenVR GetCameraOrigin()
        {
            return m_cameraOrigin as RenderViewCameraOriginOpenVR;
        }
    }

} // namespace VARLab.ExternalDisplay.OpenVR
