// Exclude if disabled by define (allow coexistance with MDVR package)
#if !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER

// unity namespaces
using UnityEngine.XR;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.Layouts;
using UnityEngine.InputSystem.XR;
using UnityEngine.Scripting;
#if USE_INPUT_SYSTEM_POSE_CONTROL
using PoseControlType = UnityEngine.InputSystem.XR.PoseControl;
#else
using PoseControlType = UnityEngine.XR.OpenXR.Input.PoseControl;
#endif

namespace VARLab.ExternalDisplay.OpenXR
{
    [Preserve,
     InputControlLayout(
        displayName = "HTC Vive Tracker (OpenXR)",
        commonUsages = new[] {
            Usages.leftFoot,
            Usages.rightFoot,
            Usages.leftShoulder,
            Usages.rightShoulder,
            Usages.leftElbow,
            Usages.rightElbow,
            Usages.leftKnee,
            Usages.rightKnee,
            Usages.waist,
            Usages.chest,
            Usages.camera,
            Usages.keyboard
        }
    )]
    public class HTCViveTracker
        : XRGenericTracker
    {
        /// <summary>
        /// Bit flags for use as XR.InputDevice characteristics, each one describing a tracker
        /// role.
        /// </summary>
        [System.Flags]
        public enum Characteristics : uint
        {
            LeftFoot = 0x1000u,
            RightFoot = 0x2000u,
            LeftShoulder = 0x4000u,
            RightShoulder = 0x8000u,
            LeftElbow = 0x10000u,
            RightElbow = 0x20000u,
            LeftKnee = 0x40000u,
            RightKnee = 0x80000u,
            Waist = 0x100000u,
            Chest = 0x200000u,
            Camera = 0x400000u,
            Keyboard = 0x800000u,
        }

        /// <summary>
        /// Constants describing device usages, one for each tracker role.
        /// </summary>
        public static class Usages
        {
            public const string leftFoot = "Left Foot";
            public const string rightFoot = "Right Foot";
            public const string leftShoulder = "Left Shoulder";
            public const string rightShoulder = "Right Shoulder";
            public const string leftElbow = "Left Elbow";
            public const string rightElbow = "Right Elbow";
            public const string leftKnee = "Left Knee";
            public const string rightKnee = "Right Knee";
            public const string waist = "Waist";
            public const string chest = "Chest";
            public const string camera = "Camera";
            public const string keyboard = "Keyboard";
        }

        /// <summary>
        /// Paths where the OpenXR runtime exposes the tracker data.
        /// </summary>
        public static class UserPaths
        {
            public const string leftFoot = "/user/vive_tracker_htcx/role/left_foot";
            public const string rightFoot = "/user/vive_tracker_htcx/role/right_foot";
            public const string leftShoulder = "/user/vive_tracker_htcx/role/left_shoulder";
            public const string rightShoulder = "/user/vive_tracker_htcx/role/right_shoulder";
            public const string leftElbow = "/user/vive_tracker_htcx/role/left_elbow";
            public const string rightElbow = "/user/vive_tracker_htcx/role/right_elbow";
            public const string leftKnee = "/user/vive_tracker_htcx/role/left_knee";
            public const string rightKnee = "/user/vive_tracker_htcx/role/right_knee";
            public const string waist = "/user/vive_tracker_htcx/role/waist";
            public const string chest = "/user/vive_tracker_htcx/role/chest";
            public const string camera = "/user/vive_tracker_htcx/role/camera";
            public const string keyboard = "/user/vive_tracker_htcx/role/keyboard";
        }

        public static class ComponentPaths
        {
            public const string grip = "/input/grip/pose";
        }

        [Preserve,
         InputControl(
            offset = 0,
            aliases = new[] { "device", "gripPose" },
            usage = "Device",
            noisy = true
        )]
        public PoseControlType devicePose
        {
            get;
            private set;
        }

        [Preserve,
         InputControl(
            offset = 8,
            alias = "gripPosition",
            noisy = true
        )]
        new public Vector3Control devicePosition
        {
            get;
            private set;
        }

        [Preserve,
         InputControl(
            offset = 20,
            alias = "gripOrientation",
            noisy = true
        )]
        new public QuaternionControl deviceRotation
        {
            get;
            private set;
        }

        [Preserve,
         InputControl(offset = 60
        )]
        new public ButtonControl isTracked
        {
            get;
            private set;
        }

        [Preserve,
         InputControl(offset = 64
        )]
        new public IntegerControl trackingState
        {
            get;
            private set;
        }

        protected override void FinishSetup()
        {
            base.FinishSetup();
            devicePose = GetChildControl<PoseControlType>("devicePose");
            devicePosition = GetChildControl<Vector3Control>("devicePosition");
            deviceRotation = GetChildControl<QuaternionControl>("deviceRotation");
            isTracked = GetChildControl<ButtonControl>("isTracked");
            trackingState = GetChildControl<IntegerControl>("trackingState");

            string capabilities = description.capabilities;
            XRDeviceDescriptor deviceDescriptor = XRDeviceDescriptor.FromJson(capabilities);

            if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.LeftFoot) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.leftFoot);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.RightFoot) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.rightFoot);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.LeftShoulder) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.leftShoulder);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.RightShoulder) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.rightShoulder);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.LeftElbow) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.leftElbow);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.RightElbow) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.rightElbow);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.LeftKnee) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.leftKnee);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.RightKnee) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.rightKnee);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.Waist) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.waist);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.Chest) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.chest);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.Camera) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.camera);
            }
            else if ((deviceDescriptor.characteristics
                & (InputDeviceCharacteristics)Characteristics.Keyboard) != 0)
            {
                InputSystem.SetDeviceUsage(this, Usages.keyboard);
            }
        }
    }

} // namespace VARLab.ExternalDisplay.OpenXR

#endif // !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER
