// Exclude if disabled by define (allow coexistance with MDVR package)
#if !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER

// system namespaces
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Layouts;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace VARLab.ExternalDisplay.OpenXR
{
#if UNITY_EDITOR
    [UnityEditor.XR.OpenXR.Features.OpenXRFeature(
        UiName = "HTC Vive Tracker Profile",
        BuildTargetGroups = new[] { BuildTargetGroup.Standalone, BuildTargetGroup.WSA },
        Company = "VARLab",
        Desc = "Interaction profile for HTC Vive Tackers.",
        OpenxrExtensionStrings = HTCViveTrackerInteractionFeature.extensionName,
        Version = "0.1.0",
        Category = UnityEditor.XR.OpenXR.Features.FeatureCategory.Interaction,
        FeatureId = HTCViveTrackerInteractionFeature.featureId
    )]
#endif
    public class HTCViveTrackerInteractionFeature
        : OpenXRInteractionFeature
    {
        public const string featureId = "edu.ucf.varlab.openxr.feature.input.htcvivetracker";
        public const string profile = "/interaction_profiles/htc/vive_tracker_htcx";
        public const string extensionName = "XR_HTCX_vive_tracker_interaction";

        private const string k_deviceName = "HTC Vive Tracker OpenXR";

        protected override InteractionProfileType GetInteractionProfileType()
        {
            return InteractionProfileType.Device;
        }

        protected override string GetDeviceLayoutName()
        {
            return nameof(HTCViveTracker);
        }

        protected override void RegisterDeviceLayout()
        {
            InputSystem.RegisterLayout<XRGenericTracker>(name: nameof(XRGenericTracker));
            InputSystem.RegisterLayout<HTCViveTracker>(
                name: nameof(HTCViveTracker),
                matches: new InputDeviceMatcher()
                    .WithInterface(XRUtilities.InterfaceMatchAnyVersion)
                    .WithProduct(k_deviceName));
        }

        protected override void UnregisterDeviceLayout()
        {
            InputSystem.RemoveLayout(nameof(HTCViveTracker));
            InputSystem.RemoveLayout(nameof(XRGenericTracker));
        }

        protected override void RegisterActionMapsWithRuntime()
        {
            ActionMapConfig config = new ActionMapConfig()
            {
                name = "htcvivetracker",
                localizedName = k_deviceName,
                desiredInteractionProfile = profile,
                manufacturer = "HTC",
                serialNumber = "",
                deviceInfos = new List<DeviceConfig>()
                {
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.LeftFoot,
                        userPath = HTCViveTracker.UserPaths.leftFoot
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.RightFoot,
                        userPath = HTCViveTracker.UserPaths.rightFoot
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.LeftShoulder,
                        userPath = HTCViveTracker.UserPaths.leftShoulder
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.RightShoulder,
                        userPath = HTCViveTracker.UserPaths.rightShoulder
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.LeftElbow,
                        userPath = HTCViveTracker.UserPaths.leftElbow
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.RightElbow,
                        userPath = HTCViveTracker.UserPaths.rightElbow
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.LeftKnee,
                        userPath = HTCViveTracker.UserPaths.leftKnee
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.RightKnee,
                        userPath = HTCViveTracker.UserPaths.rightKnee
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.Waist,
                        userPath = HTCViveTracker.UserPaths.waist
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.Chest,
                        userPath = HTCViveTracker.UserPaths.chest
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.Camera,
                        userPath = HTCViveTracker.UserPaths.camera
                    },
                    new DeviceConfig()
                    {
                        characteristics = InputDeviceCharacteristics.TrackedDevice
                            | (InputDeviceCharacteristics)HTCViveTracker.Characteristics.Keyboard,
                        userPath = HTCViveTracker.UserPaths.keyboard
                    },
                },
                actions = new List<ActionConfig>()
                {
                    new ActionConfig()
                    {
                        name = "devicePose",
                        localizedName = "Device Pose",
                        type = ActionType.Pose,
                        usages = new List<string>()
                        {
                            "Device"
                        },
                        bindings = new List<ActionBinding>()
                        {
                            new ActionBinding()
                            {
                                interactionPath = HTCViveTracker.ComponentPaths.grip,
                                interactionProfileName = profile
                            }
                        }
                    }
                }
            };

            AddActionMap(config);
        }

        protected override bool OnInstanceCreate(ulong xrInstance)
        {
            bool result = base.OnInstanceCreate(xrInstance);

            Debug.Log(
                $"{extensionName} enabled: {OpenXRRuntime.IsExtensionEnabled(extensionName)}");

            return result;
        }
    }

} // namespace VARLab.ExternalDisplay.OpenXR

#endif // !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER
