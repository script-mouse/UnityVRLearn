
// unity namespace
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.XR;

namespace VARLab.ExternalDisplay.OpenXR
{
    public class RenderViewCameraOriginOpenXR
        : RenderViewCameraOriginBase
    {
        public enum UpdateType
        {
            UpdateAndBeforeRender,
            Update,
            BeforeRender,
        }

        // ----------------------------------------------------------------------
        #region Properties

        public UpdateType updateType
        {
            get => m_updateType;
            set => m_updateType = value;
        }

        public InputActionProperty positionAction
        {
            get => m_positionAction;
            set => UpdatePositionAction(value);
        }

        public InputActionProperty rotationAction
        {
            get => m_rotationAction;
            set => UpdateRotationAction(value);
        }

        public InputActionProperty trackingStateAction
        {
            get => m_trackingStateAction;
            set => UpdateTrackingStateAction(value);
        }

        #endregion // Properties
        // ----------------------------------------------------------------------
        #region Fields

        [SerializeField]
        protected UpdateType m_updateType = UpdateType.UpdateAndBeforeRender;

        [SerializeField]
        protected InputActionProperty m_positionAction;

        [SerializeField]
        protected InputActionProperty m_rotationAction;

        [SerializeField]
        protected InputActionProperty m_trackingStateAction;

        protected Vector3 m_inputPosition = Vector3.zero;
        protected Quaternion m_inputRotation = Quaternion.identity;
        protected InputTrackingState m_inputTrackingState = InputTrackingState.None;

        protected bool m_firstUpdate = false;
        protected bool m_positionPerformedBound = false;
        protected bool m_positionCanceledBound = false;
        protected bool m_rotationPerformedBound = false;
        protected bool m_rotationCanceledBound = false;
        protected bool m_trackingStatePerformedBound = false;
        protected bool m_trackingStateCanceledBound = false;

        #endregion // Fields
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void OnEnable()
        {
            base.OnEnable();

            BindPositionAction();
            BindRotationAction();
            BindTrackingStateAction();

            m_firstUpdate = true;
            InputSystem.onAfterUpdate += HandleInputSystemOnAfterUpdate;
        }

        protected override void OnDisable()
        {
            InputSystem.onAfterUpdate -= HandleInputSystemOnAfterUpdate;

            UnbindPositionAction();
            UnbindRotationAction();
            UnbindTrackingStateAction();

            base.OnDisable();
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------
        #region API

        public void SetActions(
            InputAction positionAction, InputAction rotationAction,
            InputAction trackingStateAction)
        {
            UnbindPositionAction();
            UnbindRotationAction();
            UnbindTrackingStateAction();

            m_positionAction = new InputActionProperty(positionAction);
            m_rotationAction = new InputActionProperty(rotationAction);
            m_trackingStateAction = new InputActionProperty(trackingStateAction);

            BindPositionAction();
            BindRotationAction();
            BindTrackingStateAction();
        }

        #endregion // API
        // ----------------------------------------------------------------------

        protected void UpdatePositionAction(InputActionProperty newAction)
        {
            if (Application.isPlaying)
                UnbindPositionAction();

            m_positionAction = newAction;

            if (Application.isPlaying && isActiveAndEnabled)
                BindPositionAction();
        }

        protected void BindPositionAction()
        {
            if (!m_positionPerformedBound)
            {
                m_positionPerformedBound = InputSystemUtils.ConnectPerformedHandler(
                    m_positionAction.action, HandlePositionActionPerformed);
            }

            if (!m_positionCanceledBound)
            {
                m_positionCanceledBound = InputSystemUtils.ConnectCanceledHandler(
                    m_positionAction.action, HandlePositionActionCanceled);
            }
        }

        protected void UnbindPositionAction()
        {
            if (m_positionPerformedBound)
            {
                m_positionPerformedBound = InputSystemUtils.DisconnectPerformedHandler(
                    m_positionAction.action, HandlePositionActionPerformed);
            }

            if (m_positionCanceledBound)
            {
                m_positionCanceledBound = InputSystemUtils.DisconnectCanceledHandler(
                    m_positionAction.action, HandlePositionActionCanceled);
            }
        }

        protected void UpdateRotationAction(InputActionProperty newAction)
        {
            if (Application.isPlaying)
                UnbindRotationAction();

            m_rotationAction = newAction;

            if (Application.isPlaying && isActiveAndEnabled)
                BindRotationAction();
        }

        protected void BindRotationAction()
        {
            if (!m_rotationPerformedBound)
            {
                m_rotationPerformedBound = InputSystemUtils.ConnectPerformedHandler(
                    m_rotationAction.action, HandleRotationActionPerformed);
            }

            if (!m_rotationCanceledBound)
            {
                m_rotationCanceledBound = InputSystemUtils.ConnectCanceledHandler(
                    m_rotationAction.action, HandleRotationActionCanceled);
            }
        }

        protected void UnbindRotationAction()
        {
            if (m_rotationPerformedBound)
            {
                m_rotationPerformedBound = InputSystemUtils.DisconnectPerformedHandler(
                    m_rotationAction.action, HandleRotationActionPerformed);
            }

            if (m_rotationCanceledBound)
            {
                m_rotationCanceledBound = InputSystemUtils.DisconnectCanceledHandler(
                    m_rotationAction.action, HandleRotationActionCanceled);
            }
        }

        protected void UpdateTrackingStateAction(InputActionProperty newAction)
        {
            if (Application.isPlaying)
                UnbindTrackingStateAction();

            m_trackingStateAction = newAction;

            if (Application.isPlaying && isActiveAndEnabled)
                BindTrackingStateAction();
        }

        protected void BindTrackingStateAction()
        {
            if (!m_trackingStatePerformedBound)
            {
                m_trackingStatePerformedBound = InputSystemUtils.ConnectPerformedHandler(
                    m_trackingStateAction.action, HandleTrackingStateActionPerformed);
            }

            if (!m_trackingStateCanceledBound)
            {
                m_trackingStateCanceledBound = InputSystemUtils.ConnectCanceledHandler(
                    m_trackingStateAction.action, HandleTrackingStateActionCanceled);
            }
        }

        protected void UnbindTrackingStateAction()
        {
            if (m_trackingStatePerformedBound)
            {
                m_trackingStatePerformedBound = InputSystemUtils.DisconnectPerformedHandler(
                    m_trackingStateAction.action, HandleTrackingStateActionPerformed);
            }

            if (m_trackingStateCanceledBound)
            {
                m_trackingStateCanceledBound = InputSystemUtils.DisconnectCanceledHandler(
                    m_trackingStateAction.action, HandleTrackingStateActionCanceled);
            }
        }

        protected void HandlePositionActionPerformed(InputAction.CallbackContext context)
        {
            m_inputPosition = context.ReadValue<Vector3>();
        }

        protected void HandlePositionActionCanceled(InputAction.CallbackContext context)
        {
            m_inputPosition = m_defaultPosition;
        }

        protected void HandleRotationActionPerformed(InputAction.CallbackContext context)
        {
            m_inputRotation = context.ReadValue<Quaternion>();
        }

        protected void HandleRotationActionCanceled(InputAction.CallbackContext context)
        {
            m_inputRotation = m_defaultRotation;
        }

        protected void HandleTrackingStateActionPerformed(
            InputAction.CallbackContext context)
        {
            m_inputTrackingState = (InputTrackingState)context.ReadValue<int>();
        }

        protected void HandleTrackingStateActionCanceled(
            InputAction.CallbackContext context)
        {
            m_inputTrackingState = InputTrackingState.None;
        }

        protected void HandleInputSystemOnAfterUpdate()
        {
            if (m_firstUpdate)
            {
                if (m_positionAction.action != null)
                {
                    m_inputPosition = m_positionAction.action.ReadValue<Vector3>();
                }
                else
                {
                    m_inputPosition = m_defaultPosition;
                }

                if (m_rotationAction.action != null)
                {
                    m_inputRotation = m_rotationAction.action.ReadValue<Quaternion>();
                }
                else
                {
                    m_inputRotation = m_defaultRotation;
                }

                if (m_trackingStateAction.action != null)
                {
                    m_inputTrackingState
                        = (InputTrackingState)m_trackingStateAction.action.ReadValue<int>();
                }
                else
                {
                    m_inputTrackingState = InputTrackingState.None;
                }

                m_firstUpdate = false;
            }

            if (InputState.currentUpdateType == InputUpdateType.BeforeRender)
            {
                if (m_updateType == UpdateType.UpdateAndBeforeRender
                    || m_updateType == UpdateType.BeforeRender)
                {
                    UpdateTrackerPose();
                }
            }
            else
            {
                if (m_updateType == UpdateType.UpdateAndBeforeRender
                    || m_updateType == UpdateType.Update)
                {
                    UpdateTrackerPose();
                }
            }
        }

        protected void UpdateTrackerPose()
        {
            UpdateTrackerPose(
                m_inputPosition, m_inputRotation, m_inputTrackingState, m_ignoreTrackingState);
        }
    }

} // namespace VARLab.ExternalDisplay.OpenXR
