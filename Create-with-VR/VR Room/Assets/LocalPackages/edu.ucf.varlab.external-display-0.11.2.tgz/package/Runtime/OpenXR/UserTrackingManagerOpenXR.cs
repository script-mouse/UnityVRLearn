
// system namespaces
using System;

// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay.OpenXR
{
    [Serializable]
    public class UserTrackingConfigOpenXR
        : UserTrackingConfigBase
    {
        [Tooltip("User head position")]
        public InputActionProperty positionAction;

        [Tooltip("User head rotation")]
        public InputActionProperty rotationAction;

        [Tooltip("User head tracking state")]
        public InputActionProperty trackingStateAction;
    }

    /// <summary>
    /// Allows switching between OpenXR based head tracking sources.
    /// </summary>
    public class UserTrackingManagerOpenXR
        : UserTrackingManagerBase
    {
        // ----------------------------------------------------------------------
        #region Properties

        public override UserTrackingConfigBase activeUserConfig
        {
            get
            {
                return m_activeUserIndex != k_inactiveUserIndex
                    ? m_userTrackingConfigs[m_activeUserIndex] : null;
            }
        }

        #endregion // Properties
        // ----------------------------------------------------------------------

        [SerializeField]
        private UserTrackingConfigOpenXR[] m_userTrackingConfigs;

        // ----------------------------------------------------------------------
        #region API

        public override void SwitchActiveUser(int index)
        {
            RenderViewCameraOriginOpenXR cameraOrigin = GetCameraOrigin();

            if (index != k_inactiveUserIndex)
            {
                UserTrackingConfigOpenXR config = m_userTrackingConfigs[index];
                cameraOrigin.SetActions(
                    config.positionAction.action, config.rotationAction.action,
                    config.trackingStateAction.action);
            }
            else
            {
                cameraOrigin.SetActions(null, null, null);
            }

            m_activeUserIndex = index;
        }

        #endregion // API
        // ----------------------------------------------------------------------

        private RenderViewCameraOriginOpenXR GetCameraOrigin()
        {
            return m_cameraOrigin as RenderViewCameraOriginOpenXR;
        }
    }

} // namespace VARLab.ExternalDisplay.OpenXR
