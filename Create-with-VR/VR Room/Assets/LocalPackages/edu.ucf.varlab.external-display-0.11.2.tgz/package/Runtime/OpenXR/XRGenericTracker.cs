// Exclude if disabled by define (allow coexistance with MDVR package)
#if !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER

// unity namespaces
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Layouts;

namespace VARLab.ExternalDisplay.OpenXR
{
    [InputControlLayout(isGenericTypeOfDevice = true, displayName = "XR Generic Tracker")]
    public class XRGenericTracker
        : TrackedDevice
    {
    }

} // namespace VARLab.ExternalDisplay.OpenXR

#endif // !VARLAB_EXTERNALDISPLAY_DISABLE_HTCVIVETRACKER
