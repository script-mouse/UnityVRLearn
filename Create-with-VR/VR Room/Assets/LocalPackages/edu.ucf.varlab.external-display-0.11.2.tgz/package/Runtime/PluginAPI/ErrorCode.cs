
namespace VARLab.ExternalDisplay
{
    public enum ErrorCode
    {
        Success = 0,

        InvalidOperation = -1,
        InvalidArgument = -2,
        OutOfResources = -3,
    }

} // namespace VARLab.ExternalDisplay
