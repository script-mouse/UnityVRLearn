
// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    // NOTE: This type must match the layout of NativeDeviceDesc in
    //       PluginSource/Source/NativeDeviceDesc.hpp
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class NativeDeviceDesc
        : ICloneable
    {
        public const UInt32 InvalidIndex = 0xFFFFFFFF;

        [NonSerialized]
        public UInt32 Index = InvalidIndex;

        [SerializeField]
        public string Name = string.Empty;

        [SerializeField]
        public UInt32 AdapterIndex = InvalidIndex;

        public NativeDeviceDesc Clone()
        {
            NativeDeviceDesc clone = (NativeDeviceDesc)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }
    }

} // namespace VARLab.ExternalDisplay
