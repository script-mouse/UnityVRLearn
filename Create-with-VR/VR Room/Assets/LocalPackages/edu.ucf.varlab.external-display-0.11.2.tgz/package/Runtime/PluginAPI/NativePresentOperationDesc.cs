
// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    // NOTE: This type must match the layout of NativePresentOperationDesc in
    //       PluginSource/Source/NativePresentOperationDesc.hpp
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class NativePresentOperationDesc
    {
        public const UInt32 InvalidIndex = 0xFFFFFFFF;

        [System.NonSerialized]
        public UInt32 Index = InvalidIndex;

        [SerializeField]
        public UInt32 SourceIndex;

        [SerializeField]
        public UInt32 MeshIndex;

        [SerializeField]
        public UInt32 WindowIndex;

        [SerializeField]
        public Vector2 ViewportOrigin;

        [SerializeField]
        public Vector2 ViewportSize;
    }

} // namespace VARLab.ExternalDisplay
