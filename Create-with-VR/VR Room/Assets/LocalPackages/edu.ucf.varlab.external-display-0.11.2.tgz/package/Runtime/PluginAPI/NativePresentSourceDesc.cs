
// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    // NOTE: This type must match the layout of NativePresentSourceDesc in
    //       PluginSource/Source/NativePresentSourceDesc.hpp
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class NativePresentSourceDesc
    {
        public const UInt32 InvalidIndex = 0xFFFFFFFF;

        [System.NonSerialized]
        public UInt32 Index = InvalidIndex;

        [SerializeField]
        public IntPtr NativeTexture = IntPtr.Zero;
    }

} // namespace VARLab.ExternalDisplay
