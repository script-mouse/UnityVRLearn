
// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    // NOTE: This type must match the layout of NativeWarpMeshDesc in
    //       PluginSource/Source/NativeWarpMeshDesc.hpp
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class NativeWarpMeshDesc
    {
        public const UInt32 InvalidIndex = 0xFFFFFFFF;

        [System.NonSerialized]
        public UInt32 Index = InvalidIndex;

        [SerializeField]
        public string Name = string.Empty;

        [SerializeField]
        public UInt32 VertexCount = 0u;

        [SerializeField]
        public UInt32 IndexCount = 0u;

        [SerializeField]
        [Tooltip("Native Graphics API handle for the index buffer")]
        public IntPtr NativeIndexBuffer = IntPtr.Zero;

        [SerializeField]
        [Tooltip("Native Graphics API handle for the vertex buffer")]
        public IntPtr NativeVertexBuffer = IntPtr.Zero;

        [SerializeField]
        [Tooltip("CPU memory pointer for the index buffer")]
        public IntPtr IndexData = IntPtr.Zero;

        [SerializeField]
        [Tooltip("CPU memory pointer for the vertex buffer")]
        public IntPtr VertexData = IntPtr.Zero;
    }

} // namespace VARLab.ExternalDisplay
