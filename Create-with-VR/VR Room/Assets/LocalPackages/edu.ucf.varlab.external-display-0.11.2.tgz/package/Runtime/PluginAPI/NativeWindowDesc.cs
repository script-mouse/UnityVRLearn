
// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    // NOTE: This type must match the layout of NativeWindowDesc in
    //       PluginSource/Source/NativeWindowDesc.hpp
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class NativeWindowDesc
        : ICloneable
    {
        public const UInt32 InvalidIndex = 0xFFFFFFFF;
        public const UInt32 UnityDeviceIndex = 0xFFFFFFFF;

        [NonSerialized]
        public UInt32 Index = InvalidIndex;

        [SerializeField]
        public string Name = string.Empty;

        [SerializeField]
        public UInt32 DeviceIndex = UnityDeviceIndex;

        [SerializeField]
        public Vector2Int Position = Vector2Int.zero;

        [SerializeField]
        public Vector2Int Size = Vector2Int.zero;

        public NativeWindowDesc Clone()
        {
            NativeWindowDesc clone = (NativeWindowDesc)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }
    }

} // namespace VARLab.ExternalDisplay
