
// system namespaces
using System;
using System.IO;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;
using UnityEngine.Rendering;

namespace VARLab.ExternalDisplay
{
    public static class PluginAPI
    {
        public static ErrorCode Enable()
        {
#if UNITY_EDITOR
            // Editor window has application path in title - extract it from dataPath
            DirectoryInfo dataPathInfo = new DirectoryInfo(Application.dataPath);
            string windowTitle = dataPathInfo.Parent.Name;
#else
            // Player window has product name in title
            string windowTitle = Application.productName;
#endif

            ErrorCode ec = NativeEnable(Application.isEditor, windowTitle);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to enable ExternalDisplay native plugin");
                return ec;
            }

            return ec;
        }

        public static ErrorCode Disable()
        {
            return NativeDisable();
        }

        public static ErrorCode CreateDevice(NativeDeviceDesc nativeDeviceDesc)
        {
            ErrorCode ec = NativeCreateDevice(nativeDeviceDesc, out UInt32 deviceIdx);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to create device");
                nativeDeviceDesc.Index = NativeDeviceDesc.InvalidIndex;
                return ec;
            }

            nativeDeviceDesc.Index = deviceIdx;
            return ec;
        }

        public static ErrorCode DestroyDevice(UInt32 deviceIdx)
        {
            return NativeDestroyDevice(deviceIdx);
        }

        /// <summary>
        /// Creates a new window for presenting rendered content using the settings from
        /// <paramref name="nativeWindowDesc" />.
        /// On success <c>ErrorCode.Success</c> is returned and <c>nativeWindowDesc.Index</c>
        /// is set to the index of the new window.
        /// </summary>
        public static ErrorCode CreatePresentWindow(NativeWindowDesc nativeWindowDesc)
        {
            ErrorCode ec = NativeCreatePresentWindow(
                nativeWindowDesc, out UInt32 windowIdx);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to create present window");
                nativeWindowDesc.Index = NativeWindowDesc.InvalidIndex;
                return ec;
            }

            nativeWindowDesc.Index = windowIdx;
            return ec;
        }

        public static ErrorCode DestroyPresentWindow(UInt32 windowIdx)
        {
            return NativeDestroyPresentWindow(windowIdx);
        }

        public static ErrorCode UpdatePresentWindow(NativeWindowDesc nativeWindowDesc)
        {
            ErrorCode ec = NativeUpdatePresentWindow(nativeWindowDesc);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError(
                    $"Failed to update present window {nativeWindowDesc.Index} "
                    + $"'{nativeWindowDesc.Name}'!");
            }

            return ec;
        }

        /// <summary>
        /// Registers a new source for presentation data, passing information about the source
        /// texture in <paramref name="nativeSourceDesc" />.
        /// On success <c>ErrorCode.Success</c> is returned and
        /// <c>nativeSourceDesc.Index</c> is set to the index of the presentation source.
        /// </summary>
        public static ErrorCode RegisterPresentSource(
            NativePresentSourceDesc nativeSourceDesc)
        {
            ErrorCode ec = NativeRegisterPresentSource(
                nativeSourceDesc, out UInt32 presentSourceIdx);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to create present source");
                nativeSourceDesc.Index = NativePresentSourceDesc.InvalidIndex;
                return ec;
            }

            nativeSourceDesc.Index = presentSourceIdx;
            return ec;
        }

        public static ErrorCode UpdatePresentSource(NativePresentSourceDesc nativeSourceDesc)
        {
            ErrorCode ec = NativeUpdatePresentSource(nativeSourceDesc);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError($"Failed to update present source {nativeSourceDesc.Index}!");
            }

            return ec;
        }

        public static ErrorCode UnregisterPresentSource(UInt32 sourceIdx)
        {
            return NativeUnregisterPresentSource(sourceIdx);
        }

        /// <summary>
        /// Registers a new native presentation mesh using the settings from
        /// <paramref name="nativeMeshDesc" />.
        /// </summary>
        public static ErrorCode RegisterWarpMesh(NativeWarpMeshDesc nativeMeshDesc)
        {
            ErrorCode ec = NativeRegisterWarpMesh(
                nativeMeshDesc, out UInt32 warpMeshIdx);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to create present mesh");
                nativeMeshDesc.Index = NativeWarpMeshDesc.InvalidIndex;
                return ec;
            }

            nativeMeshDesc.Index = warpMeshIdx;
            return ec;
        }

        public static ErrorCode UnregisterWarpMesh(UInt32 meshIdx)
        {
            return NativeUnregisterWarpMesh(meshIdx);
        }

        /// <summary>
        /// Creates a new presentation operation, which draws the
        /// given present source and present mesh to a viewport rectangle on a present window.
        /// </summary>
        public static ErrorCode CreatePresentOperation(
            NativePresentOperationDesc nativeOperationDesc)
        {
            ErrorCode ec = NativeCreatePresentOperation(
                nativeOperationDesc, out UInt32 operationIdx);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError("Failed to create present operation");
                nativeOperationDesc.Index = NativePresentOperationDesc.InvalidIndex;
                return ec;
            }

            nativeOperationDesc.Index = operationIdx;
            return ec;
        }

        public static ErrorCode DestroyPresentOperation(UInt32 operationIdx)
        {
            return NativeDestroyPresentOperation(operationIdx);
        }

        public static ErrorCode SetSwapGroupEnabled(bool enabled)
        {
            return NativeSetSwapGroupEnabled(enabled);
        }

        public static ErrorCode SetSwapInterval(UInt32 interval)
        {
            ErrorCode ec = NativeSetSwapInterval(interval);

            if (ec != ErrorCode.Success)
            {
                Debug.LogError($"Failed to set swap interval to {interval}");
            }

            return ec;
        }

        public static ErrorCode PresentWindows()
        {
            ErrorCode ec = NativePresentWindows();

            if (ec != ErrorCode.Success)
            {
                Debug.LogError($"Failed to set perform 'PresentWindows' operation");
            }

            return ec;
        }

        /// <summary>
        /// Append command to issue the "DrawWindows" event to <paramref name="cmd"/>
        /// </summary>
        /// <param name="cmd"><c>CommandBuffer</c> to append an <c>IssuePluginEventAndData</c>
        /// command.</param>
        public static void CmdDrawWindows(CommandBuffer cmd)
        {
            cmd.IssuePluginEventAndData(
                GetGraphicsEventsCallback(), (int)PluginGraphicsEvents.DrawWindows,
                IntPtr.Zero);
        }

        public static void CmdPresentWindows(CommandBuffer cmd)
        {
            cmd.IssuePluginEventAndData(
                GetGraphicsEventsCallback(), (int)PluginGraphicsEvents.PresentWindows,
                IntPtr.Zero);
        }

        // ------------------------------------------------------------------
        #region Native DLL API

        private const string k_pluginName = "ExternalDisplayPlugin";

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_Enable")]
        internal static extern ErrorCode NativeEnable(
            [In] bool unityEditor, [In] string windowTitle);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_Disable")]
        internal static extern ErrorCode NativeDisable();

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_CreateDevice")]
        internal static extern ErrorCode NativeCreateDevice(
            [In] NativeDeviceDesc nativeDeviceDesc, [Out] out UInt32 deviceIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_DestroyDevice")]
        internal static extern ErrorCode NativeDestroyDevice([In] UInt32 deviceIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_CreatePresentWindow")]
        internal static extern ErrorCode NativeCreatePresentWindow(
            [In] NativeWindowDesc nativeWindowDesc, [Out] out UInt32 windowIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_DestroyPresentWindow")]
        internal static extern ErrorCode NativeDestroyPresentWindow([In] UInt32 windowIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_UpdatePresentWindow")]
        internal static extern ErrorCode NativeUpdatePresentWindow(
            [In] NativeWindowDesc nativeWindowDesc);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_RegisterPresentSource")]
        internal static extern ErrorCode NativeRegisterPresentSource(
            [In] NativePresentSourceDesc nativeSourceDesc, [Out] out UInt32 sourceIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_UpdatePresentSource")]
        internal static extern ErrorCode NativeUpdatePresentSource(
            [In] NativePresentSourceDesc nativeSourceDesc);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_UnregisterPresentSource")]
        internal static extern ErrorCode NativeUnregisterPresentSource(
            [In] UInt32 sourceIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_RegisterWarpMesh")]
        internal static extern ErrorCode NativeRegisterWarpMesh(
            [In] NativeWarpMeshDesc nativeMeshDesc, [Out] out UInt32 meshIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_UnregisterWarpMesh")]
        internal static extern ErrorCode NativeUnregisterWarpMesh([In] UInt32 meshIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_CreatePresentOperation")]
        internal static extern ErrorCode NativeCreatePresentOperation(
            [In] NativePresentOperationDesc nativeOperationDesc, [Out] out UInt32 operationIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_DestroyPresentOperation")]
        internal static extern ErrorCode NativeDestroyPresentOperation(UInt32 operationIdx);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_SetSwapGroupEnabled")]
        internal static extern ErrorCode NativeSetSwapGroupEnabled(bool enabled);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_SetSwapInterval")]
        internal static extern ErrorCode NativeSetSwapInterval(UInt32 interval);

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_PresentWindows")]
        internal static extern ErrorCode NativePresentWindows();

        #endregion Native DLL API
        // // ==================================================================
        #region Private API

        [DllImport(
            k_pluginName,
            EntryPoint = "ExternalDisplayPlugin_GetGraphicsEventsCallback")]
        private static extern IntPtr GetGraphicsEventsCallback();

        #endregion Private API
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
