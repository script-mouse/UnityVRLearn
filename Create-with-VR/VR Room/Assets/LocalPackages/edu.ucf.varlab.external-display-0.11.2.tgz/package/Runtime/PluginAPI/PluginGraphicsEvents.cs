// system namespaces
using System;
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{

    // NOTE: This enum must match PluginGraphicsEvents in
    //       PluginSource/Source/PluginGraphicsEvents.hpp
    internal enum PluginGraphicsEvents
    {
        DrawWindows = 0,
        PresentWindows = 1,
    }

} // namespace VARLab.ExternalDisplay
