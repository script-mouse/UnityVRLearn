
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Information about a presentation operation - displays (part of) the content rendered
    /// by a source camera to a window after applying a warp mesh.
    /// </summary>
    [Serializable]
    public sealed class PresentInfo
            : ICloneable
    {
        [Tooltip("Name of this present info (must be unique)")]
        public string name = string.Empty;

        [Tooltip("Name of window to present to")]
        public string targetWindow = string.Empty;

        [Tooltip("Name of warp mesh to use for present")]
        public string warpMesh = string.Empty;

        [Tooltip("Camera that renders the view being presented")]
        public Camera sourceCamera = null;

        [Tooltip("How 'Viewport Rect' is interpreted")]
        public CoordinateMode viewportCoordinateMode = CoordinateMode.Normalized;

        [Tooltip("Area on 'Target Window' that is being presented to")]
        public Rect viewportRect = new Rect(Vector2.zero, Vector2.one);

        [NonSerialized]
        internal NativePresentOperationDesc presentDesc = null;

        // --------------------------------------------------------------
        #region ICloneable

        public PresentInfo Clone()
        {
            PresentInfo clone = (PresentInfo)MemberwiseClone();
            // presentDesc is not cloned!
            clone.presentDesc = null;

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
