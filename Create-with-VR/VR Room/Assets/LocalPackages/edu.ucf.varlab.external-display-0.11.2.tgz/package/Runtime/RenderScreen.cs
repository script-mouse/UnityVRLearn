
// unity namespace
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    public class RenderScreen
        : MonoBehaviour
    {
        // ----------------------------------------------------------------------
        #region Properties

        public Vector2 size
        {
            get => m_size;
            set => m_size = value;
        }

        #endregion // Properties
        // ----------------------------------------------------------------------
        #region Fields

        [SerializeField]
        private Vector2 m_size;

        #endregion // Fields
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        private void OnDrawGizmos()
        {
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = new Color(Color.yellow.r, Color.yellow.g, Color.yellow.b, 0.25f);

            Mesh quadMesh = Resources.GetBuiltinResource<Mesh>("Quad.fbx");
            Gizmos.DrawMesh(
                quadMesh, 0, Vector3.zero, Quaternion.identity,
                new Vector3(m_size.x, m_size.y, 1.0f));
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
