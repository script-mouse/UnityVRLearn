
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public sealed class RenderScreenInfo
        : ICloneable
    {
        [Tooltip("Name of this render screen GameObject (must be unique)")]
        public string name = string.Empty;

        [Tooltip("Local position of the render screen")]
        public Vector3 position = Vector3.zero;

        [Tooltip("Local rotation of the render screen")]
        public Quaternion rotation = Quaternion.identity;

        [Tooltip("Size of the render screen")]
        public Vector2 size = Vector2.zero;

        // --------------------------------------------------------------
        #region ICloneable

        public RenderScreenInfo Clone()
        {
            RenderScreenInfo clone = (RenderScreenInfo)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
