
// unity namespace
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class RenderViewCamera
        : MonoBehaviour
    {
        // ------------------------------------------------------------------
        #region Properties

        public Camera.MonoOrStereoscopicEye eye
        {
            get => m_eye;
            set => SetEye(value);
        }

        public float ipdValue
        {
            get => m_ipdValue;
            set => SetIPDValue(value);
        }

        #endregion // Properties
        // ------------------------------------------------------------------

        [SerializeField]
        private Camera.MonoOrStereoscopicEye m_eye = Camera.MonoOrStereoscopicEye.Left;

        [SerializeField]
        private RenderScreen m_screen;

        [SerializeField]
        [Tooltip("Minimum distance from the screen the camera will keep.")]
        private float m_minScreenDistance = 0.05f;

        private float m_ipdValue = 0.063f;
        private Camera m_camera;
        private Transform m_transform;
        private Transform m_screenTransform;
        private Vector3 m_ipdOffset;
        private RenderViewCameraOriginBase m_cameraOrigin = null;

        private int m_initialCullingMask;
        private bool m_originPoseUpdatedBound = false;

        private const string k_leftEyeOnlyLayerName = "LeftEyeOnly";
        private const string k_rightEyeOnlyLayerName = "RightEyeOnly";

        // ----------------------------------------------------------------------
        #region API

        public void SetIPDValue(float value)
        {
            m_ipdValue = value;
            UpdateIPDOffset(m_ipdValue);
        }

        public void SetEye(Camera.MonoOrStereoscopicEye newEye)
        {
            m_eye = newEye;
            UpdateEye(m_eye);
        }

        #endregion // API
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        private void Awake()
        {
            Assert.IsNotNull(m_screen);

            m_camera = GetComponent<Camera>();
            Assert.IsNotNull(m_camera);

            m_transform = transform;
            m_screenTransform = m_screen.GetComponent<Transform>();
        }

        private void Start()
        {
            m_initialCullingMask = m_camera.cullingMask;

            UpdateIPDOffset(m_ipdValue);
            UpdateCullingMask();

            // Update view/projection for initial position of camera
            UpdateViewProjection();
        }

        private void OnEnable()
        {
            BindCameraOrigin();
        }

        private void OnDisable()
        {
            UnbindCameraOrigin();
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        private void UpdateEye(Camera.MonoOrStereoscopicEye newEye)
        {
            UpdateIPDOffset(m_ipdValue);
        }

        private void UpdateIPDOffset(float newIpdValue)
        {
            switch (m_eye)
            {
                case Camera.MonoOrStereoscopicEye.Mono:
                    m_ipdOffset = Vector3.zero;
                    break;

                case Camera.MonoOrStereoscopicEye.Left:
                    m_ipdOffset = 0.5f * newIpdValue * Vector3.left;
                    break;

                case Camera.MonoOrStereoscopicEye.Right:
                    m_ipdOffset = 0.5f * newIpdValue * Vector3.right;
                    break;
            }
        }

        private void UpdateCullingMask()
        {
            int cullingMask = m_initialCullingMask;
            int maskL = LayerMask.GetMask(k_leftEyeOnlyLayerName);
            int maskR = LayerMask.GetMask(k_rightEyeOnlyLayerName);
            int maskLR = maskL | maskR;

            switch (m_eye)
            {
                case Camera.MonoOrStereoscopicEye.Mono:
                    cullingMask = cullingMask | maskLR;
                    break;

                case Camera.MonoOrStereoscopicEye.Left:
                    cullingMask = (cullingMask & ~maskLR) | maskL;
                    break;

                case Camera.MonoOrStereoscopicEye.Right:
                    cullingMask = (cullingMask & ~maskLR) | maskR;
                    break;
            }

            m_camera.cullingMask = cullingMask;
        }

        private void UpdateViewProjection()
        {
            // position camera at eye offset and align with screen
            m_transform.rotation = m_screenTransform.rotation;
            m_transform.localPosition = m_ipdOffset;

            // eye position relative to screen center
            Vector3 eyePos = m_screenTransform.InverseTransformPoint(m_transform.position);

            if (m_minScreenDistance > 0.0f && eyePos.z > -m_minScreenDistance)
            {
                // eye is closer to screen than min distance (screen z points into the screen,
                // so positions in front of the screen have negative z
                eyePos.z = -m_minScreenDistance;
                m_transform.position = m_screenTransform.TransformPoint(eyePos);
            }

            Vector2 screenSize = m_screen.size;
            float scale = -m_camera.nearClipPlane / Mathf.Min(-0.001f, eyePos.z);
            float left = (-0.5f * screenSize.x - eyePos.x) * scale;
            float right = (0.5f * screenSize.x - eyePos.x) * scale;
            float top = (0.5f * screenSize.y - eyePos.y) * scale;
            float bottom = (-0.5f * screenSize.y - eyePos.y) * scale;

            m_camera.projectionMatrix = Matrix4x4.Frustum(
                left, right, bottom, top, m_camera.nearClipPlane, m_camera.farClipPlane);
        }

        private void BindCameraOrigin()
        {
            if (m_originPoseUpdatedBound)
                return;

            if (m_cameraOrigin == null)
                m_cameraOrigin = GetComponentInParent<RenderViewCameraOriginBase>();

            if (m_cameraOrigin == null)
            {
                Debug.LogWarning($"RenderViewCamera '{name}' has no RenderViewCameraOriginBase!");
                return;
            }

            m_cameraOrigin.onPoseUpdated += HandleCameraOriginPoseUpdated;
            m_originPoseUpdatedBound = true;
        }

        private void UnbindCameraOrigin()
        {
            if (!m_originPoseUpdatedBound)
                return;

            if (m_cameraOrigin == null)
                return;

            m_cameraOrigin.onPoseUpdated -= HandleCameraOriginPoseUpdated;
            m_originPoseUpdatedBound = false;
        }

        private void HandleCameraOriginPoseUpdated(RenderViewCameraOriginBase cameraOrigin)
        {
            UpdateViewProjection();
        }
    }

} // namespace VARLab.ExternalDisplay
