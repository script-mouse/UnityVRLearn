
// system namespaces
using System;
// unity namespace
using UnityEngine;
using UnityEngine.XR;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Base class for head tracked camera rigs.
    /// Derived classes should read the tracking system data and then call <c>UpdateTrackerPose</c>
    /// to store the values.
    /// </summary>
    public abstract class RenderViewCameraOriginBase
        : MonoBehaviour
    {
        // ----------------------------------------------------------------------
        #region Properties

        public event Action<RenderViewCameraOriginBase> onPoseUpdated;

        public Vector3 defaultPosition
        {
            get => m_defaultPosition;
            set => m_defaultPosition = value;
        }

        public Quaternion defaultRotation
        {
            get => m_defaultRotation;
            set => m_defaultRotation = value;
        }

        public Vector3 positionOffset
        {
            get => m_positionOffset;
            set => SetPositionOffset(value);
        }

        public Quaternion rotationOffset
        {
            get => m_rotationOffset;
            set => SetRotationOffset(value);
        }

        public bool ignoreTrackingState
        {
            get => m_ignoreTrackingState;
            set => SetIgnoreTrackingState(value);
        }

        #endregion // Properties
        // ----------------------------------------------------------------------
        #region Fields

        [SerializeField]
        [Tooltip("Tracker position used when no tracking data is available")]
        protected Vector3 m_defaultPosition = Vector3.zero;

        [SerializeField]
        [Tooltip("Tracker rotation used when no tracking data is available")]
        protected Quaternion m_defaultRotation = Quaternion.identity;

        [SerializeField]
        [Tooltip("Offset applied to tracking data (correct for tracker <-> eye offset)")]
        protected Vector3 m_positionOffset = Vector3.zero;
        [SerializeField]
        [Tooltip("Offset applied to tracking data (correct for tracker <-> eye offset)")]
        protected Quaternion m_rotationOffset = Quaternion.identity;

        [SerializeField]
        [Tooltip("Ignore tracking state and always treat input poses as valid")]
        protected bool m_ignoreTrackingState = false;

        protected Transform m_transform;
        // m_trackerPose is the values read from the tracker
        protected Pose m_trackerPose = Pose.identity;
        // m_currentPose has m_positionOffset,m_rotationOffset applied
        protected Pose m_currentPose = Pose.identity;
        protected InputTrackingState m_currentTrackingState = InputTrackingState.None;

        #endregion // Fields
        // ----------------------------------------------------------------------
        #region Public API

        public void SetOffsetPose(Vector3 positionOffset, Quaternion rotationOffset)
        {
            m_positionOffset = positionOffset;
            m_rotationOffset = rotationOffset;

            UpdateTrackerPose(
                m_trackerPose.position, m_trackerPose.rotation,
                m_currentTrackingState, m_ignoreTrackingState);
        }

        public void SetOffsetPose(Pose offsetPose)
        {
            SetOffsetPose(offsetPose.position, offsetPose.rotation);
        }

        public void SetIgnoreTrackingState(bool ignore)
        {
            m_ignoreTrackingState = ignore;
            UpdateTrackerPose(
                m_trackerPose.position, m_trackerPose.rotation,
                m_currentTrackingState, m_ignoreTrackingState);
        }

        #endregion // Public API
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            m_transform = GetComponent<Transform>();
        }

        protected virtual void OnEnable()
        {
        }

        protected virtual void OnDisable()
        {
            // sets m_default{Position,Rotation} while preserving m_trackerPose
            UpdateTrackerPose(
                m_trackerPose.position, m_trackerPose.rotation, InputTrackingState.None, false);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        protected void SetPositionOffset(Vector3 newOffset)
        {
            SetOffsetPose(newOffset, m_rotationOffset);
        }

        protected void SetRotationOffset(Quaternion newOffset)
        {
            SetOffsetPose(m_positionOffset, newOffset);
        }

        /// <summary>
        /// Updates the tracker pose in local space.
        /// </summary>
        /// <param name="position">Tracker position</param>
        /// <param name="rotation">Tracker rotation</param>
        /// <param name="trackingState">Tracking state indicating validity of
        /// <c>position</c>/<c>rotation</c></param>
        protected void UpdateTrackerPose(
            Vector3 position, Quaternion rotation, InputTrackingState trackingState,
            bool ignoreTrackingState)
        {
            m_trackerPose.position = position;
            m_trackerPose.rotation = rotation;

            Pose activePose;

            if ((trackingState & InputTrackingState.Position) != 0 || ignoreTrackingState)
            {
                activePose.position = m_trackerPose.position;
            }
            else
            {
                activePose.position = m_defaultPosition;
            }

            if ((trackingState & InputTrackingState.Rotation) != 0 || ignoreTrackingState)
            {
                activePose.rotation = m_trackerPose.rotation;
            }
            else
            {
                activePose.rotation = m_defaultRotation;
            }

            // apply offsets
            m_currentPose.rotation = activePose.rotation * m_rotationOffset;
            m_currentPose.position
                = activePose.position + m_currentPose.rotation * m_positionOffset;
            m_currentTrackingState = trackingState;

            // update local transform
            m_transform.SetLocalPositionAndRotation(m_currentPose.position, m_currentPose.rotation);
            onPoseUpdated?.Invoke(this);
        }
    }

} // namespace VARLab.ExternalDisplay
