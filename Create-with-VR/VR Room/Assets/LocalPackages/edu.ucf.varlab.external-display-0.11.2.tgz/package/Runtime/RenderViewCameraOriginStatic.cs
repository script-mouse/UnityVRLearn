
// unity namespace
using UnityEngine;
using UnityEngine.XR;

namespace VARLab.ExternalDisplay.OpenXR
{
    // RenderViewCameraOrigin for static (non-head tracked) setups.
    public class RenderViewCameraOriginStatic
        : RenderViewCameraOriginBase
    {
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected void LateUpdate()
        {
            // Ensure projection is updated after settings.json overrides are applied
            UpdateTrackerPose(
                Vector3.zero, Quaternion.identity, InputTrackingState.None, m_ignoreTrackingState);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay.OpenXR
