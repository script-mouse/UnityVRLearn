

// system namespaces
using System;
using System.Collections.Generic;

// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    public class ExternalDisplaySettings
        : ICloneable
    {
        public IList<WindowOverride> windowOverrides
        {
            get => m_windowOverrides;
            set => m_windowOverrides = new List<WindowOverride>(value);
        }

        public IList<WarpMeshOverride> warpMeshOverrides
        {
            get => m_warpMeshOverrides;
            set => m_warpMeshOverrides = new List<WarpMeshOverride>(value);
        }

        public IList<PresentInfoOverride> presentOverrides
        {
            get => m_presentOverrides;
            set => m_presentOverrides = new List<PresentInfoOverride>(value);
        }

        public TrackingOriginOverride trackingOriginOverride
        {
            get => m_trackingOriginOverride;
            set => m_trackingOriginOverride = value;
        }

        public IList<RenderScreenOverride> renderScreenOverrides
        {
            get => m_renderScreenOverrides;
            set => m_renderScreenOverrides = new List<RenderScreenOverride>(value);
        }

        public IList<SourceCameraInfoOverride> sourceCameraInfoOverrides
        {
            get => m_sourceCameraInfoOverrides;
            set => m_sourceCameraInfoOverrides = new List<SourceCameraInfoOverride>(value);
        }

        private List<WindowOverride> m_windowOverrides = new List<WindowOverride>();
        private List<WarpMeshOverride> m_warpMeshOverrides = new List<WarpMeshOverride>();
        private List<PresentInfoOverride> m_presentOverrides = new List<PresentInfoOverride>();
        private TrackingOriginOverride m_trackingOriginOverride = null;
        private List<RenderScreenOverride> m_renderScreenOverrides
            = new List<RenderScreenOverride>();
        private List<SourceCameraInfoOverride> m_sourceCameraInfoOverrides
            = new List<SourceCameraInfoOverride>();

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<ExternalDisplaySettings> context,
            ExternalDisplaySettings settings)
        {
            using (context.Writer.WriteObjectScope())
            {
                if (settings.m_windowOverrides.Count > 0)
                {
                    SerializationUtils.SerializeList(
                        context, settings.m_windowOverrides, "windowOverrides");
                }

                if (settings.m_warpMeshOverrides.Count > 0)
                {
                    SerializationUtils.SerializeList(
                        context, settings.m_warpMeshOverrides, "warpMeshOverrides");
                }

                if (settings.m_presentOverrides.Count > 0)
                {
                    SerializationUtils.SerializeList(
                        context, settings.m_presentOverrides, "presentOverrides");
                }

                if (settings.m_trackingOriginOverride != null)
                {
                    context.SerializeValue(
                        "trackingOriginOverride", settings.m_trackingOriginOverride);
                }

                if (settings.m_renderScreenOverrides.Count > 0)
                {
                    SerializationUtils.SerializeList(
                        context, settings.m_renderScreenOverrides, "renderScreenOverrides");
                }

                if (settings.m_sourceCameraInfoOverrides.Count > 0)
                {
                    SerializationUtils.SerializeList(
                        context, settings.m_sourceCameraInfoOverrides, "sourceCameraOverrides");
                }
            }
        }

        public static ExternalDisplaySettings Deserialize(
            in JsonDeserializationContext<ExternalDisplaySettings> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            ExternalDisplaySettings settings = new ExternalDisplaySettings();
            if (objectView.TryGetValue(
                "windowOverrides", out SerializedValueView windowOverridesView))
            {
                settings.m_windowOverrides = SerializationUtils.DeserializeList<WindowOverride>(
                    context, windowOverridesView.AsArrayView());
            }

            if (objectView.TryGetValue(
                "warpMeshOverrides", out SerializedValueView warpMeshOverridesView))
            {
                settings.m_warpMeshOverrides = SerializationUtils.DeserializeList<WarpMeshOverride>(
                    context, warpMeshOverridesView.AsArrayView());
            }

            if (objectView.TryGetValue(
                "presentOverrides", out SerializedValueView presentOverridesView))
            {
                settings.m_presentOverrides
                    = SerializationUtils.DeserializeList<PresentInfoOverride>(
                        context, presentOverridesView.AsArrayView());
            }

            if (objectView.TryGetValue(
                "trackingOriginOverride", out SerializedValueView trackingOriginOverrideView))
            {
                settings.m_trackingOriginOverride
                    = context.DeserializeValue<TrackingOriginOverride>(trackingOriginOverrideView);
            }

            if (objectView.TryGetValue(
                "renderScreenOverrides", out SerializedValueView renderScreenOverridesView))
            {
                settings.m_renderScreenOverrides
                    = SerializationUtils.DeserializeList<RenderScreenOverride>(
                        context, renderScreenOverridesView.AsArrayView());
            }

            if (objectView.TryGetValue(
                "sourceCameraOverrides", out SerializedValueView sourceCameraOverridesView))
            {
                settings.m_sourceCameraInfoOverrides
                    = SerializationUtils.DeserializeList<SourceCameraInfoOverride>(
                        context, sourceCameraOverridesView.AsArrayView());
            }

            return settings;
        }

        #endregion Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public ExternalDisplaySettings Clone()
        {
            ExternalDisplaySettings clone = (ExternalDisplaySettings)MemberwiseClone();
            clone.m_windowOverrides = SerializationUtils.CloneList(m_windowOverrides);
            clone.m_warpMeshOverrides = SerializationUtils.CloneList(m_warpMeshOverrides);
            clone.m_presentOverrides = SerializationUtils.CloneList(m_presentOverrides);
            clone.m_trackingOriginOverride = m_trackingOriginOverride.Clone();
            clone.m_renderScreenOverrides = SerializationUtils.CloneList(m_renderScreenOverrides);

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
