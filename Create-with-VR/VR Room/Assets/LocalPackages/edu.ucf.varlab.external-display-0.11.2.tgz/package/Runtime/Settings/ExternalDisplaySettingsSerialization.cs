
// system namespaces
using System;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    // ----------------------------------------------------------------------
    #region CoordinateMode

    public class CoordinateModeJsonAdapter
        : IJsonAdapter<CoordinateMode>
    {
        public CoordinateMode Deserialize(in JsonDeserializationContext<CoordinateMode> context)
        {
            return SerializationUtils.DeserializeEnum<CoordinateMode>(context.SerializedValue);
        }

        public void Serialize(
            in JsonSerializationContext<CoordinateMode> context, CoordinateMode value)
        {
            SerializationUtils.SerializeEnum(context, value);
        }
    }

    #endregion // CoordinateMode
    // ----------------------------------------------------------------------
    #region WarpMeshStyle

    public class WarpMeshStyleJsonAdapter
        : IJsonAdapter<WarpMeshStyle>
    {
        public WarpMeshStyle Deserialize(in JsonDeserializationContext<WarpMeshStyle> context)
        {
            return SerializationUtils.DeserializeEnum<WarpMeshStyle>(context.SerializedValue);
        }

        public void Serialize(
            in JsonSerializationContext<WarpMeshStyle> context, WarpMeshStyle value)
        {
            SerializationUtils.SerializeEnum(context, value);
        }
    }

    #endregion // WarpMeshStyle
    // ----------------------------------------------------------------------
    #region WindowOverrideJsonAdapter

    public class WindowOverrideJsonAdapter
        : IJsonAdapter<WindowOverride>
    {
        public WindowOverride Deserialize(in JsonDeserializationContext<WindowOverride> context)
        {
            return WindowOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<WindowOverride> context, WindowOverride value)
        {
            WindowOverride.Serialize(in context, value);
        }
    }

    #endregion // WindowOverrideJsonAdapter
    // ----------------------------------------------------------------------
    #region RectJsonAdapter

    public class RectJsonAdapter
        : IJsonAdapter<Rect>
    {
        public Rect Deserialize(in JsonDeserializationContext<Rect> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            return new Rect(
                objectView["x"].AsFloat(),
                objectView["y"].AsFloat(),
                objectView["width"].AsFloat(),
                objectView["height"].AsFloat()
            );
        }

        public void Serialize(in JsonSerializationContext<Rect> context, Rect value)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("x", value.x);
                context.SerializeValue("y", value.y);
                context.SerializeValue("width", value.width);
                context.SerializeValue("height", value.height);
            }
        }
    }

    #endregion // RectJsonAdapter
    // ----------------------------------------------------------------------
    #region WarpMeshControlPointsJsonAdapter

    public class WarpMeshControlPointsJsonAdapter
        : IJsonAdapter<WarpMeshControlPoints>
    {
        public WarpMeshControlPoints Deserialize(
            in JsonDeserializationContext<WarpMeshControlPoints> context)
        {
            return WarpMeshControlPoints.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<WarpMeshControlPoints> context, WarpMeshControlPoints value)
        {
            WarpMeshControlPoints.Serialize(in context, value);
        }
    }

    #endregion // WarpMeshControlPointsJsonAdapter
    // ----------------------------------------------------------------------
    #region WarpMeshOverrideJsonAdapter

    public class WarpMeshOverrideJsonAdapter
        : IJsonAdapter<WarpMeshOverride>
    {
        public WarpMeshOverride Deserialize(
            in JsonDeserializationContext<WarpMeshOverride> context)
        {
            return WarpMeshOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<WarpMeshOverride> context,
            WarpMeshOverride warpMeshOverride)
        {
            WarpMeshOverride.Serialize(in context, warpMeshOverride);
        }
    }

    #endregion // WarpMeshOverrideJsonAdapter
    // ----------------------------------------------------------------------
    #region PresentInfoOverrideAdapter

    public class PresentInfoOverrideAdapter
        : IJsonAdapter<PresentInfoOverride>
    {
        public PresentInfoOverride Deserialize(
            in JsonDeserializationContext<PresentInfoOverride> context)
        {
            return PresentInfoOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<PresentInfoOverride> context,
            PresentInfoOverride presentOverride)
        {
            PresentInfoOverride.Serialize(in context, presentOverride);
        }
    }

    #endregion // PresentInfoOverrideAdapter
    // ----------------------------------------------------------------------
    #region TrackingOriginOverrideAdapter

    public class TrackingOriginOverrideAdapter
        : IJsonAdapter<TrackingOriginOverride>
    {
        public TrackingOriginOverride Deserialize(
            in JsonDeserializationContext<TrackingOriginOverride> context)
        {
            return TrackingOriginOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<TrackingOriginOverride> context,
            TrackingOriginOverride trackingOriginOverride)
        {
            TrackingOriginOverride.Serialize(in context, trackingOriginOverride);
        }
    }

    #endregion // TrackingOriginOverrideAdapter
    // ----------------------------------------------------------------------
    #region RenderScreenOverrideAdapter

    public class RenderScreenOverrideAdapter
        : IJsonAdapter<RenderScreenOverride>
    {
        public RenderScreenOverride Deserialize(
            in JsonDeserializationContext<RenderScreenOverride> context)
        {
            return RenderScreenOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<RenderScreenOverride> context,
            RenderScreenOverride renderScreenOverride)
        {
            RenderScreenOverride.Serialize(in context, renderScreenOverride);
        }
    }

    #endregion // RenderScreenOverrideAdapter
    // ----------------------------------------------------------------------
    #region SourceCameraInfoOverrideAdapter

    public class SourceCameraInfoOverrideAdapter
        : IJsonAdapter<SourceCameraInfoOverride>
    {
        public SourceCameraInfoOverride Deserialize(
            in JsonDeserializationContext<SourceCameraInfoOverride> context)
        {
            return SourceCameraInfoOverride.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<SourceCameraInfoOverride> context,
            SourceCameraInfoOverride sourceCameraOverride)
        {
            SourceCameraInfoOverride.Serialize(in context, sourceCameraOverride);
        }
    }

    #endregion // SourceCameraInfoOverrideAdapter
    // ----------------------------------------------------------------------
    #region ExternalDisplaySettingsJsonAdapter

    public class ExternalDisplaySettingsJsonAdapter
        : IJsonAdapter<ExternalDisplaySettings>
    {
        public ExternalDisplaySettings Deserialize(
            in JsonDeserializationContext<ExternalDisplaySettings> context)
        {
            return ExternalDisplaySettings.Deserialize(in context);
        }

        public void Serialize(
            in JsonSerializationContext<ExternalDisplaySettings> context,
            ExternalDisplaySettings settings)
        {
            ExternalDisplaySettings.Serialize(in context, settings);
        }
    }

    #endregion // ExternalDisplaySettingsJsonAdapter
    // ----------------------------------------------------------------------

} // namespace VARLab.ExternalDisplay
