

// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    public class PresentInfoOverride
        : ICloneable
    {
        public string name
        {
            get => m_name;
            set => m_name = value;
        }

        public string targetWindow
        {
            get => m_targetWindow;
            set
            {
                m_targetWindow = value;
                m_overrideFlags[k_hasTargetWindowBit] = true;
            }
        }

        public bool hasTargetWindowOverride
        {
            get => m_overrideFlags[k_hasTargetWindowBit];
        }

        public string warpMesh
        {
            get => m_warpMesh;
            set
            {
                m_warpMesh = value;
                m_overrideFlags[k_hasWarpMeshBit] = true;
            }
        }

        public bool hasWarpMeshOverride
        {
            get => m_overrideFlags[k_hasWarpMeshBit];
        }

        public string sourceCamera
        {
            get => m_sourceCamera;
            set
            {
                m_sourceCamera = value;
                m_overrideFlags[k_hasSourceCameraBit] = true;
            }
        }

        public bool hasSourceCameraOverride
        {
            get => m_overrideFlags[k_hasSourceCameraBit];
        }

        public CoordinateMode viewportCoordinateMode
        {
            get => m_viewportCoordinateMode;
            set
            {
                m_viewportCoordinateMode = value;
                m_overrideFlags[k_hasViewportCoordinateModeBit] = true;
            }
        }

        public bool hasViewportCoordinateModeOverride
        {
            get => m_overrideFlags[k_hasViewportCoordinateModeBit];
        }

        public Rect viewportRect
        {
            get => m_viewportRect;
            set
            {
                m_viewportRect = value;
                m_overrideFlags[k_hasViewportRectBit] = true;
            }
        }

        public bool hasViewportRectOverride
        {
            get => m_overrideFlags[k_hasViewportRectBit];
        }

        public bool hasOverrides
        {
            get => m_overrideFlags.Data != 0;
        }

        private string m_name;
        private string m_targetWindow;
        private string m_warpMesh;
        private string m_sourceCamera;
        private CoordinateMode m_viewportCoordinateMode;
        private Rect m_viewportRect;
        private BitVector32 m_overrideFlags;

        private static readonly int k_hasTargetWindowBit = BitVector32.CreateMask();
        private static readonly int k_hasWarpMeshBit = BitVector32.CreateMask(k_hasTargetWindowBit);
        private static readonly int k_hasSourceCameraBit = BitVector32.CreateMask(k_hasWarpMeshBit);
        private static readonly int k_hasViewportCoordinateModeBit
            = BitVector32.CreateMask(k_hasSourceCameraBit);
        private static readonly int k_hasViewportRectBit
            = BitVector32.CreateMask(k_hasViewportCoordinateModeBit);

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<PresentInfoOverride> context,
            PresentInfoOverride presentOverride)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("name", presentOverride.m_name);

                if (presentOverride.hasTargetWindowOverride)
                    context.SerializeValue("targetWindow", presentOverride.m_targetWindow);

                if (presentOverride.hasWarpMeshOverride)
                    context.SerializeValue("warpMesh", presentOverride.m_warpMesh);

                if (presentOverride.hasSourceCameraOverride)
                    context.SerializeValue("sourceCamera", presentOverride.m_sourceCamera);

                if (presentOverride.hasViewportCoordinateModeOverride)
                    context.SerializeValue(
                        "viewportCoordianteMode", presentOverride.m_viewportCoordinateMode);

                if (presentOverride.hasViewportRectOverride)
                    context.SerializeValue("viewportRect", presentOverride.m_viewportRect);
            }
        }

        public static PresentInfoOverride Deserialize(
            in JsonDeserializationContext<PresentInfoOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            PresentInfoOverride presentOverride = new PresentInfoOverride()
            {
                m_name = objectView["name"].AsStringView().ToString(),
            };

            if (objectView.TryGetValue("targetWindow", out SerializedValueView targetWindowView))
            {
                presentOverride.m_targetWindow = targetWindowView.AsStringView().ToString();
                presentOverride.m_overrideFlags[k_hasTargetWindowBit] = true;
            }

            if (objectView.TryGetValue("warpMesh", out SerializedValueView warpMeshView))
            {
                presentOverride.m_warpMesh = warpMeshView.AsStringView().ToString();
                presentOverride.m_overrideFlags[k_hasWarpMeshBit] = true;
            }

            if (objectView.TryGetValue("sourceCamera", out SerializedValueView sourceCameraView))
            {
                presentOverride.m_sourceCamera = sourceCameraView.AsStringView().ToString();
                presentOverride.m_overrideFlags[k_hasSourceCameraBit] = true;
            }

            if (objectView.TryGetValue(
                "viewportCoordianteMode", out SerializedValueView viewportCoordinateModeView))
            {
                presentOverride.m_viewportCoordinateMode
                    = SerializationUtils.DeserializeEnum<CoordinateMode>(
                        viewportCoordinateModeView);
                presentOverride.m_overrideFlags[k_hasViewportCoordinateModeBit] = true;
            }

            if (objectView.TryGetValue("viewportRect", out SerializedValueView viewportRectView))
            {
                presentOverride.m_viewportRect = context.DeserializeValue<Rect>(viewportRectView);
                presentOverride.m_overrideFlags[k_hasViewportRectBit] = true;
            }

            return presentOverride;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public PresentInfoOverride Clone()
        {
            PresentInfoOverride clone = (PresentInfoOverride)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
