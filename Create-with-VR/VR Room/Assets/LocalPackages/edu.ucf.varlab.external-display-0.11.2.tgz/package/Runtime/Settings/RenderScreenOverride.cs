
// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Allows overriding (some of) the settings of a <see cref="RenderScreen"/> from
    /// a configuration file.
    /// </summary>
    public class RenderScreenOverride
        : ICloneable
    {
        // ------------------------------------------------------------------
        #region Properties

        public string name
        {
            get => m_name;
            set => m_name = value;
        }

        public Vector3 position
        {
            get => m_position;
            set
            {
                m_position = value;
                m_overrideFlags[k_hasPositionBit] = true;
            }
        }

        public bool hasPositionOverride
        {
            get => m_overrideFlags[k_hasPositionBit];
            set => m_overrideFlags[k_hasPositionBit] = value;
        }

        public Quaternion rotation
        {
            get => m_rotation;
            set
            {
                m_rotation = value;
                m_overrideFlags[k_hasRotationBit] = true;
            }
        }

        public bool hasRotationOverride
        {
            get => m_overrideFlags[k_hasRotationBit];
            set => m_overrideFlags[k_hasRotationBit] = value;
        }

        public Vector2 size
        {
            get => m_size;
            set
            {
                m_size = value;
                m_overrideFlags[k_hasSizeBit] = true;
            }
        }

        public bool hasSizeOverride
        {
            get => m_overrideFlags[k_hasSizeBit];
            set => m_overrideFlags[k_hasSizeBit] = value;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        private string m_name;
        private Vector3 m_position;
        private Quaternion m_rotation;
        private Vector2 m_size;
        private BitVector32 m_overrideFlags;

        // constants for flags in m_overrideFlags
        private static readonly int k_hasPositionBit = BitVector32.CreateMask();
        private static readonly int k_hasRotationBit = BitVector32.CreateMask(k_hasPositionBit);
        private static readonly int k_hasSizeBit = BitVector32.CreateMask(k_hasRotationBit);

        #endregion // Fields
        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<RenderScreenOverride> context, RenderScreenOverride value)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("name", value.m_name);

                if (value.hasPositionOverride)
                {
                    SerializationUtils.SerializeVector3(context, value.m_position, "position");
                }

                if (value.hasRotationOverride)
                {
                    SerializationUtils.SerializeQuaternion(context, value.m_rotation, "rotation");
                }

                if (value.hasSizeOverride)
                {
                    SerializationUtils.SerializeVector2(context, value.m_size, "size");
                }
            }
        }

        public static RenderScreenOverride Deserialize(
            in JsonDeserializationContext<RenderScreenOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            RenderScreenOverride value = new RenderScreenOverride()
            {
                m_name = objectView["name"].AsStringView().ToString()
            };

            if (objectView.TryGetValue("position", out SerializedValueView positionView))
            {
                value.m_position
                    = SerializationUtils.DeserializeVector3(positionView.AsArrayView());
                value.m_overrideFlags[k_hasPositionBit] = true;
            }

            if (objectView.TryGetValue("rotation", out SerializedValueView rotationView))
            {
                value.m_rotation
                    = SerializationUtils.DeserializeQuaternion(rotationView.AsArrayView());
                value.m_overrideFlags[k_hasRotationBit] = true;
            }

            if (objectView.TryGetValue("size", out SerializedValueView sizeView))
            {
                value.m_size = SerializationUtils.DeserializeVector2(sizeView.AsArrayView());
                value.m_overrideFlags[k_hasSizeBit] = true;
            }

            return value;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public RenderScreenOverride Clone()
        {
            RenderScreenOverride clone = (RenderScreenOverride)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
