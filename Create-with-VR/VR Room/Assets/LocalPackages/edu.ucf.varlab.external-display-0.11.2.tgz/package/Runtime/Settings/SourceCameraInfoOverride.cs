
// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    public class SourceCameraInfoOverride
        : ICloneable
    {
        public string name
        {
            get => m_name;
            set => m_name = value;
        }

        public float ipdValue
        {
            get => m_ipdValue;
            set
            {
                m_ipdValue = value;
                m_overrideFlags[k_hasIPDValueBit] = true;
            }
        }

        public bool hasIPDValueOverride
        {
            get => m_overrideFlags[k_hasIPDValueBit];
        }

        private string m_name;
        private float m_ipdValue;
        private BitVector32 m_overrideFlags;

        private static readonly int k_hasIPDValueBit = BitVector32.CreateMask();

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<SourceCameraInfoOverride> context,
            SourceCameraInfoOverride sourceCameraOverride)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("name", sourceCameraOverride.m_name);

                if (sourceCameraOverride.hasIPDValueOverride)
                    context.SerializeValue("ipdValue", sourceCameraOverride.m_ipdValue);
            }
        }

        public static SourceCameraInfoOverride Deserialize(
            in JsonDeserializationContext<SourceCameraInfoOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            SourceCameraInfoOverride sourceCameraOverride = new SourceCameraInfoOverride()
            {
                m_name = objectView["name"].AsStringView().ToString(),
            };

            if (objectView.TryGetValue("ipdValue", out SerializedValueView ipdValueView))
            {
                sourceCameraOverride.m_ipdValue = ipdValueView.AsFloat();
                sourceCameraOverride.m_overrideFlags[k_hasIPDValueBit] = true;
            }

            return sourceCameraOverride;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public SourceCameraInfoOverride Clone()
        {
            SourceCameraInfoOverride clone = (SourceCameraInfoOverride)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
