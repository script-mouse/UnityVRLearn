
// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Allows setting the tracking origin offset from a settings file.
    /// </summary>
    public class TrackingOriginOverride
        : ICloneable
    {
        public Vector3 positionOffset
        {
            get => m_positionOffset;
            set
            {
                m_positionOffset = value;
                m_overrideFlags[k_hasPositionOffsetBit] = true;
            }
        }

        public bool hasPositionOffsetOverride
        {
            get => m_overrideFlags[k_hasPositionOffsetBit];
            set => m_overrideFlags[k_hasPositionOffsetBit] = value;
        }

        public Quaternion rotationOffset
        {
            get => m_rotationOffset;
            set
            {
                m_rotationOffset = value;
                m_overrideFlags[k_hasRotationOffsetBit] = true;
            }
        }

        public bool hasRotationOffsetOverride
        {
            get => m_overrideFlags[k_hasRotationOffsetBit];
            set => m_overrideFlags[k_hasRotationOffsetBit] = value;
        }

        private Vector3 m_positionOffset;
        private Quaternion m_rotationOffset;
        private BitVector32 m_overrideFlags;

        private static readonly int k_hasPositionOffsetBit = BitVector32.CreateMask();
        private static readonly int k_hasRotationOffsetBit
            = BitVector32.CreateMask(k_hasPositionOffsetBit);

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<TrackingOriginOverride> context,
            TrackingOriginOverride value)
        {
            using (context.Writer.WriteObjectScope())
            {
                if (value.hasPositionOffsetOverride)
                {
                    SerializationUtils.SerializeVector3(
                        context, value.m_positionOffset, "positionOffset");
                }

                if (value.hasRotationOffsetOverride)
                {
                    SerializationUtils.SerializeQuaternion(
                        context, value.m_rotationOffset, "rotationOffset");
                }
            }
        }

        public static TrackingOriginOverride Deserialize(
            in JsonDeserializationContext<TrackingOriginOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();
            TrackingOriginOverride trackingOriginOverride = new TrackingOriginOverride();

            if (objectView.TryGetValue(
                "positionOffset", out SerializedValueView positionOffsetView))
            {
                trackingOriginOverride.positionOffset
                    = SerializationUtils.DeserializeVector3(positionOffsetView.AsArrayView());
            }

            if (objectView.TryGetValue(
                "rotationOffset", out SerializedValueView rotationOffsetView))
            {
                trackingOriginOverride.rotationOffset
                    = SerializationUtils.DeserializeQuaternion(rotationOffsetView.AsArrayView());
            }

            return trackingOriginOverride;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public TrackingOriginOverride Clone()
        {
            TrackingOriginOverride clone = (TrackingOriginOverride)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
