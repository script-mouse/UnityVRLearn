
// system namespaces
using System;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    [Serializable]
    public class WarpMeshControlPoints
        : ICloneable
    {
        public Vector2 topLeft
        {
            get => m_topLeft;
            set => m_topLeft = value;
        }

        public Vector2 top
        {
            get => m_top;
            set => m_top = value;
        }

        public Vector2 topRight
        {
            get => m_topRight;
            set => m_topRight = value;
        }

        public Vector2 left
        {
            get => m_left;
            set => m_left = value;
        }

        public Vector2 center
        {
            get => m_center;
            set => m_center = value;
        }

        public Vector2 right
        {
            get => m_right;
            set => m_right = value;
        }

        public Vector2 bottomLeft
        {
            get => m_bottomLeft;
            set => m_bottomLeft = value;
        }

        public Vector2 bottom
        {
            get => m_bottom;
            set => m_bottom = value;
        }

        public Vector2 bottomRight
        {
            get => m_bottomRight;
            set => m_bottomRight = value;
        }

        [SerializeField]
        private Vector2 m_topLeft = new Vector2(-1.0f, 1.0f);
        [SerializeField]
        private Vector2 m_top = new Vector2(0.0f, 1.0f);
        [SerializeField]
        private Vector2 m_topRight = new Vector2(1.0f, 1.0f);

        [SerializeField]
        private Vector2 m_left = new Vector2(-1.0f, 0.0f);
        [SerializeField]
        private Vector2 m_center = new Vector2(0.0f, 0.0f);
        [SerializeField]
        private Vector2 m_right = new Vector2(1.0f, 0.0f);

        [SerializeField]
        private Vector2 m_bottomLeft = new Vector2(-1.0f, -1.0f);
        [SerializeField]
        private Vector2 m_bottom = new Vector2(0.0f, -1.0f);
        [SerializeField]
        private Vector2 m_bottomRight = new Vector2(1.0f, -1.0f);

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<WarpMeshControlPoints> context,
            WarpMeshControlPoints controlPoints)
        {
            using (context.Writer.WriteObjectScope())
            {
                SerializationUtils.SerializeVector2(context, controlPoints.m_topLeft, "topLeft");
                SerializationUtils.SerializeVector2(context, controlPoints.m_top, "top");
                SerializationUtils.SerializeVector2(context, controlPoints.m_topRight, "topRight");

                SerializationUtils.SerializeVector2(context, controlPoints.m_left, "left");
                SerializationUtils.SerializeVector2(context, controlPoints.m_center, "center");
                SerializationUtils.SerializeVector2(context, controlPoints.m_right, "right");

                SerializationUtils.SerializeVector2(
                    context, controlPoints.m_bottomLeft, "bottomLeft");
                SerializationUtils.SerializeVector2(context, controlPoints.m_bottom, "bottom");
                SerializationUtils.SerializeVector2(
                    context, controlPoints.m_bottomRight, "bottomRight");
            }
        }

        public static WarpMeshControlPoints Deserialize(
            in JsonDeserializationContext<WarpMeshControlPoints> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            WarpMeshControlPoints controlPoints = new WarpMeshControlPoints()
            {
                m_topLeft = SerializationUtils.DeserializeVector2(
                    objectView["topLeft"].AsArrayView()),
                m_top = SerializationUtils.DeserializeVector2(
                    objectView["top"].AsArrayView()),
                m_topRight = SerializationUtils.DeserializeVector2(
                    objectView["topRight"].AsArrayView()),

                m_left = SerializationUtils.DeserializeVector2(
                    objectView["left"].AsArrayView()),
                m_center = SerializationUtils.DeserializeVector2(
                    objectView["center"].AsArrayView()),
                m_right = SerializationUtils.DeserializeVector2(
                    objectView["right"].AsArrayView()),

                m_bottomLeft = SerializationUtils.DeserializeVector2(
                    objectView["bottomLeft"].AsArrayView()),
                m_bottom = SerializationUtils.DeserializeVector2(
                    objectView["bottom"].AsArrayView()),
                m_bottomRight = SerializationUtils.DeserializeVector2(
                    objectView["bottomRight"].AsArrayView()),
            };

            return controlPoints;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public WarpMeshControlPoints Clone()
        {
            WarpMeshControlPoints clone = (WarpMeshControlPoints)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
