

// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Settings to override on a warp mesh as defined in
    /// <see cref="ExternalDisplayCamaraRig.WarpMeshInfo"/>. Each setting has a corresponding flag
    /// that indicates if the value from the override should be used (flag is <c>true</c>)
    /// or not.
    /// </summary>
    public class WarpMeshOverride
        : ICloneable
    {
        public string name
        {
            get => m_name;
            set => m_name = value;
        }

        public WarpMeshStyle style
        {
            get => m_style;
            set
            {
                m_style = value;
                m_overridesFlags[k_hasStyleBit] = true;
            }
        }

        public bool hasStyleOverride
        {
            get => m_overridesFlags[k_hasStyleBit];
            set => m_overridesFlags[k_hasStyleBit] = value;
        }

        public Vector2Int sourceResolution
        {
            get => m_sourceResolution;
            set
            {
                m_sourceResolution = value;
                m_overridesFlags[k_hasSourceResolutionBit] = true;
            }
        }

        public bool hasSourceResolutionOverride
        {
            get => m_overridesFlags[k_hasSourceResolutionBit];
            set => m_overridesFlags[k_hasSourceResolutionBit] = value;
        }

        public CoordinateMode coordinateMode
        {
            get => m_coordinateMode;
            set
            {
                m_coordinateMode = value;
                m_overridesFlags[k_hasCoordinateModeBit] = true;
            }
        }

        public bool hasCoordinateModeOverride
        {
            get => m_overridesFlags[k_hasCoordinateModeBit];
            set => m_overridesFlags[k_hasCoordinateModeBit] = value;
        }

        public Rect sourceRect
        {
            get => m_sourceRect;
            set
            {
                m_sourceRect = value;
                m_overridesFlags[k_hasSourceRectBit] = true;
            }
        }

        public bool hasSourceRectOverride
        {
            get => m_overridesFlags[k_hasSourceRectBit];
            set => m_overridesFlags[k_hasSourceRectBit] = value;
        }

        public Vector2Int meshResolution
        {
            get => m_meshResolution;
            set
            {
                m_meshResolution = value;
                m_overridesFlags[k_hasMeshResolutionBit] = true;
            }
        }

        public bool hasMeshResolutionOverride
        {
            get => m_overridesFlags[k_hasMeshResolutionBit];
            set => m_overridesFlags[k_hasMeshResolutionBit] = value;
        }

        public WarpMeshControlPoints controlPoints
        {
            get => m_controlPoints;
            set
            {
                m_controlPoints = value;
                m_overridesFlags[k_hasControlPointsBit] = true;
            }
        }

        public bool hasControlPointsOverride
        {
            get => m_overridesFlags[k_hasControlPointsBit];
            set => m_overridesFlags[k_hasControlPointsBit] = value;
        }

        public bool hasOverrides
        {
            get => m_overridesFlags.Data != 0;
        }

        private string m_name;
        private WarpMeshStyle m_style = WarpMeshStyle.FullscreenQuad;
        private Vector2Int m_sourceResolution = Vector2Int.zero;
        private CoordinateMode m_coordinateMode = CoordinateMode.Normalized;
        private Rect m_sourceRect = new Rect(Vector2.zero, Vector2.one);
        private Vector2Int m_meshResolution = new Vector2Int(16, 16);
        private WarpMeshControlPoints m_controlPoints = new WarpMeshControlPoints();
        private BitVector32 m_overridesFlags = new BitVector32(0);

        // constants for flags in m_overrideFlags
        private static readonly int k_hasStyleBit = BitVector32.CreateMask();
        private static readonly int k_hasSourceResolutionBit
            = BitVector32.CreateMask(k_hasStyleBit);
        private static readonly int k_hasCoordinateModeBit
            = BitVector32.CreateMask(k_hasSourceResolutionBit);
        private static readonly int k_hasSourceRectBit
            = BitVector32.CreateMask(k_hasCoordinateModeBit);
        private static readonly int k_hasMeshResolutionBit
            = BitVector32.CreateMask(k_hasSourceRectBit);
        private static readonly int k_hasControlPointsBit
            = BitVector32.CreateMask(k_hasMeshResolutionBit);

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<WarpMeshOverride> context,
            WarpMeshOverride warpMeshOverride)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("name", warpMeshOverride.m_name);

                if (warpMeshOverride.hasStyleOverride)
                    context.SerializeValue("style", warpMeshOverride.m_style);

                if (warpMeshOverride.hasSourceResolutionOverride)
                {
                    SerializationUtils.SerializeVector2Int(
                        context, warpMeshOverride.m_sourceResolution, "sourceResolution");
                }

                if (warpMeshOverride.hasCoordinateModeOverride)
                    context.SerializeValue("coordinateMode", warpMeshOverride.m_coordinateMode);

                if (warpMeshOverride.hasMeshResolutionOverride)
                {
                    SerializationUtils.SerializeVector2Int(
                        context, warpMeshOverride.m_meshResolution, "meshResolution");
                }

                if (warpMeshOverride.hasControlPointsOverride)
                    context.SerializeValue("controlPoints", warpMeshOverride.m_controlPoints);
            }
        }

        public static WarpMeshOverride Deserialize(
            in JsonDeserializationContext<WarpMeshOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            WarpMeshOverride warpMeshOverride = new WarpMeshOverride()
            {
                m_name = objectView["name"].AsStringView().ToString()
            };

            if (objectView.TryGetValue("style", out SerializedValueView styleView))
            {
                warpMeshOverride.m_style
                    = SerializationUtils.DeserializeEnum<WarpMeshStyle>(styleView);
                warpMeshOverride.m_overridesFlags[k_hasStyleBit] = true;
            }

            if (objectView.TryGetValue(
                "sourceResolution", out SerializedValueView sourceResolutionView))
            {
                warpMeshOverride.m_sourceResolution
                    = SerializationUtils.DeserializeVector2Int(sourceResolutionView.AsArrayView());
                warpMeshOverride.m_overridesFlags[k_hasSourceResolutionBit] = true;
            }

            if (objectView.TryGetValue(
                "coordinateMode", out SerializedValueView coordinateModeView))
            {
                warpMeshOverride.m_coordinateMode
                    = SerializationUtils.DeserializeEnum<CoordinateMode>(coordinateModeView);
                warpMeshOverride.m_overridesFlags[k_hasCoordinateModeBit] = true;
            }

            if (objectView.TryGetValue("sourceRect", out SerializedValueView sourceRectView))
            {
                warpMeshOverride.m_sourceRect = context.DeserializeValue<Rect>(sourceRectView);
                warpMeshOverride.m_overridesFlags[k_hasSourceRectBit] = true;
            }

            if (objectView.TryGetValue(
                "meshResolution", out SerializedValueView meshResolutionView))
            {
                warpMeshOverride.m_meshResolution
                    = SerializationUtils.DeserializeVector2Int(meshResolutionView.AsArrayView());
                warpMeshOverride.m_overridesFlags[k_hasMeshResolutionBit] = true;
            }

            if (objectView.TryGetValue("controlPoints", out SerializedValueView controlPointsView))
            {
                warpMeshOverride.m_controlPoints
                    = context.DeserializeValue<WarpMeshControlPoints>(controlPointsView);
                warpMeshOverride.m_overridesFlags[k_hasControlPointsBit] = true;
            }

            return warpMeshOverride;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public WarpMeshOverride Clone()
        {
            WarpMeshOverride clone = (WarpMeshOverride)MemberwiseClone();
            clone.m_controlPoints = m_controlPoints.Clone();

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
