
// system namespaces
using System;
using System.Collections.Specialized;
// unity namespaces
using UnityEngine;
using Unity.Serialization.Json;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Allows overriding (some of) the settings in <see cref="WindowInfo"/> from
    /// a configuration file.
    /// </summary>
    public class WindowOverride
        : ICloneable
    {
        // ------------------------------------------------------------------
        #region Properties

        public string name
        {
            get => m_name;
            set => m_name = value;
        }

        public Vector2Int position
        {
            get => m_position;
            set
            {
                m_position = value;
                m_overrideFlags[k_hasPositionBit] = true;
            }
        }

        public bool hasPositionOverride
        {
            get => m_overrideFlags[k_hasPositionBit];
            set => m_overrideFlags[k_hasPositionBit] = value;
        }

        public Vector2Int size
        {
            get => m_size;
            set
            {
                m_size = value;
                m_overrideFlags[k_hasSizeBit] = true;
            }
        }

        public bool hasSizeOverride
        {
            get => m_overrideFlags[k_hasSizeBit];
            set => m_overrideFlags[k_hasSizeBit] = value;
        }

        public bool hasOverrides
        {
            get => m_overrideFlags.Data != 0;
        }

        #endregion // Properties
        // ------------------------------------------------------------------

        private string m_name;
        private Vector2Int m_position;
        private Vector2Int m_size;
        private BitVector32 m_overrideFlags;

        // constants for flags in m_overrideFlags
        private static readonly int k_hasPositionBit = BitVector32.CreateMask();
        private static readonly int k_hasSizeBit = BitVector32.CreateMask(k_hasPositionBit);

        // ------------------------------------------------------------------
        #region Serialization

        public static void Serialize(
            in JsonSerializationContext<WindowOverride> context, WindowOverride windowOverride)
        {
            using (context.Writer.WriteObjectScope())
            {
                context.SerializeValue("name", windowOverride.m_name);

                if (windowOverride.hasPositionOverride)
                {
                    SerializationUtils.SerializeVector2Int(
                        context, windowOverride.m_position, "position");
                }

                if (windowOverride.hasSizeOverride)
                    SerializationUtils.SerializeVector2Int(context, windowOverride.m_size, "size");
            }
        }

        public static WindowOverride Deserialize(
            in JsonDeserializationContext<WindowOverride> context)
        {
            SerializedObjectView objectView = context.SerializedValue.AsObjectView();

            WindowOverride windowOverride = new WindowOverride()
            {
                m_name = objectView["name"].AsStringView().ToString(),
            };

            if (objectView.TryGetValue("position", out SerializedValueView positionView))
            {
                windowOverride.m_position
                    = SerializationUtils.DeserializeVector2Int(positionView.AsArrayView());
                windowOverride.m_overrideFlags[k_hasPositionBit] = true;
            }

            if (objectView.TryGetValue("size", out SerializedValueView sizeView))
            {
                windowOverride.m_size
                    = SerializationUtils.DeserializeVector2Int(sizeView.AsArrayView());
                windowOverride.m_overrideFlags[k_hasSizeBit] = true;
            }

            return windowOverride;
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region ICloneable

        public WindowOverride Clone()
        {
            WindowOverride clone = (WindowOverride)MemberwiseClone();
            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
