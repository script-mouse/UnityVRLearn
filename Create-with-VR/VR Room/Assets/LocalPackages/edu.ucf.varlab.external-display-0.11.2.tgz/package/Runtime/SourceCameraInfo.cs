
// system namespaces
using System;

// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Information about a camera that renders content to a render texture.
    /// </summary>
    [Serializable]
    public sealed class SourceCameraInfo
        : ICloneable
    {
        public Camera camera;

        [NonSerialized]
        internal NativePresentSourceDesc sourceDesc = null;

        // optional - only if this source uses a RenderViewCamera
        [NonSerialized]
        internal RenderViewCamera renderViewCamera = null;

        [NonSerialized]
        internal float ipdValue = 0.063f;

        [NonSerialized]
        internal bool nativeTextureValidated = false;

        // --------------------------------------------------------------
        #region ICloneable

        public SourceCameraInfo Clone()
        {
            SourceCameraInfo clone = (SourceCameraInfo)MemberwiseClone();
            // sourceDesc is not cloned!
            clone.sourceDesc = null;

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
