
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Base class for inputs controlling (debug/diagnostic) runtime features of the
    /// <see cref="ExternalDisplayCameraRig"> classes.
    /// </summary>
    public abstract class BaseCameraRigInput
        : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Camera rig controlled by this input (default: from same GameObject)")]
        protected ExternalDisplayCameraRig m_cameraRig;

        [SerializeField]
        [Tooltip("EyeDebugUI that are toggled by this input")]
        protected EyeDebugUI[] m_debugUIs;

        protected bool m_debugUIEnabled = false;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        protected virtual void Awake()
        {
            if (m_cameraRig == null)
                m_cameraRig = GetComponent<ExternalDisplayCameraRig>();
            Assert.IsNotNull(m_cameraRig);

            m_debugUIs = m_cameraRig.GetComponentsInChildren<EyeDebugUI>();
        }

        protected virtual void Start()
        {
            SetEyeDebugUIEnabled(false);
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        protected void SetEyeDebugUIEnabled(bool enabled)
        {
            for (int i = 0, iEnd = m_debugUIs.Length; i < iEnd; ++i)
            {
                m_debugUIs[i].enabled = enabled;
            }

            m_debugUIEnabled = enabled;
        }
    }


} // namespace VARLab.ExternalDisplay
