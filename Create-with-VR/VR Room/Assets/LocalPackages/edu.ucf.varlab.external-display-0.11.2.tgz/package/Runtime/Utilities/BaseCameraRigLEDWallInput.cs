
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public class BaseCameraRigLEDWallInput
        : BaseCameraRigInput
    {
        protected ExternalDisplayCameraRigLEDWall GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigLEDWall;
        }
    }

} // namespace VARLab.ExternalDisplay
