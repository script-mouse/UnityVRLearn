
namespace VARLab.ExternalDisplay
{
    public class BaseCameraRigVDenInput
        : BaseCameraRigInput
    {
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        protected ExternalDisplayCameraRigVDen GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigVDen;
        }
    }

} // namespace VARLab.ExternalDisplay
