
namespace VARLab.ExternalDisplay
{
    public class BaseCameraRigVRTableInput
        : BaseCameraRigInput
    {
    }

} // namespace VARLab.ExternalDisplay
