
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace VARLab.ExternalDisplay
{
    public class CheckerboardTextureGenerator
        : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Texture size")]
        private Vector2Int m_textureSize = new Vector2Int(1024, 1024);

        [SerializeField]
        [Tooltip("How many checkers per row/column to draw")]
        private Vector2Int m_checkerCount = new Vector2Int(16, 16);

        [SerializeField]
        [Tooltip("Color of checkers")]
        private Color m_checkerColor = Color.white;

        [SerializeField]
        private Material m_checkerMaterial;

        [SerializeField]
        [Tooltip("Color of corner details")]
        private Color m_cornerDetailColor = Color.white;

        [SerializeField]
        private Material m_cornerDetailMaterial;

        private RawImage m_image;
        private RenderTexture m_checkerboardTexture;

        private void Awake()
        {
            m_image = GetComponent<RawImage>();
            Assert.IsNotNull(m_image);

            m_checkerboardTexture = CreateCheckerboardTexture();
        }

        private void Start()
        {
            m_image.texture = m_checkerboardTexture;
        }

        private RenderTexture CreateCheckerboardTexture()
        {
            RenderTextureDescriptor checkerboardDesc = new RenderTextureDescriptor(
               m_textureSize.x, m_textureSize.y, RenderTextureFormat.Default, 0, 1);
            RenderTexture texture = new RenderTexture(checkerboardDesc);
            texture.Create();

            CommandBuffer cmds = new CommandBuffer();
            cmds.name = "CheckerboardTextureGenerator.CreateCheckerboardTexture";

            RenderTargetIdentifier rti = new RenderTargetIdentifier(texture);
            cmds.SetRenderTarget(
                rti, RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
            cmds.ClearRenderTarget(clearDepth: false, clearColor: true, Color.black, 1.0f);
            cmds.SetProjectionMatrix(Matrix4x4.identity);
            cmds.SetViewMatrix(Matrix4x4.identity);

            DrawCheckers(cmds);
            DrawCornerDetails(cmds);

            Graphics.ExecuteCommandBuffer(cmds);

            return texture;
        }

        private void DrawCheckers(CommandBuffer cmds)
        {
            Mesh quadMesh = Resources.GetBuiltinResource<Mesh>("Quad.fbx");
            MaterialPropertyBlock props = new MaterialPropertyBlock();

            for (int y = 0; y < m_checkerCount.y; ++y)
            {
                for (int x = 0; x < m_checkerCount.x; ++x)
                {
                    if ((x + y) % 2 == 0)
                    {
                        props.SetColor("_Color", m_checkerColor);
                    }
                    else
                    {
                        props.SetColor("_Color", Color.black);
                    }

                    cmds.DrawMesh(
                        quadMesh,
                        Matrix4x4.TRS(
                            new Vector3(
                                -1.0f + (2.0f * x + 1.0f) / m_checkerCount.x,
                                -1.0f + (2.0f * y + 1.0f) / m_checkerCount.y, 0.0f),
                            Quaternion.identity,
                            new Vector3(2.0f / m_checkerCount.x, 2.0f / m_checkerCount.y, 1.0f)
                        ),
                        m_checkerMaterial, 0, -1, props);
                }
            }
        }

        private void DrawCornerDetails(CommandBuffer cmds)
        {
            Mesh quadMesh = Resources.GetBuiltinResource<Mesh>("Quad.fbx");
            MaterialPropertyBlock props = new MaterialPropertyBlock();
            props.SetColor("_Color", m_cornerDetailColor);

            cmds.DrawMesh(
                quadMesh,
                Matrix4x4.TRS(
                    new Vector3(-0.6f, -0.6f, 0.0f), Quaternion.Euler(0.0f, 0.0f, 45.0f),
                    new Vector3(0.8f, 0.8f, 0.8f)),
                m_cornerDetailMaterial, 0, -1, props);
            cmds.DrawMesh(
                quadMesh,
                Matrix4x4.TRS(
                    new Vector3(-0.6f, 0.6f, 0.0f), Quaternion.Euler(0.0f, 0.0f, 45.0f),
                    new Vector3(0.8f, 0.8f, 0.8f)),
                m_cornerDetailMaterial, 0, -1, props);
            cmds.DrawMesh(
                quadMesh,
                Matrix4x4.TRS(
                    new Vector3(0.6f, -0.6f, 0.0f), Quaternion.Euler(0.0f, 0.0f, 45.0f),
                    new Vector3(0.8f, 0.8f, 0.8f)),
                m_cornerDetailMaterial, 0, -1, props);
            cmds.DrawMesh(
                quadMesh,
                Matrix4x4.TRS(
                    new Vector3(0.6f, 0.6f, 0.0f), Quaternion.Euler(0.0f, 0.0f, 45.0f),
                    new Vector3(0.8f, 0.8f, 0.8f)),
                m_cornerDetailMaterial, 0, -1, props);

            Graphics.ExecuteCommandBuffer(cmds);
        }
    }

} // namespace VARLab.ExternalDisplay
