
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Controls display of UI that indicates which stereo eye is being displayed.
    /// </summary>
    public class EyeDebugUI
        : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Canvas that only displays on the left eye (default: search children)")]
        private Canvas m_leftEyeCanvas;

        [SerializeField]
        [Tooltip("Canvas that only displays on the right eye (default: search children)")]
        private Canvas m_rightEyeCanvas;

        [SerializeField]
        [Tooltip(
            "Name of layer that only renders on the left eye (must be in Project Settings!)")]
        private string m_leftEyeLayerName = "LeftEyeOnly";

        [SerializeField]
        [Tooltip(
            "Name of layer that only renders on the right eye (must be in Project Settings!)")]
        private string m_rightEyeLayerName = "RightEyeOnly";

        private const string k_leftEyeCanvasName = "LeftEyeCanvas";
        private const string k_rightEyeCanvasName = "RightEyeCanvas";

        // ----------------------------------------------------------------------
        #region MonoBehaviour

        private void Awake()
        {
            if (m_leftEyeCanvas == null)
            {
                m_leftEyeCanvas = MonoBehaviourUtils.GetChildComponent<Canvas>(
                    gameObject, k_leftEyeCanvasName);
            }
            Assert.IsNotNull(m_leftEyeCanvas);

            if (m_rightEyeCanvas == null)
            {
                m_rightEyeCanvas = MonoBehaviourUtils.GetChildComponent<Canvas>(
                    gameObject, k_rightEyeCanvasName);
            }
            Assert.IsNotNull(m_rightEyeCanvas);

            int leftEyeLayer = LayerMask.NameToLayer(m_leftEyeLayerName);
            Assert.IsTrue(leftEyeLayer >= 0);
            m_leftEyeCanvas.gameObject.layer = leftEyeLayer;

            int rightEyeLayer = LayerMask.NameToLayer(m_rightEyeLayerName);
            Assert.IsTrue(rightEyeLayer >= 0);
            m_rightEyeCanvas.gameObject.layer = rightEyeLayer;

            // disable debug ui on startup
            SetCanvasEnabled(false);
        }

        private void OnEnable()
        {
            SetCanvasEnabled(true);
        }

        private void OnDisable()
        {
            SetCanvasEnabled(false);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        private void SetCanvasEnabled(bool enabled)
        {
            if (m_leftEyeCanvas != null)
                m_leftEyeCanvas.enabled = enabled;

            if (m_rightEyeCanvas != null)
                m_rightEyeCanvas.enabled = enabled;
        }
    }

} // namespace VARLab.ExternalDisplay
