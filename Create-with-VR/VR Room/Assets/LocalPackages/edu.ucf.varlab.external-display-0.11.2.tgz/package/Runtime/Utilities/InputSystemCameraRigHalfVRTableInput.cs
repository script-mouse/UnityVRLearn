// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class InputSystemCameraRigHalfVRTableInput
        : BaseCameraRigVRTableInput
    {
        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        private InputActionAsset m_inputAsset;

        [Header("Eye Debug UI")]
        [SerializeField]
        private InputActionProperty m_toggleEyeDebugUIAction;

        [Header("Swap Eyes")]
        [SerializeField]
        private InputActionProperty m_swapEyesAllAction;

        [SerializeField]
        private InputActionProperty m_swapEyesVerticalAction;

        [SerializeField]
        private InputActionProperty m_swapEyesHorizontalAction;

        private Action<InputAction.CallbackContext> m_swapEyesVerticalHandler;
        private Action<InputAction.CallbackContext> m_swapEyesHorizontalHandler;

        private const string k_toggleEyeDebugUIActionName = "ToggleEyeDebugUI";
        private const string k_swapEyesAllActionName = "SwapEyesAll";
        private const string k_swapEyesVerticalActionName = "SwapEyes1";
        private const string k_swapEyesHorizontalActionName = "SwapEyes2";

        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(
                    ref m_toggleEyeDebugUIAction, m_inputAsset, k_toggleEyeDebugUIActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesAllAction, m_inputAsset, k_swapEyesAllActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesVerticalAction, m_inputAsset, k_swapEyesVerticalActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesHorizontalAction, m_inputAsset, k_swapEyesHorizontalActionName);
            }
        }

        protected void OnEnable()
        {
            InputSystemUtils.ConnectPerformedHandler(
                ref m_toggleEyeDebugUIAction, HandleToggleEyeDebugUI);

            m_swapEyesVerticalHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigHalfVRTable.ScreenId.Vertical);
            };
            m_swapEyesHorizontalHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigHalfVRTable.ScreenId.Horizontal);
            };

            InputSystemUtils.ConnectPerformedHandler(ref m_swapEyesAllAction, HandleSwapEyesAll);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesVerticalAction, m_swapEyesVerticalHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesHorizontalAction, m_swapEyesHorizontalHandler);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        private ExternalDisplayCameraRigHalfVRTable GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigHalfVRTable;
        }

        private void HandleToggleEyeDebugUI(InputAction.CallbackContext context)
        {
            for (int i = 0, iEnd = m_debugUIs.Length; i < iEnd; ++i)
            {
                m_debugUIs[i].enabled = !m_debugUIs[i].enabled;
            }
        }

        private void HandleSwapEyesAll(InputAction.CallbackContext context)
        {
            ExternalDisplayCameraRigHalfVRTable cameraRig = GetCameraRig();
            cameraRig.SwapEyesAllScreens();
        }

        private void HandleSwapEyes(
            InputAction.CallbackContext context,
            ExternalDisplayCameraRigHalfVRTable.ScreenId screenId)
        {
            ExternalDisplayCameraRigHalfVRTable cameraRig = GetCameraRig();
            cameraRig.SwapEyes(screenId);
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
