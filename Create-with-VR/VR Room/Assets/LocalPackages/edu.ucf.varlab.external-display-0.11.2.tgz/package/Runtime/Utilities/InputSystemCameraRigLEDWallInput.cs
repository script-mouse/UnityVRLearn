// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class InputSystemCameraRigLEDWallInput
        : BaseCameraRigLEDWallInput
    {
        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        protected InputActionAsset m_inputAsset;

        [Header("Eye Debug UI")]
        [SerializeField]
        protected InputActionProperty m_toggleEyeDebugUI;

        protected const string k_toggleEyeDebugUIActionName = "ToggleEyeDebugUI";

        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(
                    ref m_toggleEyeDebugUI, m_inputAsset, k_toggleEyeDebugUIActionName);
            }
        }

        protected void OnEnable()
        {
            InputSystemUtils.ConnectPerformedHandler(
                ref m_toggleEyeDebugUI, HandleToggleEyeDebugUI);
        }

        protected void OnDisable()
        {
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_toggleEyeDebugUI, HandleToggleEyeDebugUI);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        protected virtual void HandleToggleEyeDebugUI(InputAction.CallbackContext context)
        {
            SetEyeDebugUIEnabled(!m_debugUIEnabled);
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
