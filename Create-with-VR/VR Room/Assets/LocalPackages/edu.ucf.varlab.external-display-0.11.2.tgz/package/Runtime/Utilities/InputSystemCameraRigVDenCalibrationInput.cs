// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class InputSystemCameraRigVDenCalibrationInput
        : InputSystemCameraRigVDenInput
    {
        [SerializeField]
        protected WarpMeshCalibrationUI[] m_calibrationUI;

        protected override void HandleToggleEyeDebugUI(InputAction.CallbackContext context)
        {
            base.HandleToggleEyeDebugUI(context);

            SetCalibrationUICanvasEnabled(!m_debugUIEnabled);
        }

        protected void SetCalibrationUICanvasEnabled(bool enabled)
        {
            for (int i = 0, iEnd = m_calibrationUI.Length; i < iEnd; ++i)
            {
                m_calibrationUI[i].canvas.enabled = enabled;
            }
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
