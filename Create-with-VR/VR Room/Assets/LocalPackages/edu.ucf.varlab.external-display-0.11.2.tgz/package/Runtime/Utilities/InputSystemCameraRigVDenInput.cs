// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class InputSystemCameraRigVDenInput
        : BaseCameraRigVDenInput
    {
        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        protected InputActionAsset m_inputAsset;

        [Header("Eye Debug UI")]
        [SerializeField]
        protected InputActionProperty m_toggleEyeDebugUI;

        [Header("Swap Eyes")]
        [SerializeField]
        protected InputActionProperty m_swapEyesAllAction;

        [SerializeField]
        protected InputActionProperty m_swapEyesFrontAction;

        [SerializeField]
        protected InputActionProperty m_swapEyesLeftAction;

        [SerializeField]
        protected InputActionProperty m_swapEyesRightAction;

        [SerializeField]
        protected InputActionProperty m_swapEyesFloorAction;

        protected Action<InputAction.CallbackContext> m_swapEyesFrontHandler;
        protected Action<InputAction.CallbackContext> m_swapEyesLeftHandler;
        protected Action<InputAction.CallbackContext> m_swapEyesRightHandler;
        protected Action<InputAction.CallbackContext> m_swapEyesFloorHandler;

        protected const string k_toggleEyeDebugUIActionName = "ToggleEyeDebugUI";
        protected const string k_swapEyesAllActionName = "SwapEyesAll";
        protected const string k_swapEyesFrontActionName = "SwapEyes1";
        protected const string k_swapEyesLeftActionName = "SwapEyes2";
        protected const string k_swapEyesRightActionName = "SwapEyes3";
        protected const string k_swapEyesFloorActionName = "SwapEyes4";

        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(
                    ref m_toggleEyeDebugUI, m_inputAsset, k_toggleEyeDebugUIActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesAllAction, m_inputAsset, k_swapEyesAllActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesFrontAction, m_inputAsset, k_swapEyesFrontActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesLeftAction, m_inputAsset, k_swapEyesLeftActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesRightAction, m_inputAsset, k_swapEyesRightActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesFloorAction, m_inputAsset, k_swapEyesFloorActionName);
            }
        }

        protected void OnEnable()
        {
            InputSystemUtils.ConnectPerformedHandler(
                ref m_toggleEyeDebugUI, HandleToggleEyeDebugUI);

            m_swapEyesFrontHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVDen.ScreenId.Front);
            };
            m_swapEyesLeftHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVDen.ScreenId.Left);
            };
            m_swapEyesRightHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVDen.ScreenId.Right);
            };
            m_swapEyesFloorHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVDen.ScreenId.Floor);
            };

            InputSystemUtils.ConnectPerformedHandler(ref m_swapEyesAllAction, HandleSwapEyesAll);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesFrontAction, m_swapEyesFrontHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesLeftAction, m_swapEyesLeftHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesRightAction, m_swapEyesRightHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesFloorAction, m_swapEyesFloorHandler);
        }

        protected void OnDisable()
        {
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_toggleEyeDebugUI, HandleToggleEyeDebugUI);

            InputSystemUtils.DisconnectPerformedHandler(ref m_swapEyesAllAction, HandleSwapEyesAll);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_swapEyesFrontAction, m_swapEyesFrontHandler);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_swapEyesLeftAction, m_swapEyesLeftHandler);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_swapEyesRightAction, m_swapEyesRightHandler);
            InputSystemUtils.DisconnectPerformedHandler(
                ref m_swapEyesFloorAction, m_swapEyesFloorHandler);

            m_swapEyesFrontHandler = null;
            m_swapEyesLeftHandler = null;
            m_swapEyesRightHandler = null;
            m_swapEyesFloorHandler = null;
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        protected virtual void HandleToggleEyeDebugUI(InputAction.CallbackContext context)
        {
            SetEyeDebugUIEnabled(!m_debugUIEnabled);
        }

        protected virtual void HandleSwapEyesAll(InputAction.CallbackContext context)
        {
            ExternalDisplayCameraRigVDen cameraRig = GetCameraRig();
            cameraRig.SwapEyesAllScreens();
        }

        protected virtual void HandleSwapEyes(
            InputAction.CallbackContext context, ExternalDisplayCameraRigVDen.ScreenId screenId)
        {
            ExternalDisplayCameraRigVDen cameraRig = GetCameraRig();
            cameraRig.SwapEyes(screenId);
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
