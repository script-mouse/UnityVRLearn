// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class InputSystemCameraRigVRTableInput
        : BaseCameraRigVRTableInput
    {
        [SerializeField]
        [Tooltip("Optional asset for looking up actions (default: null)")]
        private InputActionAsset m_inputAsset;

        [Header("Eye Debug UI")]
        [SerializeField]
        private InputActionProperty m_toggleEyeDebugUIAction;

        [Header("Swap Eyes")]
        [SerializeField]
        private InputActionProperty m_swapEyesAllAction;

        [SerializeField]
        private InputActionProperty m_swapEyesVerticalLeftAction;

        [SerializeField]
        private InputActionProperty m_swapEyesVerticalRightAction;

        [SerializeField]
        private InputActionProperty m_swapEyesHorizontalLeftAction;

        [SerializeField]
        private InputActionProperty m_swapEyesHorizontalRightAction;

        private Action<InputAction.CallbackContext> m_swapEyesVerticalLeftHandler;
        private Action<InputAction.CallbackContext> m_swapEyesVerticalRightHandler;
        private Action<InputAction.CallbackContext> m_swapEyesHorizontalLeftHandler;
        private Action<InputAction.CallbackContext> m_swapEyesHorizontalRightHandler;

        private const string k_toggleEyeDebugUIActionName = "ToggleEyeDebugUI";
        private const string k_swapEyesAllActionName = "SwapEyesAll";
        private const string k_swapEyesVerticalLeftActionName = "SwapEyes1";
        private const string k_swapEyesVerticalRightActionName = "SwapEyes2";
        private const string k_swapEyesHorizontalLeftActionName = "SwapEyes3";
        private const string k_swapEyesHorizontalRightActionName = "SwapEyes4";

        // ----------------------------------------------------------------------
        #region MonoBehaviour

        protected override void Awake()
        {
            base.Awake();

            if (m_inputAsset != null)
            {
                InputSystemUtils.LookupAction(
                    ref m_toggleEyeDebugUIAction, m_inputAsset, k_toggleEyeDebugUIActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesAllAction, m_inputAsset, k_swapEyesAllActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesVerticalLeftAction, m_inputAsset,
                    k_swapEyesVerticalLeftActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesVerticalRightAction, m_inputAsset,
                    k_swapEyesVerticalRightActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesHorizontalLeftAction, m_inputAsset,
                    k_swapEyesHorizontalLeftActionName);
                InputSystemUtils.LookupAction(
                    ref m_swapEyesHorizontalRightAction, m_inputAsset,
                    k_swapEyesHorizontalRightActionName);
            }
        }

        protected void OnEnable()
        {
            InputSystemUtils.ConnectPerformedHandler(
                ref m_toggleEyeDebugUIAction, HandleToggleEyeDebugUI);

            m_swapEyesVerticalLeftHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVRTable.ScreenId.VerticalLeft);
            };
            m_swapEyesVerticalRightHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVRTable.ScreenId.VerticalRight);
            };
            m_swapEyesHorizontalLeftHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVRTable.ScreenId.HorizontalLeft);
            };
            m_swapEyesHorizontalRightHandler = (InputAction.CallbackContext context) =>
            {
                HandleSwapEyes(context, ExternalDisplayCameraRigVRTable.ScreenId.HorizontalRight);
            };

            InputSystemUtils.ConnectPerformedHandler(ref m_swapEyesAllAction, HandleSwapEyesAll);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesVerticalLeftAction, m_swapEyesVerticalLeftHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesVerticalRightAction, m_swapEyesVerticalRightHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesHorizontalLeftAction, m_swapEyesHorizontalLeftHandler);
            InputSystemUtils.ConnectPerformedHandler(
                ref m_swapEyesHorizontalRightAction, m_swapEyesHorizontalRightHandler);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------

        private ExternalDisplayCameraRigVRTable GetCameraRig()
        {
            return m_cameraRig as ExternalDisplayCameraRigVRTable;
        }

        private void HandleToggleEyeDebugUI(InputAction.CallbackContext context)
        {
            for (int i = 0, iEnd = m_debugUIs.Length; i < iEnd; ++i)
            {
                m_debugUIs[i].enabled = !m_debugUIs[i].enabled;
            }
        }

        private void HandleSwapEyesAll(InputAction.CallbackContext context)
        {
            ExternalDisplayCameraRigVRTable cameraRig = GetCameraRig();
            cameraRig.SwapEyesAllScreens();
        }

        private void HandleSwapEyes(
            InputAction.CallbackContext context, ExternalDisplayCameraRigVRTable.ScreenId screenId)
        {
            ExternalDisplayCameraRigVRTable cameraRig = GetCameraRig();
            cameraRig.SwapEyes(screenId);
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
