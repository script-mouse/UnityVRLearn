// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// system namespaces
using System;
// unity namespaces
using UnityEngine;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public static class InputSystemUtils
    {
        /// <summary>
        /// Updates <paramref name="property"/> to refer to the given <paramref name="actionName"/>
        /// from <paramref name="asset"/> unless property already refers to an action and the
        /// action has at least one binding.
        /// </summary>
        /// <param name="property">Property to update</param>
        /// <param name="asset">Asset to lookup action in</param>
        /// <param name="actionName">Name of action to look up</param>
        public static void LookupAction(
            ref InputActionProperty property, InputActionAsset asset, string actionName)
        {
            if (property.action == null || property.action.bindings.Count == 0)
            {
                property = new InputActionProperty(asset.FindAction(actionName));
            }
        }

        /// <summary>
        /// Enables the action in <paramref name="property"/> if it is not <c>null</c>.
        /// </summary>
        /// <param name="property">Property with the action to update</param>
        public static void EnableAction(ref InputActionProperty property)
        {
            if (property.action != null)
                property.action.Enable();
        }

        /// <summary>
        /// Disables the action in <paramref name="property"/> if it is not <c>null</c>.
        /// </summary>
        /// <param name="property">Property with the action to update</param>
        public static void DisableAction(ref InputActionProperty property)
        {
            if (property.action != null)
                property.action.Disable();
        }

        /// <summary>
        /// Connects <paramref name="handler"/> to the <c>started</c> event of the action
        /// in <paramref name="property"/> and (optionally) enables the action.
        /// </summary>
        /// <param name="property"></param>
        /// <param name="handler"></param>
        /// <param name="enableAction"></param>
        public static void ConnectStartedHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool enableAction = true)
        {
            if (property.action != null)
            {
                property.action.started += handler;

                if (enableAction)
                    property.action.Enable();
            }
        }

        public static void DisconnectStartedHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool disableAction = true)
        {
            if (property.action != null)
            {
                if (disableAction)
                    property.action.Disable();

                property.action.started -= handler;
            }
        }

        public static void ConnectCanceledHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool enableAction = true)
        {
            if (property.action != null)
            {
                property.action.canceled += handler;

                if (enableAction)
                    property.action.Enable();
            }
        }

        public static bool ConnectCanceledHandler(
            InputAction action, Action<InputAction.CallbackContext> handler,
            bool enableAction = true)
        {
            if (action != null)
            {
                action.canceled += handler;

                if (enableAction)
                    action.Enable();

                return true;
            }

            return false;
        }

        public static void DisconnectCanceledHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool disableAction = true)
        {
            if (property.action != null)
            {
                if (disableAction)
                    property.action.Disable();

                property.action.canceled -= handler;
            }
        }

        public static bool DisconnectCanceledHandler(
            InputAction action, Action<InputAction.CallbackContext> handler,
            bool disableAction = true)
        {
            if (action != null)
            {
                if (disableAction)
                    action.Disable();

                action.canceled -= handler;

                return true;
            }

            return false;
        }

        public static void ConnectPerformedHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool enableAction = true)
        {
            if (property.action != null)
            {
                property.action.performed += handler;

                if (enableAction)
                    property.action.Enable();
            }
        }

        public static bool ConnectPerformedHandler(
            InputAction action, Action<InputAction.CallbackContext> handler,
            bool enableAction = true)
        {
            if (action != null)
            {
                action.performed += handler;

                if (enableAction)
                    action.Enable();

                return true;
            }

            return false;
        }

        public static void DisconnectPerformedHandler(
            ref InputActionProperty property, Action<InputAction.CallbackContext> handler,
            bool disableAction = true)
        {
            if (property.action != null)
            {
                if (disableAction)
                    property.action.Disable();

                property.action.performed -= handler;
            }
        }

        public static bool DisconnectPerformedHandler(
            InputAction action, Action<InputAction.CallbackContext> handler,
            bool disableAction = true)
        {
            if (action != null)
            {
                if (disableAction)
                    action.Disable();

                action.performed -= handler;

                return true;
            }

            return false;
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
