
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public static class MathUtils
    {
        public static Rect ConvertToNormalizedRect(
            CoordinateMode coordinateMode, Rect rect, Vector2Int resolution)
        {
            switch (coordinateMode)
            {
                case CoordinateMode.Normalized:
                    return rect;

                case CoordinateMode.Pixel:
                    return new Rect(
                        rect.x / resolution.x, rect.y / resolution.y,
                        rect.width / resolution.x, rect.height / resolution.y);

                default:
                    Debug.LogError($"Unhandled CoordinateMode '{coordinateMode}'!");
                    break;
            }

            return new Rect(Vector2.zero, Vector2.one);
        }

        public static Rect ConvertToPixelRect(
            CoordinateMode coordinateMode, Rect rect, Vector2Int resolution)
        {
            switch (coordinateMode)
            {
                case CoordinateMode.Normalized:
                    return new Rect(
                        rect.x * resolution.x, rect.y * resolution.y,
                        rect.width * resolution.x, rect.height * resolution.y);

                case CoordinateMode.Pixel:
                    return rect;

                default:
                    Debug.LogError($"Unhandled CoordinateMode '{coordinateMode}'!");
                    break;
            }

            return new Rect(Vector2.zero, resolution);
        }

        /// <summary>
        /// Transforms <paramref name="point"/> from <paramref name="source"/> coordinate system
        /// to <paramref name="destination"/> coordinate system (via world space).
        /// </summary>
        /// <param name="source">Source coordinate system (may be <c>null</c> == world space).
        /// </param>
        /// <param name="destination">Destination coordinate system
        /// (may be <c>null</c> == world space).</param>
        /// <param name="point">Point to transform.</param>
        /// <returns></returns>
        public static Vector3 TransformPoint(Transform source, Transform destination, Vector3 point)
        {
            point = source != null ? source.TransformPoint(point) : point;
            point = destination != null ? destination.InverseTransformPoint(point) : point;
            return point;
        }

        // Evaluate the Centripedal Catmull-Rom spline with control points p0,p1,p2,p3 at t [0,1]
        public static Vector2 EvalSpline(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3, float t)
        {
            // calculate knot sequence
            float t0 = 0.0f;
            float t1 = CalcT(t0, p0, p1);
            float t2 = CalcT(t1, p1, p2);
            float t3 = CalcT(t2, p2, p3);

            // map t [0, 1] to [t1, t2]
            float tt = Mathf.Lerp(t1, t2, t);

            Vector2 A0 = (t1 - tt) / (t1 - t0) * p0 + (tt - t0) / (t1 - t0) * p1;
            Vector2 A1 = (t2 - tt) / (t2 - t1) * p1 + (tt - t1) / (t2 - t1) * p2;
            Vector2 A2 = (t3 - tt) / (t3 - t2) * p2 + (tt - t2) / (t3 - t2) * p3;

            Vector2 B0 = (t2 - tt) / (t2 - t0) * A0 + (tt - t0) / (t2 - t0) * A1;
            Vector2 B1 = (t3 - tt) / (t3 - t1) * A1 + (tt - t1) / (t3 - t1) * A2;

            return (t2 - tt) / (t2 - t1) * B0 + (tt - t1) / (t2 - t1) * B1;
        }

        // Expects 4 point correspondences
        public static Matrix3x3 CalcHomographyMatrix(Vector2[] a, Vector2[] b)
        {
            Assert.AreEqual(a.Length, a.Length);
            Assert.AreEqual(4, a.Length);

            float[,] A = {
                {
                    0.0f, 0.0f, 0.0f, -a[0].x, -a[0].y, -1.0f, a[0].x * b[0].y, a[0].y * b[0].y, -b[0].y
                },
                {
                    a[0].x, a[0].y, 1.0f, 0.0f, 0.0f, 0.0f, -a[0].x * b[0].x, -a[0].y * b[0].x, b[0].x
                },
                {
                    0.0f, 0.0f, 0.0f, -a[1].x, -a[1].y, -1.0f, a[1].x * b[1].y, a[1].y * b[1].y, -b[1].y
                },
                {
                    a[1].x, a[1].y, 1.0f, 0.0f, 0.0f, 0.0f, -a[1].x * b[1].x, -a[1].y * b[1].x, b[1].x
                },
                {
                    0.0f, 0.0f, 0.0f, -a[2].x, -a[2].y, -1.0f, a[2].x * b[2].y, a[2].y * b[2].y, -b[2].y
                },
                {
                    a[2].x, a[2].y, 1.0f, 0.0f, 0.0f, 0.0f, -a[2].x * b[2].x, -a[2].y * b[2].x, b[2].x
                },
                {
                    0.0f, 0.0f, 0.0f, -a[3].x, -a[3].y, -1.0f, a[3].x * b[3].y, a[3].y * b[3].y, -b[3].y
                },
                {
                    a[3].x, a[3].y, 1.0f, 0.0f, 0.0f, 0.0f, -a[3].x * b[3].x, -a[3].y * b[3].x, b[3].x
                }
            };

            GaussianElimination(ref A, 9);

            return new Matrix3x3(
                A[0, 8], A[1, 8], A[2, 8],
                A[3, 8], A[4, 8], A[5, 8],
                A[6, 8], A[7, 8], 1.0f
            );
        }

        // ------------------------------------------------------------------
        #region Helper Functions

        // Helper function to calculate knot sequence for Centripedal Catmull-Rom spline
        private static float CalcT(float t, Vector2 p0, Vector2 p1)
        {
            float dx = p1.x - p0.x;
            float dy = p1.y - p0.y;

            return t + Mathf.Pow(dx * dx + dy * dy, 0.25f);
        }

        // Performs Gaussian elimination on the matrix A that has n columns and (n-1) rows.
        private static void GaussianElimination(ref float[,] A, int numCols)
        {
            int row = 0;
            int col = 0;
            int numRows = numCols - 1;

            while (row < numRows && col < numCols)
            {
                // find pivot in column 'col', starting in row 'row'
                int pivotRow = FindPivotRow(ref A, numRows, row, col);

                if (A[pivotRow, col] != 0.0f)
                {
                    if (row != pivotRow)
                    {
                        // swap rows 'row' and 'pivotRow', keep value of 'row' unchanged
                        SwapRows(ref A, numCols, row, pivotRow);
                    }

                    // divide each entry in row 'row' by A[row, col] (now contains A[pivotRow, col],
                    // i.e. pivot value)
                    float pivot = A[row, col];
                    DivideRow(ref A, numCols, row, pivot);

                    for (int r = row + 1; r < numRows; ++r)
                    {
                        float a_rj = A[r, col];

                        for (int c = 0; c < numCols; ++c)
                        {
                            A[r, c] -= a_rj * A[row, c];
                        }
                    }

                    ++row;
                }

                ++col;
            }

            // back substitution
            BackSubstitute(ref A, numRows, numCols);
        }

        // Helper for GaussianElimination to select the pivot row.
        private static int FindPivotRow(ref float[,] A, int numRows, int startRow, int column)
        {
            int pivotRow = startRow;

            for (int row = startRow + 1; row < numRows; ++row)
            {
                if (Mathf.Abs(A[row, column]) > Mathf.Abs(A[pivotRow, column]))
                    pivotRow = row;
            }

            return pivotRow;
        }

        // Helper for GaussianElimination to swap two rows
        private static void SwapRows(ref float[,] A, int numCols, int row0, int row1)
        {
            for (int col = 0; col < numCols; ++col)
            {
                float tmp = A[row0, col];
                A[row0, col] = A[row1, col];
                A[row1, col] = tmp;
            }
        }

        // Helper for GaussianElimination to divide a row by a factor
        private static void DivideRow(ref float[,] A, int numCols, int row, float divisor)
        {
            for (int col = 0; col < numCols; ++col)
                A[row, col] = A[row, col] / divisor;
        }

        // Helper for GaussianElimination to perform back substitution
        private static void BackSubstitute(ref float[,] A, int numRows, int numCols)
        {
            for (int row = numRows - 2; row >= 0; --row)
            {
                for (int col = row + 1; col < numCols - 1; ++col)
                {
                    A[row, numCols - 1] -= A[row, col] * A[col, numCols - 1];
                }
            }
        }

        #endregion // Helper Functions
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
