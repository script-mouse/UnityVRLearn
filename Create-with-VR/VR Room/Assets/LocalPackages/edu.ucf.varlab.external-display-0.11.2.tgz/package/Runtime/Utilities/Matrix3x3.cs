
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Matrix with 3 rows and 3 columns. Only supports operations needed for display warp.
    /// </summary>
    public struct Matrix3x3
    {
        public static Matrix3x3 identity
        {
            get
            {
                return new Matrix3x3()
                {
                    m_00 = 1.0f,
                    m_01 = 0.0f,
                    m_02 = 0.0f,
                    m_10 = 0.0f,
                    m_11 = 1.0f,
                    m_12 = 0.0f,
                    m_20 = 0.0f,
                    m_21 = 0.0f,
                    m_22 = 1.0f
                };
            }
        }

        public static Matrix3x3 zero
        {
            get
            {
                return new Matrix3x3()
                {
                    m_00 = 0.0f,
                    m_01 = 0.0f,
                    m_02 = 0.0f,
                    m_10 = 0.0f,
                    m_11 = 0.0f,
                    m_12 = 0.0f,
                    m_20 = 0.0f,
                    m_21 = 0.0f,
                    m_22 = 0.0f
                };
            }
        }

        public float this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0:
                        return m_00;
                    case 1:
                        return m_01;
                    case 2:
                        return m_02;
                    case 3:
                        return m_10;
                    case 4:
                        return m_11;
                    case 5:
                        return m_12;
                    case 6:
                        return m_20;
                    case 7:
                        return m_21;
                    case 8:
                        return m_22;
                }

                throw new System.ArgumentOutOfRangeException();
            }
        }

        public float this[int row, int column]
        {
            get
            {
                int index = row * 3 + column;
                switch (index)
                {
                    case 0:
                        return m_00;
                    case 1:
                        return m_01;
                    case 2:
                        return m_02;
                    case 3:
                        return m_10;
                    case 4:
                        return m_11;
                    case 5:
                        return m_12;
                    case 6:
                        return m_20;
                    case 7:
                        return m_21;
                    case 8:
                        return m_22;
                }

                throw new System.ArgumentOutOfRangeException();
            }

            set
            {
                int index = row * 3 + column;
                switch (index)
                {
                    case 0:
                        m_00 = value;
                        break;
                    case 1:
                        m_01 = value;
                        break;
                    case 2:
                        m_02 = value;
                        break;
                    case 3:
                        m_10 = value;
                        break;
                    case 4:
                        m_11 = value;
                        break;
                    case 5:
                        m_12 = value;
                        break;
                    case 6:
                        m_20 = value;
                        break;
                    case 7:
                        m_21 = value;
                        break;
                    case 8:
                        m_22 = value;
                        break;
                }

                throw new System.ArgumentOutOfRangeException();
            }
        }

        private float m_00;
        private float m_01;
        private float m_02;
        private float m_10;
        private float m_11;
        private float m_12;
        private float m_20;
        private float m_21;
        private float m_22;

        public Matrix3x3(
            float in00, float in01, float in02,
            float in10, float in11, float in12,
            float in20, float in21, float in22)
        {
            m_00 = in00;
            m_01 = in01;
            m_02 = in02;
            m_10 = in10;
            m_11 = in11;
            m_12 = in12;
            m_20 = in20;
            m_21 = in21;
            m_22 = in22;
        }

        public Vector2 MultiplyPoint(Vector2 point)
        {
            float w = m_20 * point.x + m_21 * point.y + m_22;

            if (!Mathf.Approximately(w, 0.0f))
            {
                float invW = 1.0f / w;
                float x = invW * (m_00 * point.x + m_01 * point.y + m_02);
                float y = invW * (m_10 * point.x + m_11 * point.y + m_12);

                return new Vector2(x, y);
            }

            return Vector2.zero;
        }

        public Vector3 MultiplyVector(Vector3 vector)
        {
            float x = m_00 * vector.x + m_01 * vector.y + m_02 * vector.z;
            float y = m_10 * vector.x + m_11 * vector.y + m_12 * vector.z;
            float z = m_20 * vector.x + m_21 * vector.y + m_22 * vector.z;

            return new Vector3(x, y, z);
        }

        public override string ToString()
        {
            return $"({m_00} {m_01} {m_02}) ({m_10} {m_11} {m_12}) ({m_20} {m_21} {m_22})";
        }
    }

} // namespace VARLab.ExternalDisplay
