
// system namespaces
using System;
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UObject = UnityEngine.Object;

namespace VARLab.ExternalDisplay
{
    public static class MonoBehaviourUtils
    {
        public static T GetUniqueComponentInstance<T>(
            FindObjectsInactive findObjectsInactive = FindObjectsInactive.Exclude)
            where T : Component
        {
            T[] instances = UObject.FindObjectsByType<T>(
                findObjectsInactive, FindObjectsSortMode.None);

            if (instances.Length == 0)
            {
                Debug.LogError($"Failed to find instance of type '{typeof(T)}'!");
                return null;
            }
            else if (instances.Length > 1)
            {
                Debug.LogError($"Found multiple instances of type '{typeof(T)}'!");
                return null;
            }

            return instances[0];
        }

        public static T FindUniqueComponentInstance<T>(
            FindObjectsInactive findObjectsInactive = FindObjectsInactive.Exclude
            ) where T : Component
        {
            T[] instances = UObject.FindObjectsByType<T>(
                findObjectsInactive, FindObjectsSortMode.None);

            if (instances.Length != 1)
            {
                return null;
            }

            return instances[0];
        }

        private static readonly Queue<Transform> s_traversalQueue = new Queue<Transform>();

        public static T GetChildComponent<T>(
            GameObject rootGO, string childName) where T : Component
        {
            if (TryGetChildComponent(rootGO, childName, out T component))
                return component;

            return null;
        }

        public static bool TryGetChildComponent<T>(
            GameObject rootGO, string childName, out T component) where T : Component
        {
            s_traversalQueue.Clear();
            s_traversalQueue.Enqueue(rootGO.transform);

            while (s_traversalQueue.Count > 0)
            {
                Transform currentTransform = s_traversalQueue.Dequeue();
                GameObject currentGO = currentTransform.gameObject;

                if (currentGO.name.Equals(childName))
                {
                    if (currentGO.TryGetComponent(out component))
                    {
                        s_traversalQueue.Clear();
                        return true;
                    }
                }

                for (int i = 0, iEnd = currentTransform.childCount; i < iEnd; ++i)
                    s_traversalQueue.Enqueue(currentTransform.GetChild(i));
            }

            component = null;
            return false;
        }

        public static GameObject GetChildGameObject(GameObject rootGO, string childName)
        {
            if (TryGetChildGameObject(rootGO, childName, out GameObject childGO))
                return childGO;

            return null;
        }

        public static bool TryGetChildGameObject(
            GameObject rootGO, string childName, out GameObject childGO)
        {
            s_traversalQueue.Clear();
            s_traversalQueue.Enqueue(rootGO.transform);

            while (s_traversalQueue.Count > 0)
            {
                Transform currentTransform = s_traversalQueue.Dequeue();
                GameObject currentGO = currentTransform.gameObject;

                if (currentGO.name.Equals(childName))
                {
                    s_traversalQueue.Clear();
                    childGO = currentGO;
                    return true;
                }

                for (int i = 0, iEnd = currentTransform.childCount; i < iEnd; ++i)
                    s_traversalQueue.Enqueue(currentTransform.GetChild(i));
            }

            childGO = null;
            return false;
        }

        public static void InitializeUniqueInstance<T>(
            ref T instance, Func<T> createInstanceFunc,
            FindObjectsInactive findObjectsInactive = FindObjectsInactive.Exclude) where T : UObject
        {
            T[] sceneInstances = UObject.FindObjectsByType<T>(
                findObjectsInactive, FindObjectsSortMode.None);

            if (sceneInstances.Length == 0)
            {
                Assert.IsNull(instance);

                instance = createInstanceFunc();
            }
            else if (sceneInstances.Length == 1)
            {
                // found a single instance in the scene, this happens e.g. when switching scenes
                if (instance != null && sceneInstances[0] != instance)
                {
                    // instance in the scene does not match member variable?
                    Debug.LogError(
                        $"{typeof(T).Name} instance in scene ({sceneInstances[0]}) does not match "
                        + $"given instance (instance)!");

                    Debug.Log($"Destroying given {typeof(T).Name} instance {instance}");
                    UnityEngine.Object.Destroy(instance);
                    instance = null;
                }

                // keep scene instance
                instance = sceneInstances[0];
            }
            else
            {
                // multiple instances found in scene
                Debug.LogError(
                    $"Found multiple ({sceneInstances.Length}) {typeof(T).Name} instances in "
                    + "the scene.");

                int activeIndex = 0;

                if (instance == null)
                {
                    // keep first instance found in scene
                    instance = sceneInstances[0];
                }
                else
                {
                    // ref argument cannot be used in a lambda, use a local variable instead
                    T givenInstance = instance;
                    activeIndex = Array.FindIndex(sceneInstances, x => x == givenInstance);

                    if (activeIndex < 0)
                    {
                        Debug.LogError(
                            $"No {typeof(T).Name} instance in scene matches given instance "
                            + $"({instance})");

                        Debug.Log($"Destroying given {typeof(T).Name} instance {instance}");
                        UObject.Destroy(instance);

                        // keep first instance found in scene
                        activeIndex = 0;
                        instance = sceneInstances[0];
                    }
                }

                for (int i = 0, iEnd = sceneInstances.Length; i < iEnd; ++i)
                {
                    // destroy all other instances in the scene
                    if (i != activeIndex)
                    {
                        UObject.Destroy(sceneInstances[i]);
                    }
                }
            }
        }
    }

} // namespace VARLab.ExternalDisplay
