
// system namespaces
using System;
using System.Collections.Generic;

// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    public static class PluginUtils
    {
        public static DeviceInfo FindDeviceInfo(IList<DeviceInfo> deviceInfos, string name)
        {
            for (int i = 0, iEnd = deviceInfos.Count; i < iEnd; ++i)
            {
                if (deviceInfos[i].name.Equals(name))
                    return deviceInfos[i];
            }

            return null;
        }

        public static WindowInfo FindWindowInfo(IList<WindowInfo> windowInfos, string name)
        {
            for (int i = 0, iEnd = windowInfos.Count; i < iEnd; ++i)
            {
                if (windowInfos[i].name.Equals(name))
                    return windowInfos[i];
            }

            return null;
        }

        public static WarpMeshInfo FindWarpMeshInfo(IList<WarpMeshInfo> warpMeshInfos, string name)
        {
            for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
            {
                if (warpMeshInfos[i].name.Equals(name))
                    return warpMeshInfos[i];
            }

            return null;
        }

        public static PresentInfo FindPresentInfo(IList<PresentInfo> presentInfos, string name)
        {
            for (int i = 0, iEnd = presentInfos.Count; i < iEnd; ++i)
            {
                if (presentInfos[i].name.Equals(name))
                    return presentInfos[i];
            }

            return null;
        }

        public static SourceCameraInfo FindSourceCameraInfo(
            IList<SourceCameraInfo> sourceCameraInfos, string name)
        {
            for (int i = 0, iEnd = sourceCameraInfos.Count; i < iEnd; ++i)
            {
                if (sourceCameraInfos[i].camera.name.Equals(name))
                    return sourceCameraInfos[i];
            }

            return null;
        }

        public static WarpMeshOverride FindWarpMeshOverride(
            IList<WarpMeshOverride> warpMeshOverrides, string name)
        {
            for (int i = 0, iEnd = warpMeshOverrides.Count; i < iEnd; ++i)
            {
                if (warpMeshOverrides[i].name.Equals(name))
                    return warpMeshOverrides[i];
            }

            return null;
        }

        public static RenderScreenInfo FindRenderScreenInfo(
            IList<RenderScreenInfo> renderScreenInfos, string name)
        {
            for (int i = 0, iEnd = renderScreenInfos.Count; i < iEnd; ++i)
            {
                if (renderScreenInfos[i].name.Equals(name))
                    return renderScreenInfos[i];
            }

            return null;
        }

        public static RenderScreenInfo[] MakeRenderScreenInfos(ExternalDisplayCameraRig cameraRig)
        {
            RenderScreen[] renderScreens = cameraRig.GetComponentsInChildren<RenderScreen>();
            RenderScreenInfo[] renderScreenInfos = new RenderScreenInfo[renderScreens.Length];

            for (int i = 0, iEnd = renderScreens.Length; i < iEnd; ++i)
            {
                renderScreenInfos[i] = new RenderScreenInfo()
                {
                    name = renderScreens[i].name,
                    position = renderScreens[i].transform.localPosition,
                    rotation = renderScreens[i].transform.localRotation,
                    size = renderScreens[i].size
                };
            }

            return renderScreenInfos;
        }

        // ------------------------------------------------------------------
        #region Reset Helpers

        public static bool ResetDeviceInfos(
            ref DeviceInfo[] deviceInfos, DeviceInfo[] sourceDeviceInfos)
        {
            if (deviceInfos == null || deviceInfos.Length != sourceDeviceInfos.Length)
            {
                Array.Resize(ref deviceInfos, sourceDeviceInfos.Length);

                for (int i = 0, iEnd = sourceDeviceInfos.Length; i < iEnd; ++i)
                {
                    deviceInfos[i] = sourceDeviceInfos[i].Clone();
                }

                return true;
            }

            return false;
        }

        public static bool ResetWindowInfos(
            ref WindowInfo[] windowInfos, WindowInfo[] sourceWindowInfos)
        {
            if (windowInfos == null || windowInfos.Length != sourceWindowInfos.Length)
            {
                Array.Resize(ref windowInfos, sourceWindowInfos.Length);

                for (int i = 0, iEnd = sourceWindowInfos.Length; i < iEnd; ++i)
                {
                    windowInfos[i] = sourceWindowInfos[i].Clone();
                }

                return true;
            }

            return false;
        }

        public static bool ResetSourceCameras(
            ref SourceCameraInfo[] sourceCameraInfos, string[] sourceCameraNames,
            GameObject gameObject)
        {
            if (sourceCameraInfos == null
                || sourceCameraInfos.Length != sourceCameraNames.Length)
            {
                Array.Resize(ref sourceCameraInfos, sourceCameraNames.Length);

                for (int i = 0, iEnd = sourceCameraNames.Length; i < iEnd; ++i)
                {
                    if (MonoBehaviourUtils.TryGetChildComponent(
                        gameObject, sourceCameraNames[i], out Camera camera))
                    {
                        sourceCameraInfos[i] = new SourceCameraInfo()
                        {
                            camera = camera
                        };
                    }
                }

                return true;
            }

            return false;
        }

        public static bool ResetWarpMeshes(
            ref WarpMeshInfo[] warpMeshes, WarpMeshInfo[] sourceWarpMeshes)
        {
            if (warpMeshes == null || warpMeshes.Length != sourceWarpMeshes.Length)
            {
                Array.Resize(ref warpMeshes, sourceWarpMeshes.Length);

                for (int i = 0, iEnd = sourceWarpMeshes.Length; i < iEnd; ++i)
                {
                    warpMeshes[i] = sourceWarpMeshes[i].Clone();
                }

                return true;
            }

            return false;
        }

        public static bool ResetPresentInfos(
            ref PresentInfo[] presentInfos, PresentInfo[] sourcePresentInfos)
        {
            if (presentInfos == null || presentInfos.Length != sourcePresentInfos.Length)
            {
                Array.Resize(ref presentInfos, sourcePresentInfos.Length);

                for (int i = 0, iEnd = sourcePresentInfos.Length; i < iEnd; ++i)
                {
                    presentInfos[i] = sourcePresentInfos[i].Clone();
                }

                return true;
            }

            return false;
        }

        #endregion // Reset Helpers
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
