
// system namespaces
using System;
using System.Runtime.CompilerServices;
// unity namespaces
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Fixed capacity ring buffer. Overwrites oldest value when adding values to a full buffer.
    /// </summary>
    public class RingBuffer<T>
    {
        /// <summary>
        /// Number of elements in the buffer.
        /// </summary>
        public int Count
        {
            get => m_size;
        }

        /// <summary>
        /// If the buffer is empty (contains no elements).
        /// </summary>
        public bool Empty
        {
            get => m_size == 0;
        }

        /// <summary>
        /// If the buffer is full (contains as many elements as it has capacity).
        /// </summary>
        public bool Full
        {
            get => m_size == m_buffer.Length;
        }

        /// <summary>
        /// Maximum number of elements the buffer can hold.
        /// </summary>
        public int Capacity
        {
            get => m_buffer.Length;
        }

        /// <summary>
        /// Returns the internal buffer. Do NOT modify it!
        /// </summary>
        public T[] Buffer
        {
            get => m_buffer;
        }

        private readonly T[] m_buffer;
        private int m_size;
        private int m_readIndex;
        private int m_writeIndex;

        public RingBuffer(int capacity)
        {
            Assert.IsTrue(capacity > 0, "Capacity must be positive!");

            m_buffer = new T[capacity];
            m_size = 0;
            m_readIndex = 0;
            m_writeIndex = 0;
        }

        /// <summary>
        /// Removes all elements from the buffer.
        /// </summary>
        public void Clear()
        {
            if (m_readIndex < m_writeIndex)
            {
                Array.Clear(m_buffer, m_readIndex, m_writeIndex);
            }
            else
            {
                Array.Clear(m_buffer, m_readIndex, m_buffer.Length - m_readIndex);
                Array.Clear(m_buffer, 0, m_writeIndex);
            }

            m_size = 0;
            m_readIndex = 0;
            m_writeIndex = 0;
        }

        /// <summary>
        /// Adds <paramref name="value" /> to the end of the buffer. If the buffer is full the
        /// element at the front (oldest) will be overwritten.
        /// </summary>
        public void Enqueue(T value)
        {
            m_buffer[m_writeIndex] = value;
            m_writeIndex = (m_writeIndex + 1) % m_buffer.Length;

            if (m_size < m_buffer.Length)
            {
                ++m_size;
            }
            else
            {
                m_readIndex = m_writeIndex;
            }
        }

        /// <summary>
        /// Adds <paramref name="value" /> to the end of the buffer if there is space and returns
        /// <c>true</c>, otherwise returns <c>false</c> and does not add <c>value</c>.
        /// </summary>
        public bool TryEnqueue(T value)
        {
            if (m_size < m_buffer.Length)
            {
                m_buffer[m_writeIndex] = value;
                m_writeIndex = (m_writeIndex + 1) % m_buffer.Length;
                ++m_size;

                return true;
            }

            return false;
        }

        /// <summary>
        /// Removes and returns an element from the front of the buffer. Throws an exception if
        /// the buffer is empty.
        /// </summary>
        public T Dequeue()
        {
            Assert.IsTrue(m_size > 0, "Dequeue must not be called on empty RingBuffer");

            return DequeueUnchecked();
        }

        /// <summary>
        /// Removes the element at the front of the buffer, copies to <paramref name="result" />
        /// and returns <c>true</c>. If the buffer is empty returns <c>false</c>.
        /// </summary>
        public bool TryDequeue(out T result)
        {
            if (m_size == 0)
            {
                result = default(T);
                return false;
            }

            result = DequeueUnchecked();
            return true;
        }

        /// <summary>
        /// Returns the element at the front of the buffer without removing it, throws an
        /// exception of the buffer is empty.
        /// </summary>
        public T Peek()
        {
            Assert.IsTrue(m_size > 0, "Peek must not be called on empty RingBuffer");

            return m_buffer[m_readIndex];
        }

        /// <summary>
        /// Returns whether there is an element at the front of the buffer and if so copies it to
        /// <paramref name="result" />, without removing it.
        /// </summary>
        public bool TryPeek(out T result)
        {
            if (m_size == 0)
            {
                result = default(T);
                return false;
            }

            result = m_buffer[m_readIndex];
            return true;
        }

        /// <summary>
        /// Returns the element at <paramref name="offset" /> (must be positive) from the front of
        /// the buffer without removing it, throws an exception if offset is out of range.
        /// </summary>
        public T PeekAt(int offset)
        {
            Assert.IsTrue(offset >= 0, "PeekAt offset must be positive");
            Assert.IsTrue(offset < m_size, "PeekAt offset must be less than size");

            return m_buffer[(m_readIndex + offset) % m_buffer.Length];
        }

        /// <summary>
        /// Returns whether there is an element at <paramref name="offset" /> (must be positive)
        /// from the front of the buffer and if so copies it to <paramref name="result" />,
        /// without removing it.
        /// </summary>
        public bool TryPeekAt(int offset, out T result)
        {
            Assert.IsTrue(offset >= 0, "TryPeekAt offset must be positive");

            if (offset >= m_size)
            {
                result = default(T);
                return false;
            }

            result = m_buffer[(m_readIndex + offset) % m_buffer.Length];
            return true;
        }

        // Internal helper to remove element at the front of the buffer. There must be at least
        // one element in the buffer!
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private T DequeueUnchecked()
        {
            T result = m_buffer[m_readIndex];
            m_buffer[m_readIndex] = default(T);
            m_readIndex = (m_readIndex + 1) % m_buffer.Length;
            --m_size;

            return result;
        }
    }

} // namespace VARLab.ExternalDisplay
