
// system namespaces
using System.Collections.Generic;
using System.IO;
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using Unity.Serialization.Json;
using System;

namespace VARLab.ExternalDisplay
{
    public static class SerializationUtils
    {
        // ------------------------------------------------------------------
        #region Serialization

        public static void SerializeVector2(
            IJsonSerializationContext context, Vector2 value, string key = null)
        {
            JsonWriter writer = context.Writer;

            using (writer.WriteArrayScope(key))
            {
                writer.WriteValue(value.x);
                writer.WriteValue(value.y);
            }
        }

        public static Vector2 DeserializeVector2(SerializedArrayView arrayView)
        {
            using (SerializedArrayView.Enumerator iter = arrayView.GetEnumerator())
            {
                bool hasX = iter.MoveNext();
                Assert.IsTrue(hasX);
                float x = iter.Current.AsFloat();
                bool hasY = iter.MoveNext();
                Assert.IsTrue(hasY);
                float y = iter.Current.AsFloat();

                return new Vector2(x, y);
            }
        }

        public static void SerializeVector2Int(
            IJsonSerializationContext context, Vector2Int value, string key = null)
        {
            JsonWriter writer = context.Writer;

            using (writer.WriteArrayScope(key))
            {
                writer.WriteValue(value.x);
                writer.WriteValue(value.y);
            }
        }

        public static Vector2Int DeserializeVector2Int(SerializedArrayView arrayView)
        {
            using (SerializedArrayView.Enumerator iter = arrayView.GetEnumerator())
            {
                bool hasX = iter.MoveNext();
                Assert.IsTrue(hasX);
                int x = iter.Current.AsInt32();
                bool hasY = iter.MoveNext();
                Assert.IsTrue(hasY);
                int y = iter.Current.AsInt32();

                return new Vector2Int(x, y);
            }
        }

        public static void SerializeVector3(
            IJsonSerializationContext context, Vector3 value, string key = null)
        {
            JsonWriter writer = context.Writer;

            using (writer.WriteArrayScope(key))
            {
                writer.WriteValue(value.x);
                writer.WriteValue(value.y);
                writer.WriteValue(value.z);
            }
        }

        public static Vector3 DeserializeVector3(SerializedArrayView arrayView)
        {
            using (SerializedArrayView.Enumerator iter = arrayView.GetEnumerator())
            {
                bool hasX = iter.MoveNext();
                Assert.IsTrue(hasX);
                float x = iter.Current.AsFloat();

                bool hasY = iter.MoveNext();
                Assert.IsTrue(hasY);
                float y = iter.Current.AsFloat();

                bool hasZ = iter.MoveNext();
                Assert.IsTrue(hasZ);
                float z = iter.Current.AsFloat();

                return new Vector3(x, y, z);
            }
        }

        public static void SerializeQuaternion(
            IJsonSerializationContext context, Quaternion value, string key = null)
        {
            JsonWriter writer = context.Writer;

            using (writer.WriteArrayScope(key))
            {
                Vector3 eulerAngles = value.eulerAngles;

                writer.WriteValue(eulerAngles.x);
                writer.WriteValue(eulerAngles.y);
                writer.WriteValue(eulerAngles.z);
            }
        }

        public static Quaternion DeserializeQuaternion(SerializedArrayView arrayView)
        {
            using (SerializedArrayView.Enumerator iter = arrayView.GetEnumerator())
            {
                bool hasX = iter.MoveNext();
                Assert.IsTrue(hasX);
                float x = iter.Current.AsFloat();

                bool hasY = iter.MoveNext();
                Assert.IsTrue(hasY);
                float y = iter.Current.AsFloat();

                bool hasZ = iter.MoveNext();
                Assert.IsTrue(hasZ);
                float z = iter.Current.AsFloat();

                return Quaternion.Euler(x, y, z);
            }
        }

        public static List<T> DeserializeList<T>(
            IJsonDeserializationContext context, SerializedArrayView arrayView)
        {
            List<T> values = new List<T>();

            foreach (SerializedValueView valueView in arrayView)
            {
                values.Add(context.DeserializeValue<T>(valueView));
            }

            return values;
        }

        public static void SerializeList<T>(
            IJsonSerializationContext context, IList<T> values, string key = null)
        {
            using (context.Writer.WriteArrayScope(key))
            {
                for (int i = 0, iEnd = values.Count; i < iEnd; ++i)
                {
                    context.SerializeValue(values[i]);
                }
            }
        }

        public static T DeserializeEnum<T>(SerializedValueView valueView)
            where T : struct, Enum
        {
            string valueString = valueView.AsStringView().ToString();

            if (System.Enum.TryParse(valueString, out T value))
                return value;

            Debug.LogError($"Unknown value '{valueString}' for enum {typeof(T)}.");
            throw new InvalidDataException($"Value '{valueString}' not valid for enum {typeof(T)}");
        }

        public static void SerializeEnum<T>(IJsonSerializationContext context, T value)
             where T : struct, Enum
        {
            context.Writer.WriteValue(Enum.GetName(typeof(T), value));
        }

        #endregion // Serialization
        // ------------------------------------------------------------------
        #region Clone

        public static T[] CloneArray<T>(T[] source) where T : ICloneable
        {
            T[] clone = new T[source.Length];

            for (int i = 0, iEnd = source.Length; i < iEnd; ++i)
            {
                clone[i] = (T)source[i].Clone();
            }

            return clone;
        }

        public static List<T> CloneList<T>(IList<T> source) where T : ICloneable
        {
            List<T> clone = new List<T>(source.Count);

            for (int i = 0, iEnd = source.Count; i < iEnd; ++i)
            {
                clone.Add((T)source[i].Clone());
            }

            return clone;
        }

        #endregion // Clone
        // ------------------------------------------------------------------
        #region Files

        public static string GetDefaultFolderPath()
        {
            return $"{Application.streamingAssetsPath}/VARLab_ExternalDisplay";
        }

        public static string GetDefaultSettingsFilePath(string suffix = null)
        {
            if (string.IsNullOrEmpty(suffix))
                return $"{GetDefaultFolderPath()}/settings.json";

            return $"{GetDefaultFolderPath()}/settings_{suffix}.json";
        }

        public static string GetSettingsFilePath(string suffix = null)
        {
            return GetOverridableFilePath(
                GetDefaultSettingsFilePath(suffix), "+external-display-settings");
        }

        public static bool TryLoadSettings(string filePath, out ExternalDisplaySettings settings)
        {
            if (!File.Exists(filePath))
            {
                settings = null;
                return false;
            }

            FileInfo fileInfo = new FileInfo(filePath);

            // XXX WORKAROUND:
            // There is a bug in com.unity.serialization v3.1.1 that results in some buffers
            // being too small (based on file size) and triggering assertions in the package.
            // Assume that if the file is less than 16 bytes it is empty.
            if (fileInfo.Length < 16)
            {
                Debug.Log(
                    $"Settings file '{filePath}' is {fileInfo.Length} bytes - triggering "
                    + "serialization workaround and assuming empty settings!");

                settings = new ExternalDisplaySettings();
                return true;
            }

            JsonSerializationParameters parameters = new JsonSerializationParameters()
            {
                UserDefinedAdapters = CreateCustomSerializationAdapters()
            };

            bool success = JsonSerialization.TryFromJson(
               fileInfo, out settings, out DeserializationResult result, parameters);

            if (!success)
            {
                Debug.LogWarning($"Loading of settings from '{filePath}' failed!");
            }

            foreach (DeserializationEvent evt in result.Events)
            {
                if (evt.Type == Unity.Serialization.Json.EventType.Log)
                {
                    Debug.Log($"{evt.Type}: {evt}");
                }
                else if (evt.Type == Unity.Serialization.Json.EventType.Warning)
                {
                    Debug.LogWarning($"{evt.Type}: {evt}");
                }
                else
                {
                    Debug.LogError($"{evt.Type}: {evt}");
                }
            }

            return success;
        }

        public static bool TrySaveSettings(
            string filePath, ExternalDisplaySettings settings, bool allowOverwrite = false,
            bool createBackup = true)
        {
            if (File.Exists(filePath))
            {
                if (!allowOverwrite)
                {
                    Debug.LogWarning(
                        $"Could not save settings to '{filePath}' - it already exists!");
                    return false;
                }

                if (createBackup)
                {
                    File.Copy(filePath, $"{filePath}.bak", overwrite: true);
                }
            }

            FileInfo fileInfo = new FileInfo(filePath);
            JsonSerializationParameters parameters = new JsonSerializationParameters()
            {
                UserDefinedAdapters = CreateCustomSerializationAdapters()
            };

            JsonSerialization.ToJson(fileInfo, settings, parameters);
            return true;
        }

        #endregion // Files
        // ------------------------------------------------------------------

        private static string GetOverridableFilePath(string defaultPath, string optionName)
        {
            string filePath = defaultPath;
            string[] args = System.Environment.GetCommandLineArgs();

            for (int i = 0, iEnd = args.Length; i < iEnd; ++i)
            {
                if (args[i].StartsWith($"{optionName}="))
                {
                    // handle optionName=value (split argument at = sign)
                    string pathArg = args[i].Replace($"{optionName}=", "");
                    if (IsPathFullyQualified(pathArg))
                    {
                        filePath = pathArg;
                    }
                    else
                    {
                        filePath = $"{Application.dataPath}/{pathArg}";
                    }
                }
                else if (args[i].Equals(optionName) && i + 1 < args.Length)
                {
                    // handle optionName value (separate arguments)
                    string pathArg = args[i + 1];
                    if (IsPathFullyQualified(pathArg))
                    {
                        filePath = pathArg;
                    }
                    else
                    {
                        filePath = $"{Application.dataPath}/{pathArg}";
                    }
                }
            }

            return filePath;
        }

        private static bool IsPathFullyQualified(string path)
        {
            if (string.IsNullOrWhiteSpace(path)
                || path.IndexOfAny(Path.GetInvalidPathChars()) != -1
                || !Path.IsPathRooted(path))
            {
                return false;
            }

            // reject empty, \, X:, but accept / for unix
            string pathRoot = Path.GetPathRoot(path);
            if (pathRoot.Length <= 2 && pathRoot != "/")
                return false;

            // rooted but not a UNC path
            if (pathRoot[0] != '\\' || pathRoot[1] != '\\')
                return true;

            // reject UNC server name without share
            return pathRoot.Trim('\\').IndexOf('\\') != -1;
        }

        private static List<IJsonAdapter> CreateCustomSerializationAdapters()
        {
            return new List<IJsonAdapter>()
            {
                new CoordinateModeJsonAdapter(),
                new ExternalDisplaySettingsJsonAdapter(),
                new PresentInfoOverrideAdapter(),
                new RectJsonAdapter(),
                new RenderScreenOverrideAdapter(),
                new SourceCameraInfoOverrideAdapter(),
                new TrackingOriginOverrideAdapter(),
                new WarpMeshControlPointsJsonAdapter(),
                new WarpMeshOverrideJsonAdapter(),
                new WarpMeshStyleJsonAdapter(),
                new WindowOverrideJsonAdapter(),
            };
        }
    }

} // namespace VARLab.ExternalDisplay
