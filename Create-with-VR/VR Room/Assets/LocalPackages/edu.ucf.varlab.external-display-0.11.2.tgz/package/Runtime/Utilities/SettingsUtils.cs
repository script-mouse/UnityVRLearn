
// system namespaces
using System.Collections.Generic;

// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;

namespace VARLab.ExternalDisplay
{
    public static class SettingsUtils
    {
        // ------------------------------------------------------------------
        #region Window Override

        /// <summary>
        /// Creates <c>WindowOverride</c>s capturing the difference between each item in
        /// <paramref name="windowInfos"/> and the corresponding item in
        /// <paramref name="initialWindowInfos"/>.
        /// </summary>
        /// <param name="windowInfos"></param>
        /// <param name="initialWindowInfos"></param>
        /// <returns></returns>
        public static List<WindowOverride> CreateWindowOverrides(
            IList<WindowInfo> windowInfos,
            IList<WindowInfo> initialWindowInfos)
        {
            Assert.AreEqual(windowInfos.Count, initialWindowInfos.Count);

            List<WindowOverride> windowOverrides = new List<WindowOverride>(windowInfos.Count);

            for (int i = 0, iEnd = windowInfos.Count; i < iEnd; ++i)
            {
                WindowInfo windowInfo = windowInfos[i];
                WindowInfo initialWindowInfo = initialWindowInfos[i];

                windowOverrides.Add(CreateWindowOverride(windowInfo, initialWindowInfo));
            }

            return windowOverrides;
        }

        /// <summary>
        /// Creates <c>WindowOverride</c>s matching the settings in <paramref name="windowInfos"/>.
        /// </summary>
        /// <param name="windowInfos"></param>
        /// <returns></returns>
        public static List<WindowOverride> CreateWindowOverrides(
            IList<WindowInfo> windowInfos)
        {
            List<WindowOverride> windowOverrides
                = new List<WindowOverride>(windowInfos.Count);

            for (int i = 0, iEnd = windowInfos.Count; i < iEnd; ++i)
            {
                windowOverrides.Add(CreateWindowOverride(windowInfos[i]));
            }

            return windowOverrides;
        }

        /// <summary>
        /// Creates a <c>WindowOverride</c> capturing the difference between
        /// <paramref name="windowInfo"/> and <paramref name="initialWindowInfo"/>.
        /// </summary>
        /// <param name="windowInfo"></param>
        /// <param name="initialWindowInfo"></param>
        /// <returns></returns>
        public static WindowOverride CreateWindowOverride(
            WindowInfo windowInfo, WindowInfo initialWindowInfo)
        {
            Assert.AreEqual(windowInfo.name, initialWindowInfo.name);

            WindowOverride windowOverride = new WindowOverride()
            {
                name = windowInfo.name,
            };

            if (windowInfo.position != initialWindowInfo.position)
                windowOverride.position = windowInfo.position;

            if (windowInfo.size != initialWindowInfo.size)
                windowOverride.size = windowInfo.size;

            return windowOverride;
        }

        /// <summary>
        /// Creates a <c>WindowOverride</c> matching the settings in <paramref name="windowInfo"/>.
        /// </summary>
        public static WindowOverride CreateWindowOverride(WindowInfo windowInfo)
        {
            return new WindowOverride()
            {
                name = windowInfo.name,
                position = windowInfo.position,
                size = windowInfo.size,
            };
        }

        #endregion // Window Override
        // ------------------------------------------------------------------
        #region PresentInfoOverride

        /// <summary>
        /// Creates <c>PresentInfoOverride</c>s capturing the difference between each item in
        /// <paramref name="presentInfos"/> and the corresponding item in
        /// <paramref name="initialPresentInfos"/>.
        /// </summary>
        /// <param name="presentInfos"></param>
        /// <param name="initialPresentInfos"></param>
        /// <returns></returns>
        public static List<PresentInfoOverride> CreatePresentInfoOverrides(
            IList<PresentInfo> presentInfos,
            IList<PresentInfo> initialPresentInfos)
        {
            Assert.AreEqual(presentInfos.Count, initialPresentInfos.Count);

            List<PresentInfoOverride> presentInfoOverrides
                = new List<PresentInfoOverride>(presentInfos.Count);

            for (int i = 0, iEnd = presentInfos.Count; i < iEnd; ++i)
            {
                PresentInfo presentInfo = presentInfos[i];
                PresentInfo initialPresentInfo = initialPresentInfos[i];

                presentInfoOverrides.Add(
                    CreatePresentInfoOverride(presentInfo, initialPresentInfo));
            }

            return presentInfoOverrides;
        }

        /// <summary>
        /// Creates <c>PresentInfoOverride</c>s matching the settings in
        /// <paramref name="presentInfos"/>.
        /// </summary>
        /// <param name="presentInfos"></param>
        /// <returns></returns>
        public static List<PresentInfoOverride> CreatePresentInfoOverrides(
            IList<PresentInfo> presentInfos)
        {
            List<PresentInfoOverride> presentOverrides
                = new List<PresentInfoOverride>(presentInfos.Count);

            for (int i = 0, iEnd = presentInfos.Count; i < iEnd; ++i)
            {
                presentOverrides.Add(CreatePresentInfoOverride(presentInfos[i]));
            }

            return presentOverrides;
        }

        /// <summary>
        /// Creates <c>PresentInfoOverride</c> capturing the difference between
        /// <paramref name="presentInfo"/> and <paramref name="initialPresentInfo"/>.
        /// </summary>
        /// <param name="presentInfo"></param>
        /// <param name="initialPresentInfo"></param>
        /// <returns></returns>
        public static PresentInfoOverride CreatePresentInfoOverride(
            PresentInfo presentInfo, PresentInfo initialPresentInfo)
        {
            Assert.AreEqual(presentInfo.name, initialPresentInfo.name);

            PresentInfoOverride presentInfoOverride = new PresentInfoOverride()
            {
                name = presentInfo.name,
            };

            if (presentInfo.targetWindow != initialPresentInfo.targetWindow)
                presentInfoOverride.targetWindow = presentInfo.targetWindow;

            if (presentInfo.warpMesh != initialPresentInfo.warpMesh)
                presentInfoOverride.warpMesh = presentInfo.warpMesh;

            if (presentInfo.sourceCamera != initialPresentInfo.sourceCamera)
                presentInfoOverride.sourceCamera = presentInfo.sourceCamera.name;

            if (presentInfo.viewportCoordinateMode != initialPresentInfo.viewportCoordinateMode)
                presentInfoOverride.viewportCoordinateMode = presentInfo.viewportCoordinateMode;

            if (presentInfo.viewportRect != initialPresentInfo.viewportRect)
                presentInfoOverride.viewportRect = presentInfo.viewportRect;

            return presentInfoOverride;
        }

        /// <summary>
        /// Creates <c>PresentInfoOverride</c> matching the settings in
        /// <paramref name="presentInfo"/>.
        /// </summary>
        /// <param name="presentInfo"></param>
        /// <returns></returns>
        public static PresentInfoOverride CreatePresentInfoOverride(PresentInfo presentInfo)
        {
            return new PresentInfoOverride()
            {
                name = presentInfo.name,
                targetWindow = presentInfo.targetWindow,
                warpMesh = presentInfo.warpMesh,
                sourceCamera = presentInfo.sourceCamera.name,
                viewportCoordinateMode = presentInfo.viewportCoordinateMode,
                viewportRect = presentInfo.viewportRect,
            };
        }

        #endregion // PresentInfoOverride
        // ------------------------------------------------------------------
        #region WarpMeshOverride

        /// <summary>
        /// Creates <c>WarpMeshOverride</c>s capturing the difference between each item in
        /// <paramref name="warpMeshInfos"/> and the corresponding item in
        /// <paramref name="initialWarpMeshInfos"/>.
        /// </summary>
        /// <param name="warpMeshInfos"></param>
        /// <param name="initialWarpMeshInfos"></param>
        /// <returns></returns>
        public static List<WarpMeshOverride> CreateWarpMeshOverrides(
            IList<WarpMeshInfo> warpMeshInfos,
            IList<WarpMeshInfo> initialWarpMeshInfos)
        {
            Assert.AreEqual(warpMeshInfos.Count, initialWarpMeshInfos.Count);

            List<WarpMeshOverride> warpMeshOverrides
                = new List<WarpMeshOverride>(warpMeshInfos.Count);

            for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
            {
                WarpMeshInfo warpMeshInfo = warpMeshInfos[i];
                WarpMeshInfo initialWarpMeshInfo = initialWarpMeshInfos[i];

                warpMeshOverrides.Add(CreateWarpMeshOverride(warpMeshInfo, initialWarpMeshInfo));
            }

            return warpMeshOverrides;
        }

        /// <summary>
        /// Creates <c>WarpMeshOverride</c>s matching the settings in
        /// <paramref name="warpMeshInfos"/>.
        /// </summary>
        /// <param name="warpMeshInfos"></param>
        /// <returns></returns>
        public static List<WarpMeshOverride> CreateWarpMeshOverrides(
            IList<WarpMeshInfo> warpMeshInfos)
        {
            List<WarpMeshOverride> warpMeshOverrides
                = new List<WarpMeshOverride>(warpMeshInfos.Count);

            for (int i = 0, iEnd = warpMeshInfos.Count; i < iEnd; ++i)
            {
                warpMeshOverrides.Add(CreateWarpMeshOverride(warpMeshInfos[i]));
            }

            return warpMeshOverrides;
        }

        /// <summary>
        /// Creates <c>WarpMeshOverride</c> capturing the difference between
        /// <paramref name="warpMeshInfo"/> and <paramref name="initialWarpMeshInfo"/>.
        /// </summary>
        /// <param name="warpMeshInfo"></param>
        /// <param name="initialWarpMeshInfo"></param>
        /// <returns></returns>
        public static WarpMeshOverride CreateWarpMeshOverride(
            WarpMeshInfo warpMeshInfo, WarpMeshInfo initialWarpMeshInfo)
        {
            Assert.AreEqual(warpMeshInfo.name, initialWarpMeshInfo.name);

            WarpMeshOverride warpMeshOverride = new WarpMeshOverride()
            {
                name = warpMeshInfo.name,
            };

            if (warpMeshInfo.warpStyle != initialWarpMeshInfo.warpStyle)
                warpMeshOverride.style = warpMeshInfo.warpStyle;

            if (warpMeshInfo.sourceResolution != initialWarpMeshInfo.sourceResolution)
                warpMeshOverride.sourceResolution = warpMeshInfo.sourceResolution;

            if (warpMeshInfo.coordinateMode != initialWarpMeshInfo.coordinateMode)
                warpMeshOverride.coordinateMode = warpMeshInfo.coordinateMode;

            if (warpMeshInfo.sourceRect != initialWarpMeshInfo.sourceRect)
                warpMeshOverride.sourceRect = warpMeshInfo.sourceRect;

            if (warpMeshInfo.meshResolution != initialWarpMeshInfo.meshResolution)
                warpMeshOverride.meshResolution = warpMeshInfo.meshResolution;

            warpMeshOverride.controlPoints = warpMeshInfo.controlPoints.Clone();

            return warpMeshOverride;
        }

        /// <summary>
        /// Creates <c>WarpMeshOverride</c> matching the settings in
        /// <paramref name="warpMeshInfo"/>.
        /// </summary>
        /// <param name="warpMeshInfo"></param>
        /// <returns></returns>
        public static WarpMeshOverride CreateWarpMeshOverride(WarpMeshInfo warpMeshInfo)
        {
            return new WarpMeshOverride()
            {
                name = warpMeshInfo.name,
                style = warpMeshInfo.warpStyle,
                sourceResolution = warpMeshInfo.sourceResolution,
                coordinateMode = warpMeshInfo.coordinateMode,
                sourceRect = warpMeshInfo.sourceRect,
                meshResolution = warpMeshInfo.meshResolution,
                controlPoints = warpMeshInfo.controlPoints.Clone()
            };
        }

        #endregion // WarpMeshOverride
        // ------------------------------------------------------------------
        #region TrackingOriginOverride

        public static TrackingOriginOverride CreateTrackingOriginOverride(
            ExternalDisplayCameraRig cameraRig)
        {
            Transform trackingOrigin = cameraRig.trackingOrigin;
            TrackingOriginOverride trackingOriginOverride = new TrackingOriginOverride();

            if (trackingOrigin != null)
            {
                trackingOriginOverride.positionOffset = trackingOrigin.localPosition;
                trackingOriginOverride.rotationOffset = trackingOrigin.localRotation;
            }

            return trackingOriginOverride;
        }

        #endregion // TrackingOriginOverride
        // ------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
