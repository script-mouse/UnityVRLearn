
// system namespaces
using System.Collections.Generic;
// unity namespaces
using UnityEngine;
using UnityEngine.PlayerLoop;

namespace VARLab.ExternalDisplay
{
    public class StateMachineBase<S> where S : System.Enum
    {
        // ------------------------------------------------------------------
        #region Properties

        public S State
        {
            get => m_state;
        }

        public S PreviousState
        {
            get => m_previousState;
        }

        #endregion // Properties
        // ------------------------------------------------------------------
        #region Fields

        protected S m_state = default;
        protected S m_previousState = default;
        protected Queue<S> m_stateQueue = new Queue<S>(2);
        protected bool m_transitionActive = false;

        protected Dictionary<StatesTransition, TransitionCallback> m_transitionMap
            = new Dictionary<StatesTransition, TransitionCallback>(new StatesTransitionComparer());
        protected Dictionary<S, UpdateCallback> m_updateMap = new Dictionary<S, UpdateCallback>();

        #endregion // Fields
        // ------------------------------------------------------------------
        #region Public API

        /// <summary>
        /// Call the registered update function (see <see cref="RegisterUpdate" />) for the current
        /// state (if any).
        /// </summary>
        public void Update()
        {
            if (m_updateMap.TryGetValue(m_state, out UpdateCallback update))
            {
                update(m_state);
            }
        }

        /// <summary>
        /// Transition to <paramref name="targetState" /> invoking the registered transition
        /// function (see <see cref="RegisterTransition" />).
        /// <b>NOTE:</b> It is an error to request a transition for which no function was
        /// registered.
        /// </summary>
        public void Transition(S targetState)
        {
            if (m_transitionActive)
            {
                // a transition is already in progress, queue next state
                m_stateQueue.Enqueue(targetState);
            }
            else
            {
                m_transitionActive = true;
                PerformTransition(targetState);

                // if another transition happens as part of the above PerformTransition call
                // it will be in the queue - process it now
                while (m_stateQueue.Count > 0)
                {
                    PerformTransition(m_stateQueue.Dequeue());
                }

                m_transitionActive = false;
            }
        }

        #endregion // Public API
        // ------------------------------------------------------------------
        #region Protected Types

        protected delegate void TransitionCallback(S sourceState, S targetState);
        protected delegate void UpdateCallback(S state);

        protected struct StatesTransition
        {
            public S SourceState;
            public S TargetState;
        }

        protected class StatesTransitionComparer
            : IEqualityComparer<StatesTransition>
        {
            public bool Equals(StatesTransition lhs, StatesTransition rhs)
            {
                return lhs.SourceState.Equals(rhs.SourceState)
                    && lhs.TargetState.Equals(rhs.TargetState);
            }

            public int GetHashCode(StatesTransition states)
            {
                // System.HashCode is not available in Unity :(
                // return System.HashCode.Combine(states.sourceState, states.targetState);

                const uint c1 = 0xcc9e2d51;
                const uint c2 = 0x1b873593;

                uint h1 = (uint)states.SourceState.GetHashCode();
                h1 *= c1;
                h1 = (h1 << 15) | (h1 >> 17);
                h1 *= c2;

                h1 ^= (uint)states.TargetState.GetHashCode();
                h1 = (h1 << 13) | (h1 >> 19);
                h1 = h1 * 5 + 0xe6546b64;

                return (int)h1;
            }
        }

        #endregion // Protected Types
        // ------------------------------------------------------------------

        protected void PerformTransition(S targetState)
        {
            StatesTransition states = new StatesTransition()
            {
                SourceState = m_state,
                TargetState = targetState
            };

            if (m_transitionMap.TryGetValue(states, out TransitionCallback transition))
            {
                transition(m_state, targetState);
                m_previousState = m_state;
                m_state = targetState;
            }
            else
            {
                Debug.LogError($"Unregistered state transition {m_state} -> {targetState}!");
            }
        }

        /// <summary>
        /// Register function to call when transitioning from <paramref name="sourceState" /> to
        /// <paramref name="targetState" />.
        /// </summary>
        protected void RegisterTransition(
            S sourceState, S targetState, TransitionCallback transition)
        {
            m_transitionMap.Add(new StatesTransition()
            {
                SourceState = sourceState,
                TargetState = targetState
            }, transition);
        }

        /// <summary>
        /// Register function to call when transitioning from any state in
        /// <paramref name="sourceStates" /> to <paramref name="targetState" />.
        /// </summary>
        protected void RegisterMultiTransition(
            S[] sourceStates, S targetState, TransitionCallback transition)
        {
            for (int i = 0, iEnd = sourceStates.Length; i < iEnd; ++i)
                RegisterTransition(sourceStates[i], targetState, transition);
        }

        /// <summary>
        /// Register function to call from <c>Update</c> while in <paramref name="state" />.
        /// A typical use case is to initiate a transition to a new state from the registered
        /// function, e.g. by checking some conditions and calling <c>Transition</c>.
        /// </summary>
        protected void RegisterUpdate(S state, UpdateCallback update)
        {
            m_updateMap.Add(state, update);
        }
    }

} // namespace VARLab.ExternalDisplay
