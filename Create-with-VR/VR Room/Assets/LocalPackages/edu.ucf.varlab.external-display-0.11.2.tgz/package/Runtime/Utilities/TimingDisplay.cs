
// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
// external namespaces
using TMPro;

namespace VARLab.ExternalDisplay
{
    public class TimingDisplay
       : MonoBehaviour
    {
        [SerializeField]
        private Canvas m_canvas;

        [SerializeField]
        private TextMeshProUGUI m_text;

        private RingBuffer<float> m_deltaTimeBuffer;

        private float m_lastTextUpdate = 0.0f;

        private const int k_bufferSize = 120;
        private const float k_textUpdateInterval = 1.0f;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        private void Awake()
        {
            Assert.IsNotNull(m_text);

            m_deltaTimeBuffer = new RingBuffer<float>(k_bufferSize);
        }

        private void Update()
        {
            UpdateBuffer();

            if (Time.time - m_lastTextUpdate >= k_textUpdateInterval)
            {
                UpdateText();
                m_lastTextUpdate = Time.time;
            }
        }

        private void OnEnable()
        {
            if (m_canvas != null)
                m_canvas.enabled = true;

            if (m_text != null)
                m_text.enabled = true;

            m_deltaTimeBuffer.Clear();
            m_lastTextUpdate = Time.time;
        }

        private void OnDisable()
        {
            if (m_canvas != null)
                m_canvas.enabled = false;

            if (m_text != null)
                m_text.enabled = false;
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        private void UpdateBuffer()
        {
            float deltaTime = Time.deltaTime;
            m_deltaTimeBuffer.Enqueue(deltaTime);
        }

        private void UpdateText()
        {
            if (m_deltaTimeBuffer.Count == 0)
            {
                m_text.text
                    = $"Frame: {Time.frameCount,5:D}  "
                    + $"Avg T: N/A   Min T: N/A   Max T: N/A   FPS: N/A";
                return;
            }

            float[] timeBuffer = m_deltaTimeBuffer.Buffer;
            float minFrameTime = float.MaxValue;
            float maxFrameTime = 0.0f;
            float sumFrameTime = 0.0f;

            for (int i = 0, iEnd = m_deltaTimeBuffer.Count; i < iEnd; ++i)
            {
                float deltaTime = timeBuffer[i];
                minFrameTime = Mathf.Min(minFrameTime, deltaTime);
                maxFrameTime = Mathf.Max(maxFrameTime, deltaTime);
                sumFrameTime += deltaTime;
            }

            float avgFrameTime = sumFrameTime / m_deltaTimeBuffer.Count;
            float fps = 1.0f / avgFrameTime;

            m_text.text
                = $"Frame: {Time.frameCount,5:D}  "
                + $"Avg T: {avgFrameTime,5:F3}  Min T: {minFrameTime,5:F3}  "
                + $"Max T: {maxFrameTime,5:F3}  FPS: {fps,5:F0}";
        }
    }

} // namespace VARLab.ExternalDisplay
