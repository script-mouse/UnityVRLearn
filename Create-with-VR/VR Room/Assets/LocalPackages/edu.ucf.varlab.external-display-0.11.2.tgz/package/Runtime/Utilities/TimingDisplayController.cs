// Only compile if input system is used
#if ENABLE_INPUT_SYSTEM

// unity namespaces
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.InputSystem;

namespace VARLab.ExternalDisplay
{
    public class TimingDisplayController
        : MonoBehaviour
    {
        [SerializeField]
        private TimingDisplay m_timingDisplay;
        
        [SerializeField]
        private InputActionProperty m_toggleAction;

        // ------------------------------------------------------------------
        #region MonoBehaviour

        private void Awake()
        {
            Assert.IsNotNull(m_timingDisplay);
        }

        private void OnEnable()
        {
            if (m_toggleAction.action != null)
            {
                m_toggleAction.action.performed += HandleToggleActionPerformed;
                m_toggleAction.action.Enable();
            }
        }

        private void OnDisable()
        {
            if (m_toggleAction.action != null)
            {
                m_toggleAction.action.Disable();
                m_toggleAction.action.performed -= HandleToggleActionPerformed;
            }
        }

        #endregion // MonoBehaviour
        // ------------------------------------------------------------------

        private void HandleToggleActionPerformed(InputAction.CallbackContext context)
        {
            m_timingDisplay.enabled = !m_timingDisplay.enabled;
        }
    }

} // namespace VARLab.ExternalDisplay

#endif // ENABLE_INPUT_SYSTEM
