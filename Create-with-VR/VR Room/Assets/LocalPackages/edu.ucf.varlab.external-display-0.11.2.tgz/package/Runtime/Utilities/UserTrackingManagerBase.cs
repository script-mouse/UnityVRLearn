
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Base class for different head tracking configurations.
    /// </summary>
    [Serializable]
    public class UserTrackingConfigBase
    {
        [Tooltip("User name (must be unique)")]
        public string name;
    }

    /// <summary>
    /// Base class for switching between different trackers for the camera. This can be used
    /// to switch head tracking between multiple users.
    /// </summary>
    public abstract class UserTrackingManagerBase
        : MonoBehaviour
    {
        // ----------------------------------------------------------------------
        #region Properties

        public static int inactiveUserIndex
        {
            get => k_inactiveUserIndex;
        }

        public int activeUserIndex
        {
            get => m_activeUserIndex;
            set => SwitchActiveUser(value);
        }

        public abstract UserTrackingConfigBase activeUserConfig
        {
            get;
        }

        #endregion // Properties
        // ----------------------------------------------------------------------

        [SerializeField]
        [Tooltip("Camera origin that is switched to follow different user head trackers")]
        protected RenderViewCameraOriginBase m_cameraOrigin;

        [SerializeField]
        [Tooltip("Index of user to activate on Start")]
        protected int m_userIndexOnStart = k_inactiveUserIndex;

        // Index of the currently active user
        protected int m_activeUserIndex = k_inactiveUserIndex;

        // Index used to indicate no active user
        protected const int k_inactiveUserIndex = -1;

        // ----------------------------------------------------------------------
        #region API

        public abstract void SwitchActiveUser(int index);

        #endregion // API
        // ----------------------------------------------------------------------
        #region MonoBehaviour

        private void Start()
        {
            SwitchActiveUser(m_userIndexOnStart);
        }

        #endregion // MonoBehaviour
        // ----------------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
