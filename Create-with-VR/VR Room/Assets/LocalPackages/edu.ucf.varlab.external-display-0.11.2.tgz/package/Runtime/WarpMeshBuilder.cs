
// system namespaces
using System;
using System.Collections.Generic;
// unity namespaces
using Unity.Collections;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.Rendering;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Creates or updates Mesh objects used to warp images rendered to present windows.
    /// </summary>
    public static class WarpMeshBuilder
    {
        // ------------------------------------------------------------------
        #region Public API

        /// <summary>
        /// Returns true if mesh appears to be suitable for having its vertex data updated
        /// by <see cref="UpdateVertexData"/>.
        /// </summary>
        public static bool CanUpdateVertexData(
            Mesh mesh, WarpMeshStyle meshStyle, Vector2Int resolution)
        {
            int numVerts = CalcVertexCount(
                meshStyle, resolution, out int numVertsX, out int numVertsY);
            int numIndices = CalcIndexCount(
                meshStyle, resolution, out int numCellsX, out int numCellsY);

            return (mesh.vertexCount == numVerts
                && mesh.subMeshCount == 1
                && mesh.GetIndexCount(0) == numIndices);
        }

        /// <summary>
        /// Updates vertex data only. The 'mesh' must already have indices for the given
        /// <paramref name="meshStyle"/> and <paramref name="meshResolution"/>, i.e. from a
        /// previous call to <see cref="CreateWarpMesh"/>.
        /// </summary>
        public static void UpdateVertexData(
            Mesh mesh, WarpMeshStyle meshStyle, WarpMeshControlPoints controlPoints,
            Vector2Int meshResolution, Rect sourceRect)
        {
            Assert.IsTrue(CanUpdateVertexData(mesh, meshStyle, meshResolution));

            List<WarpMeshVertex> vertices;

            switch (meshStyle)
            {
                case WarpMeshStyle.FullscreenQuad:
                    vertices = MakeVerticesFullscreenQuad(sourceRect);
                    break;

                case WarpMeshStyle.Linear:
                case WarpMeshStyle.Spline:
                case WarpMeshStyle.Homography:
                case WarpMeshStyle.MultiHomography:
                    vertices = MakeVerticesGrid(
                        meshStyle, controlPoints, meshResolution, sourceRect);
                    break;

                default:
                    Assert.IsTrue(false, $"Unhandled WarpMeshStyle '{meshStyle}'!");
                    vertices = null;
                    break;
            }

            mesh.SetVertexBufferData(vertices, 0, 0, vertices.Count, 0, MeshUpdateFlags.Default);
            mesh.UploadMeshData(markNoLongerReadable: false);
        }

        /// <summary>
        /// Returns a new <c>Mesh</c> object for warping.
        /// </summary>
        public static Mesh CreateWarpMesh(
            WarpMeshStyle meshStyle, WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            Rect sourceRect)
        {
            CreateVertexData(
                meshStyle, controlPoints, meshResolution, sourceRect,
                 out List<WarpMeshVertex> vertices, out List<UInt16> indices);

            Mesh mesh = new Mesh();
            mesh.SetIndexBufferParams(indices.Count, IndexFormat.UInt16);
            // Float2 Position
            // Float2 UV
            VertexAttributeDescriptor[] vertexLayout = new VertexAttributeDescriptor[]
            {
                new VertexAttributeDescriptor(
                    VertexAttribute.Position, VertexAttributeFormat.Float32, 2),
                new VertexAttributeDescriptor(
                    VertexAttribute.TexCoord0, VertexAttributeFormat.Float32, 2)
            };
            mesh.SetVertexBufferParams(vertices.Count, vertexLayout);

            mesh.SetVertexBufferData(
                vertices, 0, 0, vertices.Count, 0, MeshUpdateFlags.Default);
            mesh.SetIndexBufferData(indices, 0, 0, indices.Count, MeshUpdateFlags.Default);

            SubMeshDescriptor subMeshDesc = new SubMeshDescriptor()
            {
                baseVertex = 0,
                bounds = default,
                firstVertex = 0,
                indexCount = indices.Count,
                indexStart = 0,
                topology = MeshTopology.Triangles,
                vertexCount = vertices.Count
            };
            mesh.SetSubMesh(0, subMeshDesc, MeshUpdateFlags.DontRecalculateBounds);
            mesh.UploadMeshData(markNoLongerReadable: false);

            return mesh;
        }

        /// <summary>
        /// Creates vertex and index data for a warp mesh with style <paramref name="meshStyle"/>,
        /// control points <paramref name="controlPoints"/>, and mesh resolution
        /// <paramref name="meshResolution"/>.
        /// </summary>
        public static void CreateVertexData(
            WarpMeshStyle meshStyle, WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            Rect sourceRect, out List<WarpMeshVertex> vertices, out List<UInt16> indices)
        {
            switch (meshStyle)
            {
                case WarpMeshStyle.FullscreenQuad:
                    vertices = MakeVerticesFullscreenQuad(sourceRect);
                    indices = MakeIndicesFullscreenQuad();
                    break;

                case WarpMeshStyle.Linear:
                case WarpMeshStyle.Spline:
                case WarpMeshStyle.Homography:
                case WarpMeshStyle.MultiHomography:
                    vertices = MakeVerticesGrid(
                        meshStyle, controlPoints, meshResolution, sourceRect);
                    indices = MakeIndicesGrid(meshResolution);
                    break;

                default:
                    Assert.IsTrue(false, $"Unhandled WarpMeshStyle '{meshStyle}'!");
                    vertices = null;
                    indices = null;
                    break;
            }
        }

        /// <summary>
        /// Creates a NativeWarpMeshDesc for the given <paramref name="mesh" />.
        /// </summary>
        public static NativeWarpMeshDesc CreateWarpMeshDesc(Mesh mesh)
        {
            Assert.AreEqual(1, mesh.subMeshCount, "Mesh must have 1 submesh");
            Assert.AreEqual(1, mesh.vertexBufferCount, "Mesh must have 1 vertex buffer");

            Assert.AreEqual(2, mesh.vertexAttributeCount, "Mesh must have 2 attributes (pos, uv)");
            VertexAttributeDescriptor attr0Desc = mesh.GetVertexAttribute(0);
            Assert.AreEqual(VertexAttribute.Position, attr0Desc.attribute);
            Assert.AreEqual(VertexAttributeFormat.Float32, attr0Desc.format);
            Assert.AreEqual(2, attr0Desc.dimension);
            VertexAttributeDescriptor attr1Desc = mesh.GetVertexAttribute(1);
            Assert.AreEqual(VertexAttribute.TexCoord0, attr1Desc.attribute);
            Assert.AreEqual(VertexAttributeFormat.Float32, attr1Desc.format);
            Assert.AreEqual(2, attr1Desc.dimension);

            SubMeshDescriptor subMeshDescriptor = mesh.GetSubMesh(0);
            Assert.IsTrue(subMeshDescriptor.indexStart == 0);
            Assert.IsTrue(subMeshDescriptor.topology == MeshTopology.Triangles);

            NativeWarpMeshDesc desc = new NativeWarpMeshDesc()
            {
                VertexCount = (UInt32)subMeshDescriptor.vertexCount,
                IndexCount = (UInt32)subMeshDescriptor.indexCount,
                NativeIndexBuffer = mesh.GetNativeIndexBufferPtr(),
                NativeVertexBuffer = mesh.GetNativeVertexBufferPtr(0),
                IndexData = IntPtr.Zero,
                VertexData = IntPtr.Zero,
            };

            return desc;
        }

        #endregion // Public API
        // ------------------------------------------------------------------

        /// <summary>
        /// Returns total number of vertices needed for the given <paramref name="meshStyle"/> and
        /// <paramref name="meshResolution"/>. Additionally, the output parameters
        /// <paramref name="numVertsX"/> and <paramref name="numVertsY"/> are set to the number
        /// of vertices in horizontal and vertical direction respectively.
        /// </summary>
        /// <param name="meshStyle"></param>
        /// <param name="meshResolution"></param>
        /// <param name="numVertsX"></param>
        /// <param name="numVertsY"></param>
        /// <returns></returns>
        private static int CalcVertexCount(
            WarpMeshStyle meshStyle, Vector2Int meshResolution,
            out int numVertsX, out int numVertsY)
        {
            if (meshStyle == WarpMeshStyle.FullscreenQuad)
            {
                // fixed size independent of meshResolution
                numVertsX = 2;
                numVertsY = 2;
            }
            else
            {
                numVertsX = 2 * meshResolution.x + 1;
                numVertsY = 2 * meshResolution.y + 1;
            }

            return numVertsX * numVertsY;
        }

        private static int CalcIndexCount(
            WarpMeshStyle meshStyle, Vector2Int meshResolution,
            out int numCellsX, out int numCellsY)
        {
            if (meshStyle == WarpMeshStyle.FullscreenQuad)
            {
                // fixed size independent of meshResolution
                numCellsX = 1;
                numCellsY = 1;
            }
            else
            {
                numCellsX = 2 * meshResolution.x;
                numCellsY = 2 * meshResolution.y;
            }

            return 6 * numCellsX * numCellsY;
        }

        /// <summary>
        /// Returns vertices for a fullscreen quad (vertex positions are in NDC).
        /// </summary>
        /// <param name="sourceRect"></param>
        /// <returns></returns>
        private static List<WarpMeshVertex> MakeVerticesFullscreenQuad(Rect sourceRect)
        {
            List<WarpMeshVertex> vertices = new List<WarpMeshVertex>(4)
            {
                new WarpMeshVertex()
                {
                    position = new Vector2(-1.0f, -1.0f),
                    uv = new Vector2(sourceRect.x, sourceRect.y)
                },
                new WarpMeshVertex()
                {
                    position = new Vector2(-1.0f, 1.0f),
                    uv = new Vector2(sourceRect.x, sourceRect.y + sourceRect.height)
                },
                new WarpMeshVertex()
                {
                    position = new Vector2(1.0f, 1.0f),
                    uv = new Vector2(
                        sourceRect.x + sourceRect.width,
                        sourceRect.y + sourceRect.height)
                },
                new WarpMeshVertex()
                {
                    position = new Vector2(1.0f, -1.0f),
                    uv = new Vector2(sourceRect.x + sourceRect.width, sourceRect.y)
                },
            };

            return vertices;
        }

        private static List<UInt16> MakeIndicesFullscreenQuad()
        {
            return new List<UInt16>(6)
            {
                0, 1, 3,
                3, 1, 2
            };
        }

        /// <summary>
        /// Returns vertices for a grid warp mesh, where the positions are calculated using
        /// the method <paramref name="meshStyle"/> based on control point positions from
        /// <paramref name="controlPoints"/>.
        /// </summary>
        /// <param name="meshStyle"></param>
        /// <param name="controlPoints"></param>
        /// <param name="meshResolution"></param>
        /// <param name="sourceRect"></param>
        /// <returns></returns>
        private static List<WarpMeshVertex> MakeVerticesGrid(
            WarpMeshStyle meshStyle, WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            Rect sourceRect)
        {
            int numVerts = CalcVertexCount(
                meshStyle, meshResolution, out int numVertsX, out int numVertsY);

            List<WarpMeshVertex> vertices = new List<WarpMeshVertex>(numVerts);
            for (int i = 0, iEnd = numVerts; i < iEnd; ++i)
            {
                vertices.Add(new WarpMeshVertex()
                {
                    position = Vector2.zero,
                    uv = Vector2.zero,
                });
            }

            switch (meshStyle)
            {
                case WarpMeshStyle.Linear:
                    SetVertexPositionsLinear(controlPoints, meshResolution, ref vertices);
                    break;

                case WarpMeshStyle.Spline:
                    SetVertexPositionsSpline(controlPoints, meshResolution, ref vertices);
                    break;

                case WarpMeshStyle.Homography:
                    SetVertexPositionsHomography(controlPoints, meshResolution, ref vertices);
                    break;

                case WarpMeshStyle.MultiHomography:
                    SetVertexPositionsMultiHomography(controlPoints, meshResolution, ref vertices);
                    break;

                default:
                    Assert.IsTrue(false, $"Unhandled WarpMeshStyle {meshStyle}!");
                    break;
            }

            SetVertexUVsGrid(meshResolution, sourceRect, ref vertices);

            return vertices;
        }

        /// <summary>
        /// Fills <paramref name="vertices"/> positions based on linear interpolation between
        /// <paramref name="controlPoints"/>.
        /// </summary>
        /// <param name="controlPoints"></param>
        /// <param name="meshResolution"></param>
        /// <param name="vertices"></param>
        private static void SetVertexPositionsLinear(
            WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            ref List<WarpMeshVertex> vertices)
        {
            int numVerts = CalcVertexCount(
                WarpMeshStyle.Linear, meshResolution, out int numVertsX, out int numVertsY);
            Assert.AreEqual(numVerts, vertices.Count);

            for (int y = 0; y < numVertsY; ++y)
            {
                // interpolated positions left, center, right
                Vector2 yL;
                Vector2 yC;
                Vector2 yR;

                if (y < meshResolution.y)
                {
                    // bottom half
                    float t = (float)y / meshResolution.y;
                    yL = Vector2.Lerp(controlPoints.bottomLeft, controlPoints.left, t);
                    yC = Vector2.Lerp(controlPoints.bottom, controlPoints.center, t);
                    yR = Vector2.Lerp(controlPoints.bottomRight, controlPoints.right, t);
                }
                else
                {
                    // top half
                    float t = (float)(y - meshResolution.y) / meshResolution.y;
                    yL = Vector2.Lerp(controlPoints.left, controlPoints.topLeft, t);
                    yC = Vector2.Lerp(controlPoints.center, controlPoints.top, t);
                    yR = Vector2.Lerp(controlPoints.right, controlPoints.topRight, t);
                }

                for (int x = 0; x < numVertsX; ++x)
                {
                    int i = y * numVertsX + x;

                    if (x < meshResolution.x)
                    {
                        // left half
                        float t = (float)x / meshResolution.x;

                        WarpMeshVertex vertex = vertices[i];
                        vertex.position = Vector2.Lerp(yL, yC, t);
                        vertices[i] = vertex;
                    }
                    else
                    {
                        // right half
                        float t = (float)(x - meshResolution.x) / meshResolution.x;

                        WarpMeshVertex vertex = vertices[i];
                        vertex.position = Vector2.Lerp(yC, yR, t);
                        vertices[i] = vertex;
                    }
                }
            }
        }

        /// <summary>
        /// Fills <paramref name="vertices"/> positions based on constructing splines through
        /// the <paramref name="controlPoints"/>.
        /// </summary>
        /// <param name="controlPoints"></param>
        /// <param name="meshResolution"></param>
        /// <param name="vertices"></param>
        private static void SetVertexPositionsSpline(
            WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            ref List<WarpMeshVertex> vertices)
        {
            // extrapolated control points, * = controlPoint
            //  0   1   2   3   4
            //  5   *   *   *   6
            //  7   *   *   *   8
            //  9   *   *   *  10
            // 11  12  13  14  15

            Vector2[] extraCP = new Vector2[16];
            extraCP[0]
                = controlPoints.topLeft
                + (controlPoints.topLeft - controlPoints.top)
                + (controlPoints.topLeft - controlPoints.left);
            extraCP[1]
                = controlPoints.topLeft + (controlPoints.topLeft - controlPoints.left);
            extraCP[2] = controlPoints.top + (controlPoints.top - controlPoints.center);
            extraCP[3]
                = controlPoints.topRight + (controlPoints.topRight - controlPoints.right);
            extraCP[4]
                = controlPoints.topRight
                + (controlPoints.topRight - controlPoints.top)
                + (controlPoints.topRight - controlPoints.right);

            extraCP[5]
                = controlPoints.topLeft + (controlPoints.topLeft - controlPoints.top);
            extraCP[6]
                = controlPoints.topRight + (controlPoints.topRight - controlPoints.top);
            extraCP[7]
                = controlPoints.left + (controlPoints.left - controlPoints.center);
            extraCP[8]
                = controlPoints.right + (controlPoints.right - controlPoints.center);
            extraCP[9]
                = controlPoints.bottomLeft + (controlPoints.bottomLeft - controlPoints.bottom);
            extraCP[10]
                = controlPoints.bottomRight + (controlPoints.bottomRight - controlPoints.bottom);

            extraCP[11]
                = controlPoints.bottomLeft
                + (controlPoints.bottomLeft - controlPoints.bottom)
                + (controlPoints.bottomLeft - controlPoints.left);
            extraCP[12]
                = controlPoints.bottomLeft + (controlPoints.bottomLeft - controlPoints.left);
            extraCP[13]
                = controlPoints.bottom + (controlPoints.bottom - controlPoints.center);
            extraCP[14]
                = controlPoints.bottomRight + (controlPoints.bottomRight - controlPoints.right);
            extraCP[15]
                = controlPoints.bottomRight
                + (controlPoints.bottomRight - controlPoints.bottom)
                + (controlPoints.bottomLeft - controlPoints.right);

            int numVerts = CalcVertexCount(
                WarpMeshStyle.Spline, meshResolution, out int numVertsX, out int numVertsY);
            Assert.AreEqual(numVerts, vertices.Count);

            for (int y = 0; y < numVertsY; ++y)
            {
                // interpolated positions
                Vector2 y0;
                Vector2 y1;
                Vector2 y2;
                Vector2 y3;
                Vector2 y4;

                if (y < meshResolution.y)
                {
                    // bottom half
                    float ty = (float)y / meshResolution.y;
                    y0 = MathUtils.EvalSpline(extraCP[11], extraCP[9], extraCP[7], extraCP[5], ty);
                    y1 = MathUtils.EvalSpline(
                        extraCP[12], controlPoints.bottomLeft, controlPoints.left,
                        controlPoints.topLeft, ty);
                    y2 = MathUtils.EvalSpline(
                        extraCP[13], controlPoints.bottom, controlPoints.center,
                        controlPoints.top, ty);
                    y3 = MathUtils.EvalSpline(
                        extraCP[14], controlPoints.bottomRight, controlPoints.right,
                        controlPoints.topRight, ty);
                    y4 = MathUtils.EvalSpline(extraCP[15], extraCP[10], extraCP[8], extraCP[6], ty);
                }
                else
                {
                    // top half
                    float ty = (float)(y - meshResolution.y) / meshResolution.y;
                    y0 = MathUtils.EvalSpline(extraCP[9], extraCP[7], extraCP[5], extraCP[0], ty);
                    y1 = MathUtils.EvalSpline(
                        controlPoints.bottomLeft, controlPoints.left, controlPoints.topLeft,
                        extraCP[1], ty);
                    y2 = MathUtils.EvalSpline(
                        controlPoints.bottom, controlPoints.center, controlPoints.top,
                        extraCP[2], ty);
                    y3 = MathUtils.EvalSpline(
                        controlPoints.bottomRight, controlPoints.right, controlPoints.topRight,
                        extraCP[3], ty);
                    y4 = MathUtils.EvalSpline(extraCP[10], extraCP[8], extraCP[6], extraCP[4], ty);
                }

                for (int x = 0; x < numVertsX; ++x)
                {
                    int i = y * numVertsX + x;

                    if (x < meshResolution.x)
                    {
                        // left half
                        float tx = (float)x / meshResolution.x;

                        WarpMeshVertex vertex = vertices[i];
                        vertex.position = MathUtils.EvalSpline(y0, y1, y2, y3, tx);
                        vertices[i] = vertex;
                    }
                    else
                    {
                        // right half
                        float tx = (float)(x - meshResolution.x) / meshResolution.x;

                        WarpMeshVertex vertex = vertices[i];
                        vertex.position = MathUtils.EvalSpline(y1, y2, y3, y4, tx);
                        vertices[i] = vertex;
                    }
                }
            }
        }

        /// <summary>
        /// Fills <paramref name="vertices"/> positions by calculating a homography matrix that
        /// maps the corner <paramref name="controlPoints"/> to an ideal square.
        /// </summary>
        /// <param name="controlPoints"></param>
        /// <param name="meshResolution"></param>
        /// <param name="vertices"></param>
        private static void SetVertexPositionsHomography(
            WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            ref List<WarpMeshVertex> vertices)
        {
            Vector2[] idealPoints = new Vector2[4];
            Vector2[] cpPoints = new Vector2[4];

            idealPoints[0] = new Vector2(-1.0f, 1.0f);
            idealPoints[1] = new Vector2(1.0f, 1.0f);
            idealPoints[2] = new Vector2(1.0f, -1.0f);
            idealPoints[3] = new Vector2(-1.0f, -1.0f);
            cpPoints[0] = controlPoints.topLeft;
            cpPoints[1] = controlPoints.topRight;
            cpPoints[2] = controlPoints.bottomRight;
            cpPoints[3] = controlPoints.bottomLeft;
            Matrix3x3 H = MathUtils.CalcHomographyMatrix(idealPoints, cpPoints);

            int numVerts = CalcVertexCount(
                WarpMeshStyle.Homography, meshResolution, out int numVertsX, out int numVertsY);
            Assert.AreEqual(numVerts, vertices.Count);

            for (int y = 0; y < numVertsY; ++y)
            {
                // normalized [0,1] and NDC [-1, 1] Y
                float nY = (float)y / (numVertsY - 1);
                float ndcY = Mathf.Lerp(-1.0f, 1.0f, nY);

                for (int x = 0; x < numVertsX; ++x)
                {
                    // normalized [0,1] and NDC [-1, 1] X
                    float nX = (float)x / (numVertsX - 1);
                    float ndcX = Mathf.Lerp(-1.0f, 1.0f, nX);

                    Vector2 ndcP = new Vector2(ndcX, ndcY);

                    int i = y * numVertsX + x;
                    WarpMeshVertex vertex = vertices[i];
                    vertex.position = H.MultiplyPoint(ndcP);
                    vertices[i] = vertex;
                }
            }
        }

        /// <summary>
        /// Fills <paramref name="vertices"/> positions by calculating four homography matrices
        /// (one per quadrant) that map between <paramref name="controlPoints"/> and an ideal
        /// square. All four matrices are applied to grid points and the final position is a
        /// weighted sum based on where the grid points is located relative to the quadrants.
        /// </summary>
        /// <param name="controlPoints"></param>
        /// <param name="meshResolution"></param>
        /// <param name="vertices"></param>
        private static void SetVertexPositionsMultiHomography(
            WarpMeshControlPoints controlPoints, Vector2Int meshResolution,
            ref List<WarpMeshVertex> vertices)
        {
            Vector2[] idealPoints = new Vector2[4];
            Vector2[] cpPoints = new Vector2[4];

            // top left quadrant
            idealPoints[0] = new Vector2(-1.0f, 1.0f);
            idealPoints[1] = new Vector2(0.0f, 1.0f);
            idealPoints[2] = new Vector2(0.0f, 0.0f);
            idealPoints[3] = new Vector2(-1.0f, 0.0f);
            cpPoints[0] = controlPoints.topLeft;
            cpPoints[1] = controlPoints.top;
            cpPoints[2] = controlPoints.center;
            cpPoints[3] = controlPoints.left;
            Matrix3x3 Htl = MathUtils.CalcHomographyMatrix(idealPoints, cpPoints);

            // top right quadrant
            idealPoints[0] = new Vector2(0.0f, 1.0f);
            idealPoints[1] = new Vector2(1.0f, 1.0f);
            idealPoints[2] = new Vector2(1.0f, 0.0f);
            idealPoints[3] = new Vector2(0.0f, 0.0f);
            cpPoints[0] = controlPoints.top;
            cpPoints[1] = controlPoints.topRight;
            cpPoints[2] = controlPoints.right;
            cpPoints[3] = controlPoints.center;
            Matrix3x3 Htr = MathUtils.CalcHomographyMatrix(idealPoints, cpPoints);

            // bottom left quadrant
            idealPoints[0] = new Vector2(-1.0f, 0.0f);
            idealPoints[1] = new Vector2(0.0f, 0.0f);
            idealPoints[2] = new Vector2(0.0f, -1.0f);
            idealPoints[3] = new Vector2(-1.0f, -1.0f);
            cpPoints[0] = controlPoints.left;
            cpPoints[1] = controlPoints.center;
            cpPoints[2] = controlPoints.bottom;
            cpPoints[3] = controlPoints.bottomLeft;
            Matrix3x3 Hbl = MathUtils.CalcHomographyMatrix(idealPoints, cpPoints);

            // bottom right quadrant
            idealPoints[0] = new Vector2(0.0f, 0.0f);
            idealPoints[1] = new Vector2(1.0f, 0.0f);
            idealPoints[2] = new Vector2(1.0f, -1.0f);
            idealPoints[3] = new Vector2(0.0f, -1.0f);
            cpPoints[0] = controlPoints.center;
            cpPoints[1] = controlPoints.right;
            cpPoints[2] = controlPoints.bottomRight;
            cpPoints[3] = controlPoints.bottom;
            Matrix3x3 Hbr = MathUtils.CalcHomographyMatrix(idealPoints, cpPoints);

            int numVerts = CalcVertexCount(
                WarpMeshStyle.MultiHomography, meshResolution,
                out int numVertsX, out int numVertsY);
            Assert.AreEqual(numVerts, vertices.Count);

            for (int y = 0; y < numVertsY; ++y)
            {
                // normalized [0,1] and NDC [-1, 1] Y
                float nY = (float)y / (numVertsY - 1);
                float ndcY = Mathf.Lerp(-1.0f, 1.0f, nY);

                for (int x = 0; x < numVertsX; ++x)
                {
                    // normalized [0,1] and NDC [-1, 1] X
                    float nX = (float)x / (numVertsX - 1);
                    float ndcX = Mathf.Lerp(-1.0f, 1.0f, nX);

                    Vector2 ndcP = new Vector2(ndcX, ndcY);

                    // apply homography matrices for all 4 quadrants...
                    Vector2 pTL = Htl.MultiplyPoint(ndcP);
                    Vector2 pTR = Htr.MultiplyPoint(ndcP);
                    Vector2 pBL = Hbl.MultiplyPoint(ndcP);
                    Vector2 pBR = Hbr.MultiplyPoint(ndcP);

                    // ... and bi-linearly interpolate between them based on wX, wY
                    // which give a matrix full weight from the center of its quadrant to
                    // the edge and otherwise bilinearly interpolate between matrices
                    float wX = 2.0f * Mathf.Clamp(nX, 0.25f, 0.75f) - 0.5f;
                    float wY = 2.0f * Mathf.Clamp(nY, 0.25f, 0.75f) - 0.5f;

                    Vector2 pT = Vector2.Lerp(pTL, pTR, wX);
                    Vector2 pB = Vector2.Lerp(pBL, pBR, wX);
                    Vector2 p = Vector2.Lerp(pB, pT, wY);

                    int i = y * numVertsX + x;
                    WarpMeshVertex vertex = vertices[i];
                    vertex.position = p;
                    vertices[i] = vertex;
                }
            }
        }

        /// <summary>
        /// Fills <paramref name="vertices"/> uv coordinates for a grid mesh.
        /// </summary>
        /// <param name="meshResolution"></param>
        /// <param name="sourceRect"></param>
        /// <param name="vertices"></param>
        private static void SetVertexUVsGrid(
            Vector2Int meshResolution, Rect sourceRect, ref List<WarpMeshVertex> vertices)
        {
            int numVerts = CalcVertexCount(
                WarpMeshStyle.Linear, meshResolution, out int numVertsX, out int numVertsY);
            Assert.AreEqual(numVerts, vertices.Count);

            for (int y = 0; y < numVertsY; ++y)
            {
                // normalized y in [0,1]
                float tY = (float)y / (float)(numVertsY - 1);
                float nY = Mathf.Lerp(sourceRect.y, sourceRect.y + sourceRect.height, tY);

                for (int x = 0; x < numVertsX; ++x)
                {
                    // normalized x in [0,1]
                    float tX = (float)x / (float)(numVertsX - 1);
                    float nX = Mathf.Lerp(sourceRect.x, sourceRect.x + sourceRect.width, tX);

                    int i = y * numVertsX + x;
                    WarpMeshVertex vertex = vertices[i];
                    vertex.uv = new Vector2(nX, nY);
                    vertices[i] = vertex;
                }
            }
        }

        private static List<UInt16> MakeIndicesGrid(Vector2Int meshResolution)
        {
            int numIndices = CalcIndexCount(
                WarpMeshStyle.Linear, meshResolution, out int numCellsX, out int numCellsY);

            List<UInt16> indices = new List<UInt16>(numIndices);

            for (int y = 0; y < numCellsY; ++y)
            {
                for (int x = 0; x < numCellsX; ++x)
                {
                    int baseIndex = y * (numCellsX + 1) + x;
                    indices.Add((UInt16)baseIndex);
                    indices.Add((UInt16)(baseIndex + numCellsX + 1));
                    indices.Add((UInt16)(baseIndex + 1));
                    indices.Add((UInt16)(baseIndex + 1));
                    indices.Add((UInt16)(baseIndex + numCellsX + 1));
                    indices.Add((UInt16)(baseIndex + numCellsX + 2));
                }
            }

            return indices;
        }
    }

} // namespace VARLab.ExternalDisplay
