
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Information about a warp mesh.
    /// </summary>
    [Serializable]
    public sealed class WarpMeshInfo
        : ICloneable
    {
        [Tooltip("Name of this warp mesh (must be unique)")]
        public string name = string.Empty;

        [Tooltip("The type of warping mesh generated - affects meaning of control points")]
        public WarpMeshStyle warpStyle = WarpMeshStyle.FullscreenQuad;

        [Tooltip("Resolution of the source render texture (for pixel coordinate mode)")]
        public Vector2Int sourceResolution = Vector2Int.zero;

        [Tooltip("How sourceRect coordinates are interpreted")]
        public CoordinateMode coordinateMode = CoordinateMode.Normalized;

        [Tooltip(
            "Region of sourceTexture applied to this warp mesh (normalized or pixels based on "
            + "coordinate mode)")]
        public Rect sourceRect = new Rect(Vector2.zero, Vector2.one);

        [Tooltip("Resolution of the warp mesh grid (number of vertices)")]
        public Vector2Int meshResolution = new Vector2Int(16, 16);

        [Tooltip("Control points determining the warping (in [-1, 1] NDC)")]
        public WarpMeshControlPoints controlPoints = new WarpMeshControlPoints();

        [NonSerialized]
        internal Mesh mesh = null;
        [NonSerialized]
        internal NativeWarpMeshDesc meshDesc = null;

        // --------------------------------------------------------------
        #region ICloneable

        public WarpMeshInfo Clone()
        {
            WarpMeshInfo clone = (WarpMeshInfo)MemberwiseClone();
            // mesh and meshDesc are not cloned!
            clone.mesh = null;
            clone.meshDesc = null;

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }
} // namespace VARLab.ExternalDisplay
