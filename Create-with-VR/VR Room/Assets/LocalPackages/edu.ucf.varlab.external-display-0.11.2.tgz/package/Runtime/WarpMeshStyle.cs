
namespace VARLab.ExternalDisplay
{
    public enum WarpMeshStyle
    {
        FullscreenQuad,
        Linear,
        Spline,
        Homography,
        MultiHomography
    }

} // namespace VARLab.ExternalDisplay