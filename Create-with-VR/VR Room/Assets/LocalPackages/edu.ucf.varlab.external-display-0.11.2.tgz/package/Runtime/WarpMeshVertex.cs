
// system namespaces
using System.Runtime.InteropServices;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    [StructLayout(LayoutKind.Sequential)]
    public struct WarpMeshVertex
    {
        public Vector2 position;
        public Vector2 uv;
    }

} // namespace VARLab.ExternalDisplay
