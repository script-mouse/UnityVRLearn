
// system namespaces
using System;
// unity namespaces
using UnityEngine;

namespace VARLab.ExternalDisplay
{
    /// <summary>
    /// Information about a window where content is presented.
    /// </summary>
    [Serializable]
    public sealed class WindowInfo
        : ICloneable
    {
        [Tooltip("Name of this window (must be unique)")]
        public string name = string.Empty;

        [Tooltip("Name of the device to associate this window with (empty for Unity device)")]
        public string deviceName = string.Empty;

        [Tooltip("Position of the window on the desktop")]
        public Vector2Int position = Vector2Int.zero;

        [Tooltip("Size of the window on the desktop")]
        public Vector2Int size = Vector2Int.zero;

        [NonSerialized]
        internal NativeWindowDesc windowDesc = null;

        // --------------------------------------------------------------
        #region ICloneable

        public WindowInfo Clone()
        {
            WindowInfo clone = (WindowInfo)MemberwiseClone();
            // windowDesc is not cloned!
            clone.windowDesc = null;

            return clone;
        }

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion // ICloneable
        // --------------------------------------------------------------
    }

} // namespace VARLab.ExternalDisplay
